Paper 7 frozen temporal benchmark — unmodified study files.

From this folder execute: python -B reproduce.py

Python 3.11 or later, SQLite and pandas are required. The frozen design evaluates 4,935 constructed traces and 26,430 event decisions. Study files are preserved without modification.
