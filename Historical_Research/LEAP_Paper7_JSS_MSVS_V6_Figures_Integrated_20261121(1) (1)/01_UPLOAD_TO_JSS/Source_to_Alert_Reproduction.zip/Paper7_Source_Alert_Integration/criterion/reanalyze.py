"""Read-only re-scoring of archived version strategies under two explicitly distinguished criteria."""
from pathlib import Path
import pandas as pd, json, hashlib, csv
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT
CASES=SRC/'recovered'/'LEAP_Paper7_Real_Revision_Authority_Gate_20261119'/'Paper7_RealRevision_Authority_Gate_20261119'
O=SRC/'integration'/'outputs'
OUT=ROOT/'criterion/outputs';OUT.mkdir(parents=True,exist_ok=True)
R=pd.read_csv(CASES/'data'/'real_source_revisions.csv').fillna('')
assert len(R)==9 and R.case_id.nunique()==9
for rec in R.itertuples():
 case_dir=CASES/'cases'/rec.case_id
 paths=sorted(case_dir.glob('before.*'))+sorted(case_dir.glob('after.*'))
 assert len(paths)==2, (rec.case_id,paths)
 assert hashlib.sha256(paths[0].read_bytes()).hexdigest()==rec.before_sha256,rec.case_id
 assert hashlib.sha256(paths[1].read_bytes()).hexdigest()==rec.after_sha256,rec.case_id
 assert rec.before_sha256!=rec.after_sha256
D=pd.read_csv(O/'decision_events.csv')
assert len(D)==1512 and len(D.groupby(['case_id','strategy','scenario']))==252
assert D.groupby(['case_id','strategy','scenario']).size().eq(6).all()
P=pd.read_csv(O/'pair_categories.csv')
assert len(P)==9
for s in sorted(D.strategy.unique()):print('strategy',s)
# Rescore every scenario against actual recorded stream of a designated reference strategy, not a fabricated new oracle.
fields=['state','active','severity']
refs={'signed_source_file_scope':'A_file','derived_output_scope':'D_dual'}
rows=[]; details=[]
for policy,reference in refs.items():
 for st in ['A_file','B_calculation','C_documentation','D_dual']:
  mismatch_streams=mismatch_events=reason_mismatch_streams=reason_mismatch_events=0
  for (case,sc), group in D[D.strategy==st].groupby(['case_id','scenario']):
   rg=D[(D.strategy==reference)&(D.case_id==case)&(D.scenario==sc)].sort_values('event_index')
   g=group.sort_values('event_index')
   assert len(g)==len(rg)==6
   diff_field=(g[fields].to_numpy()!=rg[fields].to_numpy()).any(axis=1)
   diff_reason=(g.reason.to_numpy()!=rg.reason.to_numpy())
   mismatch_streams+=int(diff_field.any());mismatch_events+=int(diff_field.sum())
   reason_mismatch_streams+=int(diff_reason.any());reason_mismatch_events+=int(diff_reason.sum())
   details.append({'criterion':policy,'reference_strategy':reference,'case_id':case,'scenario':sc,'strategy':st,'decision_differences_in_stream':int(diff_field.any()),'decision_event_differences':int(diff_field.sum()),'reason_differences_in_stream':int(diff_reason.any()),'reason_event_differences':int(diff_reason.sum())})
  rows.append({'criterion':policy,'reference_strategy':reference,'strategy':st,'changed_pairs_detected':int(P[P['calculation_representation_changed'].notna()].shape[0]) if False else None,'differing_sequences':mismatch_streams,'total_sequences':63,'differing_event_tuples':mismatch_events,'total_events':378,'differing_reason_sequences':reason_mismatch_streams,'differing_reason_events':reason_mismatch_events})
metric=pd.DataFrame(rows)
change=pd.read_csv(O/'change_detection.csv')
for row in rows:
 policy=row['criterion'];st=row['strategy']
 c=change[change.strategy==st]
 assert len(c)==9
 if policy=='signed_source_file_scope':
  row['missed_changes']=int((~c.detected_change).sum());row['extra_resets']=0
 else:
  row['missed_changes']=int(c.missed_change.sum());row['extra_resets']=int(c.false_reset.sum())
 row['changed_pairs_detected']=int(c.detected_change.sum())
metric=pd.DataFrame(rows)
metric.to_csv(OUT/'reference_sensitivity_8rows.csv',index=False)
pd.DataFrame(details).to_csv(OUT/'case_context_reference_sensitivity.csv',index=False)
case_out=R[['case_id','source_path','parent_commit','child_commit','before_sha256','after_sha256']].merge(P,on='case_id').sort_values('case_id')
case_out['strict_source_file_signature_changed']=True
case_out.to_csv(OUT/'verified_revision_criteria.csv',index=False)
result={'checked_sha256_pairs':len(R),'archived_event_rows':len(D),'streams':252,'per_reference_streams':63,'summary_rows':rows,'source_files':{'policy_GOVERNANCE_SPEC_md':hashlib.sha256((SRC/'recovered'/'LEAP_Paper7_Source_Revision_Pilot_20261119'/'inputs'/'source_snapshot'/'.ai'/'GOVERNANCE_SPEC.md').read_bytes()).hexdigest(), 'policy_BUSINESS_RULES_md':hashlib.sha256((SRC/'recovered'/'LEAP_Paper7_Source_Revision_Pilot_20261119'/'inputs'/'source_snapshot'/'.ai'/'BUSINESS_RULES.md').read_bytes()).hexdigest()}}
(OUT/'rescore_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(metric.to_string(index=False))
print('PASSED',len(R),'verified source hashes +',len(D),'archived event decisions')
