Paper 7 source-to-alert study.

From this folder run:

1. python -B integration/run_integration.py
2. python -B criterion/reanalyze.py

The first command recreates 252 constructed monitoring streams from the nine preserved Git source-pair representations. The second command verifies the 18 source-file hashes and compares both documented revalidation requirements using the recorded 1,512 event outcomes. The source-identity and monitor inputs remain unchanged. Python 3.11 or later and pandas are required.
