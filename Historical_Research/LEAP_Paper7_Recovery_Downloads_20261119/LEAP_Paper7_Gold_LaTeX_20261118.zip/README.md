# Paper 7 - editable Gold revision

Version: 18 November 2026. Main source: `Paper7.tex`.
All source files, bibliography, class, style and figure assets are at one folder level.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error Paper7.tex
```

Use a standard LaTeX installation with the packages listed in the source,
including longtable. The generated BBL, elsarticle class and unsrtnat style are
included. Preserve the original license notices within the class and style.
The three PDF figures are the approved assets used by the manuscript. Matching
editable SVGs are included. Their original metadata identifies Matplotlib 3.10.8.

To recompute the plotted counts from saved outputs and export the SVGs:

```sh
python reproduce_figures.py --archive ../LEAP_Paper7_Reproduction_20261118.zip --svg-dir . --output-dir ../figure-reproduction --previews
```

See Figure_Reproduction_README.md for dependencies. Re-exported PDF metadata may
differ; this verification preserves the scientific values and vector artwork.
The locked research archive is supplied beside this source ZIP in the clean
journal-file bundle. Extract it and run from its Paper7_Reproduction directory:

```sh
python -B run_all.py ../paper7-run
```

The Gold review retains the frozen archive byte for byte. It adds independent
raw-output rescoring, literature and source audits, reader review and production
checks. Those records and the substantive diff are in the complete Gold package.
SHA256SUMS covers every payload file in this source ZIP.
