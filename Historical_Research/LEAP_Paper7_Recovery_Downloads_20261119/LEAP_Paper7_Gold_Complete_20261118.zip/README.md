# LEAP Paper 7 - complete Gold revision

18 November 2026. **COMPLETE WITH RECORDED VENUE/ADMIN CHECK.**

Start with `LEAP_Paper7_Gold_Review_20261118.pdf` and
`manuscript/Paper7.pdf`. The report explains the completed work and the exact
remaining venue/author facts. The manuscript is the final 21-page revision.

## Contents

- `manuscript/`: final source, PDF, bibliography/BBL, class/style and approved PDF figures.
- `figures/`: unchanged editable SVG artwork, independently checked plot data and export/verification script.
- `journal_files/`: clean manuscript PDF, flat LaTeX source ZIP, locked research supplement, cover letter and highlights.
- `review/reports/`: identity brief, full protocol execution register, source/bibliography diffs, change/closure register, gates and administrative record.
- `review/agents/`: five specialist reports with source-level, method, reader and production evidence.
- `review/prior_audits/`: retained earlier claim/benchmark/declaration records. The new venue report corrects two benchmark details.
- `validation/`: final identities, preservation checks, package checks and build records.
- `research/`: unchanged executable reproduction ZIP.
- `recovered/` and `revision_20261118/`: exact original historical inputs required by the new independent saved-output audit.
- `baseline/`: the authoritative 20-page pre-Gold manuscript and source assets.
- `history/`: the entire preceding prompt-suite completion package.
- `instructions/`: the exact attached Gold Niche protocol.
- `provenance/`: actual current and historical AI activity records.

Primary external publication URLs, access outcomes and retrieval hashes are in
the novelty source ledger/search log and venue access ledger. Local source names
in those reports identify the originals inspected in this session. Repository
commit and blob identities are retained in their retrieval metadata.

## Build the manuscript

For the cleanest build, extract the flat source ZIP in `journal_files/` and run:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error Paper7.tex
```

The independent production review records the actual successful build environment
and verifies exact text/rendered-page equivalence with the delivered PDF.

## Replay the preserved study

Extract `research/LEAP_Paper7_Reproduction_20261118.zip`. From its
`Paper7_Reproduction` directory:

```sh
python -B run_all.py ../paper7-run
```

The archive retains its original entry point, inputs, outputs, source/licenses
and execution logs. The Gold phase independently rescored saved outputs and
preserved earlier actual executions.

## Repeat the independent saved-output audit

From this complete package directory:

```sh
python -m zipfile -e research/LEAP_Paper7_Reproduction_20261118.zip review/agents/method/frozen
python review/agents/method/audit_saved_evidence.py
```

This audit imports no study implementation. It uses the extracted frozen data,
the original `recovered/` archive and the retained targeted-check JSON. It writes
the raw evidence audit, metric CSV and read-input hashes in its own directory.
Absolute paths in the originally delivered JSON describe the inspected workspace;
new execution records will identify the directory where this package is extracted.

## Repeat the figure audit/export

```sh
python figures/reproduce_figures.py --archive research/LEAP_Paper7_Reproduction_20261118.zip --svg-dir figures --output-dir figure-reproduction --previews
```

See `figures/README.md` for dependencies. The script independently checks plotted
counts and SVG data positions, then exports the retained artwork to a separate
directory. Approved manuscript PDF figures are preserved. Export metadata may vary.

## Preservation and current administrative checks

All protected theory, numerical tables, Results/Discussion/Conclusion, figure
assets and the locked research archive retain their identities. Qualitative
Table 2 and the targeted literature/method/provenance wording have the documented
changes. The final bibliography contains 28 cited entries.

`review/reports/Venue_and_Author_Checks.md` lists the live journal guide, author-only
declarations and unavailable historical AI build identifiers. No submission or
publication was performed. SHA256SUMS covers every other file in this package.
