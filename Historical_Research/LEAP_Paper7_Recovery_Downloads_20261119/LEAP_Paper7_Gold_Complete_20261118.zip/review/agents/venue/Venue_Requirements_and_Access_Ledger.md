# Paper 7: verified venue requirements and access ledger

**Checked 18 November 2026.** Current official scope is verified. The current SCP Guide for Authors remains inaccessible. Numerical journal rules are therefore **NOT VERIFIED**, even when a dated prior record supplies a useful working value. Scope/genre findings are in `Venue_Fit_and_Benchmark.md`.

## Requirements matrix

| Requirement / field | Verification result | Exact operative content or boundary | Manuscript implication |
|---|---|---|---|
| Scope | VERIFIED [S1], lines 94–110 | Software development, specification, verification and testing are in scope. | The monitor contract and evaluation fit. |
| Research Papers Track | VERIFIED [S1], lines 111–120 | Formal techniques include pragmatic application; experimental software technology includes implementations and experiments with systems/methods. | Correct target track. |
| Software Track | VERIFIED [S1], lines 122–124 | OSP is a separate track. | Do not import OSP manuscript-length guidance into this paper. |
| Abstract maximum | NOT VERIFIED current | Identity brief records 250 words from a 26 April 2026 guide; current route returned 403. | Baseline reports 238 words; retain as a working value, not current-rule certification. |
| Number of keywords | NOT VERIFIED current | Identity brief records 1–7 from that dated guide; current route returned 403. | Baseline has six keywords. |
| Research-article page/word limit | NOT VERIFIED | No accessible current journal rule. | Neither 20 manuscript pages nor a comparator's page count determines compliance. |
| Current highlights requirement / bullet and character limits | NOT VERIFIED journal-specific | No accessible current primary SCP instruction. | Retain prepared highlights; do not certify live requirement. |
| Citation format / initial-submission flexibility | NOT VERIFIED journal-specific | Current Elsevier general LaTeX page sends journal-specific styles to its Guide for Authors [S12], lines 53–55. | Existing `unsrtnat` is a manuscript fact, not verified current journal compliance. |
| Anonymization / title-page separation | NOT VERIFIED journal-specific | Current SCP peer-review model and packaging rule unavailable. | Do not declare the identifiable baseline anonymized. |
| Mandatory journal declarations, data statement, CRediT and funding fields | NOT VERIFIED journal-specific | Live guide and submission checklist not inspected. | Recover existing author facts; never fill absent facts by inference. |
| Elsevier LaTeX template support | VERIFIED general policy [S12], lines 49–55 | Official support for `elsarticle`; journal-specific style remains delegated to guide. | Existing class is appropriate publisher infrastructure. |
| Source packaging for Editorial Manager | VERIFIED general policy [S12], lines 60–96 | Supply source/BibTeX/figures and needed nonstandard classes/packages; keep submission sources at one folder level; do not classify LaTeX files as Supplementary. | Build a flat journal source bundle; retain the full research archive separately. |
| AI research-method assistance | VERIFIED general policy [S13], lines 81, 117–119 and 188–191 | Describe research/code assistance reproducibly in Methods. | Baseline lines 256–257 already describe the workflow; recover actual version records before further claims. |
| AI manuscript declaration | VERIFIED general policy [S13], lines 76–87 and 236–244 | Before references: tools, purpose, oversight and responsibility. | Preserve the approved responsibility sentence. A statement that the author reviewed outputs requires the author's factual confirmation or an existing record. |
| AI-assisted explanatory images | VERIFIED policy; exact code-path applicability requires provenance judgment [S13], lines 94–101 and 251–255 | Caption and general-declaration provenance. | Inspect actual figure creation/edit records; see precise interpretation below. |
| AI-assisted data visualization | VERIFIED general policy [S13], lines 104–110 | Reproducible data derivation; tool/version/developer in Methods. | Check the actual plotting script/data and available execution/tool history. |

## Exact disclosure passage and applicability

The explanatory-image section states: **“The use of AI tools should be disclosed in the caption of each image”** [S13, line 101]. It then specifies tool, version and manner of use. The FAQ also directs disclosure for explanatory-image creation. These are current publisher statements, separate from the blocked journal guide.

The text does **not explicitly distinguish AI-written rendering code from direct generative imagery**. Its explanatory-image category is framed around AI support in creating flowcharts and diagrams. Applying that category to an AI-authored Python/SVG diagram is therefore an applicability interpretation, not a separately verified code-specific rule. Code assistance itself is expressly covered by Methods reporting. The lead should classify the actual artifacts from their provenance and make a factual disclosure; an exemption based solely on a vector or programmatic output format is not stated in this policy.

Baseline captions (source lines 130, 189 and 316) contain no AI-use wording. Baseline Methods names ChatGPT/Codex and points to available settings in archived records; the declaration names drafting/editorial review and responsibility. Figure origin, historically available model identifiers and the author's personal final review are facts to recover, not facts established by this venue review. The recommended declaration format is not a requirement to reproduce its wording verbatim.

**Administrative handoff:** check records first; add only accurately supported provenance where the verified policy applies; keep the protected responsibility sentence unchanged. No scientific result or figure value needs modification to resolve this item. The methods/production gate determines which facts are actually available.

## Sources actually opened

Reference IDs below are retrieval identifiers for the Chief Editor to reopen before final chat citations. Page numbers refer to the published PDFs; line numbers refer to the tool's extracted page. Access status is specific to this review.

| ID | Official or primary source URL | Access status and exact evidence location | Web reference IDs |
|---|---|---|---|
| S1 | [SCP official Elsevier Shop scope](https://shop.elsevier.com/journals/science-of-computer-programming/0167-6423) | Full scope opened; lines 94–124 inspected. Current primary publisher source. | `turn429665348view3` |
| S2 | [SCP ScienceDirect aims and scope](https://www.sciencedirect.com/journal/science-of-computer-programming/about/aims-and-scope) | HTTP 403. No content-based rule inferred. | `turn429665348view0` |
| S3 | [SCP current Guide for Authors](https://www.sciencedirect.com/journal/science-of-computer-programming/publish/guide-for-authors) | HTTP 403 on direct open and official Shop link click. | `turn429665348view1`; `turn959335535view1` |
| S4 | [Legacy Elsevier guide route](https://www.elsevier.com/journals/science-of-computer-programming/0167-6423/guide-for-authors) | HTTP 403. | `turn429665348view2` |
| S5 | [Journals Elsevier guide route](https://www.journals.elsevier.com/science-of-computer-programming/guide-for-authors) | Tool reports URL not accessible. | `turn959335535view0` |
| S6 | [Vamos published PDF at ISTA](https://research-explorer.ista.ac.at/download/18169/18831/2024_ScienceCompProg_Chalupa.pdf) | Complete 32-page version of record accessible; inspected title, introduction, architecture/examples, evaluation, threats, future work and conclusion. Direct PDF GET also 200. | `turn978343170view0`; `turn435632832view3`–`turn435632832view5`; `turn877803573view1` |
| S7 | [Stemmer et al. published PDF at DLR](https://elib.dlr.de/214014/1/1-s2.0-S0167642325000401-main.pdf) | Complete 15-page version of record accessible; inspected §§1–7 with emphasis on semantics, mapping, examples and closing boundaries. Direct PDF GET also 200. | `turn978343170view1`; `turn435632832view6`; `turn877803573view2` |
| S8 | [detectEr published PDF at University of Malta](https://staff.um.edu.mt/afra1/papers/linearDetectErSCP2024.pdf) | Complete seven-page version of record accessible; inspected title/type, formalism, token-server examples, §3.4 evidence attribution and §4 conclusion. Direct PDF GET also 200. | `turn978343170view2`; `turn435632832view7`; `turn877803573view3` |
| S9 | [Formal Aspects of Computing, official BCS owner page](https://www.bcs.org/about-us/learned-publishing/formal-aspects-of-computing/) | Current primary society page opened; scope lines 144–151. | `turn435632832view0`; `turn877803573view0` |
| S10 | [FAC ACM author guidelines](https://dl.acm.org/journal/fac/author-guidelines) | Official BCS-linked guide returned 403; ACM aims/scope URL also inaccessible. | `turn959335535view2`; `turn435632832view1` |
| S11 | [STTT official editorial-site scope](https://sttt.cs.uni-dortmund.de/aims-and-scope/) | Full short page opened; lines 18–22 inspected to compare venue emphasis. | `turn435632832view2` |
| S12 | [Elsevier LaTeX instructions](https://www.elsevier.com/researcher/author/policies-and-guidelines/latex-instructions) | Current primary policy opened; lines 49–96 inspected. | `turn924183738view0` |
| S13 | [Elsevier generative AI policies for journals](https://www.elsevier.com/about/policies-and-standards/generative-ai-policies-for-journals) | Current primary policy opened; author disclosure, image/data visualization, Methods/code and FAQ passages inspected. | `turn924183738view1`; `turn476034983view0`–`turn476034983view3` |
| S14 | [Elsevier template support FAQ](https://www.elsevier.support/publishing/answer/is-there-a-template-available-for-my-manuscript-file) | Current page opened; last updated 28 August 2026, lines 72–74. It delegates exact template requirements to the journal guide; not used to establish an SCP-specific rule. | `turn306743420view0` |

The Scribd reproduction of a dated guide appeared in search. It was not used as current primary evidence. No APC/price, institutional agreement or acceptance-probability claim was researched or made. No login, paywall circumvention or alternate access credential was attempted.

## Limits of this requirements review

Journal-specific rules remain unknown where the live guide was inaccessible. Publisher-wide policies were verified separately and are identified as such. This review did not open the authenticated submission form or verify author-only declarations. Its findings support a venue/administrative check; they do not reopen the manuscript's validated scientific record.
