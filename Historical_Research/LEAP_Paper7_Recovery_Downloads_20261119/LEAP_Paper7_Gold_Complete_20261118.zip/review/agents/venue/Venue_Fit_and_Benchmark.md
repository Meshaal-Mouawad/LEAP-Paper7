# Paper 7: journal fit and published-paper benchmark

**Decision: FIT — Science of Computer Programming, Research Papers Track.**

**Verification date:** 18 November 2026. **Reviewer role:** Discipline and Niche-Journal Agent. **Authority:** the Gold Niche Chief Editor Protocol and Paper Identity and Evidence Brief were read in full. The complete authoritative `baseline/Paper7.tex` was read. No manuscript or protected evidence was edited.

The manuscript is completed applied formal-methods research: an executable review contract, a representation analysis, and deterministic constructed-trace evaluation with separately encoded executions. Its central object is the information needed to preserve specified outputs of a revision-sensitive monitor. That object belongs in the target journal's software specification, verification and testing conversation. The accessible official publisher scope explicitly includes pragmatic applications of formal techniques and experimental software technology in its Research Papers Track [S1, lines 94–124].

The paper's contribution is the contract-specific separation between an interface that preserves displayed state/activity/severity and an interface that additionally preserves the prescribed reason. Its second useful result is the demonstrated loss of display errors when evaluation considers active intervals alone. This is the contribution against which the paper should be evaluated. General abstraction principles are established prior work and already attributed in the baseline (§2.2 and §4). The scientific bar is whether the specified interface result and endpoint failure teach the specialist a defensible design and testing lesson.

## Baseline identity

| Item | Independently checked value |
|---|---|
| Title | Version Comparisons Preserve Governance Alert Decisions Across Evidence and Policy Revisions |
| Authoritative source SHA-256 | `78297924bc2607ef52d01bdfdfb3b244589389c0271f5ca4ea9d6d9208f281b8` |
| Authoritative PDF SHA-256 | `73c843da88d0b14d71e6300f625800295fb910d44c9387fb8fe2613483fe3720` |
| PDF | 20 pages; 484,262 bytes; US Letter |
| Appropriate genre | Research article in applied formal techniques, with executable contract and controlled conformance evidence |
| Track | Research Papers Track |

The research question and proved representation result determine the Research Papers classification.

## Bounded near-neighbor benchmark

Three existing comparison papers were independently reopened as complete versions of record at author/institutional hosts. The sections below were inspected; the report does not claim a line-by-line audit of every appendix or reference. Primary PDF retrieval also succeeded for all three. Two research articles set the main comparison. The third is explicitly retained as a tool/explanation comparator.

| Paper and role | Design, claim and evidence actually inspected | Authors' stated boundaries / future work | Evidence locations |
|---|---|---|---|
| **M. Chalupa, F. Muehlboeck, S. Muroya Lei and T. A. Henzinger. “Vamos: Middleware for best-effort third-party monitoring.” Science of Computer Programming 240 (2025), 103212.** DOI: [10.1016/j.scico.2024.103212](https://doi.org/10.1016/j.scico.2024.103212). Main research comparison. | Heterogeneous event acquisition, preprocessing and arbitration connect monitored systems to monitors. Formalized components and a prototype support experiments on throughput, buffering and application cases. The race experiment uses 391 supported SV-COMP cases; verdict correctness is assessed on the 118-case ground-truth subset. | §5.4.1 identifies resource/architecture dependence, untested very large stream counts, benchmark selection, one author's recorded pointer inputs, and manual compiler testing. §§7–8 propose broader applications, higher-level language integration, multiple arbiters and enforcement. | [S6]: title p.1; architecture/examples pp.2–5; evaluation §5, especially pp.15–18 and Fig.12; limitations p.18; future work/conclusion pp.19–20. |
| **R. Stemmer, I. Saxena, L. Panneke, D. Grundt, A. Austel, E. Möhlmann and B. Westphal. “Runtime monitoring of complex scenario-based requirements for autonomous driving functions.” Science of Computer Programming 244 (2025), 103301.** DOI: [10.1016/j.scico.2025.103301](https://doi.org/10.1016/j.scico.2025.103301). Main research comparison. | Defines Traffic Sequence Chart monitoring from sampled observations through an explicit signal-to-attributes mapping. Formal semantics and component construction lead to two plotted CARLA trajectories with contrasting verdicts; SILAB adaptation is explained. §6 also constructs a bus-stop example and an in-vehicle, sensor-aware example. | Verdict interpretation is relative to the mapping and sampling procedure (§5, §7). Automation of monitor construction, broader TSC support and additional domains/purposes remain future work (§6.4, §7). | [S7]: contribution pp.1–2; overview/semantics/architecture §§3–5, pp.3–8; examples §§6.1–6.3, pp.8–13; discussion/conclusion pp.13–14. |
| **L. Aceto, A. Achilleos, D. P. Attard, L. Exibard, A. Francalanza and A. Ingólfsdóttir. “A monitoring tool for linear-time μHML.” Science of Computer Programming 232 (2024), 103031.** DOI: [10.1016/j.scico.2023.103031](https://doi.org/10.1016/j.scico.2023.103031). Explanatory comparator: **Original Software Publication**. | detectEr synthesizes and instruments Erlang monitors for data-carrying events. Token-server examples connect formulas, execution and verdicts. §3.4 attributes synthetic-overhead and third-party server evidence to earlier studies; these are not fresh experiments in this article. | The inspected article provides no dedicated limitations/future-work section. §4 closes on the demonstrated tool and examples; application evidence is partly attributed to cited studies. No unreported limitation is attributed to its authors. | [S8]: publication-type label and metadata p.1; formalism/architecture/examples §§1–3, pp.1–6; evidence attribution/conclusion §3.4/§4, p.7. |

### Corrections to the inherited benchmark

The inherited `Published_Article_Benchmark.md` correctly identified the core mechanisms and useful explanatory sequence. Retain those findings. Two details require correction in the new evidence record:

1. The detectEr first page labels it an Original Software Publication. Its short length and evidence presentation must not be used to infer the Research Papers Track's minimum scientific bar.
2. Stemmer et al. include a third case-study subsection, §6.3, on in-vehicle monitoring. The prior account of the stopping and bus-stop examples remains valid; its enumeration was incomplete.

## Editorial-bar comparison

The main research comparators organize their contribution around a precise relation between observations, an executable formal mechanism and its outputs. Their evidence follows the claimed capability. Their shared practice supports the following manuscript-specific criteria; it does not imply a universal sample-size or industrial-deployment requirement.

| Editorial function / bar | Paper 7 evidence and assessment | Action |
|---|---|---|
| Consequential, intelligible problem | Introduction lines 29–35 distinguishes an active review episode from the warning shown, then demonstrates obsolete authorization in a concrete trace. The consequence is visible before formal notation. | Retain. |
| Exact relation to established capability | Related work lines 65–87 attributes output-preserving abstraction, event processing, explanation and versioned evidence. §4 explicitly identifies the provenance of Propositions 1–2. | Keep the general principles attributed; let the closest-work agent resolve any additional primary predecessor. |
| Formal result that answers the question | Propositions 3–4, lines 194–212, establish sufficiency for the stated outputs and exhibit a reason collision under the joint encoding. The claims are sufficiency and a concrete loss of distinction. | Retain this exact claim. Do not convert the two interfaces into a minimality or general optimality claim. |
| Executable mapping from inputs to decisions | §3 specifies packet presence, version comparisons, timing, reset order, validity and reason precedence. The same contract has incremental, reference, SQL and PyContract encodings. | Retain explicit assumptions and order; these make the formal result inspectable. |
| Evaluation endpoint matches the scientific claim | §5 defines complete decision tuples separately from intervals; §6.2 reports 30 changed complete base sequences with all 987 episode sequences preserved for the suppression ablation. | Retain the full endpoint comparison and the constructed witness. These establish the design/testing consequence. |
| Claim-specific evidence | Proofs support the representation result; controlled traces characterize mechanism behavior; alternate executions check conformance. | Preserve these evidential roles. There is no target-scope basis for requiring an unrelated industrial effectiveness trial. |
| Clear interpretation | Discussion lines 357–363 connects observation authority, suppression authority and choice of receiving interface. | Retain. The paper's practical lesson is an interface and acceptance-test decision. |

### Material scientific publication risk

The live editorial risk is the significance of the **specified-instance result**. The formal sufficiency argument directly follows the comparisons used by the contract; an editor must see what the compositional lifecycle and the decision/reason distinction add to the already established abstraction principle. The current manuscript provides that answer through the explicit collision and the display/interval divergence. This is a risk about the intellectual weight of the stated contribution, not an identified false theorem or a missing venue-mandated experiment.

Required editorial action: preserve the narrow positive contribution and the mechanism-to-endpoint argument in the abstract, introduction and conclusion. If the independent novelty pass identifies an earlier derivation of the same composed result, reconcile that primary evidence before finalizing G2. This venue pass found no scientific reason to replace the study with a broader application trial.

## Closest alternative

**Formal Aspects of Computing (FAC): FIT as the closest alternative by scientific genre.** Its current BCS owner page welcomes contributions joining theory and practice, including applications of existing formalisms that reveal something novel about the approach or application [S9, lines 144–151]. The manuscript's formalized software contract and proved output distinction fit that description. This selection is an editorial inference from the completed contribution and verified scope.

STTT is a neighboring option; its current official editorial site emphasizes tools applied to realistic systems and surrounding development workflows [S11, lines 18–22]. FAC is the closer alternative for the present representation-centered result. FAC's ACM author-guide route returned 403, so no alternative-journal formatting requirements are asserted. SCP remains the primary target.

## Handoff finding register

| Finding | Primary evidence/location | Interpretation | Severity | Required action | Access boundary |
|---|---|---|---|---|---|
| Primary target FIT | [S1], lines 94–124; baseline §§3–6 | Applied formal techniques with executable evidence are within Research Papers Track. | PASS: G1 scientific fit | Keep SCP as primary target. | Official publisher scope accessible; current SCP guide blocked. |
| Correct article genre | Baseline propositions, complete tuple endpoint and replay design | Completed contract/representation research. | PASS | Select Research Papers Track; retain contribution-oriented description. | Submission-system live article-type menu not inspected. |
| detectEr comparator has different track | [S8], p.1, explicit OSP label | Useful explanation example; not Research Papers evidence-scale precedent. | MINOR benchmark correction | Correct benchmark role only. | Version of record opened and downloaded. |
| Stemmer benchmark omitted third example | [S7], §6.3 p.13 | Prior summary incomplete, core interpretation retained. | MINOR benchmark correction | Add sensor-aware construction example. | Version of record opened and downloaded. |
| Significance needs contract-specific framing | Baseline §4, especially Propositions 3–4; §§6.1–6.2 and §7 | The new object is the composed policy's output-dependent interface and endpoint consequence. | MODERATE editorial risk, no demonstrated blocker | Preserve precise claim; reconcile novelty-pass sources. | Bounded venue benchmark does not substitute for closest-prior-work audit. |
| Closest alternative FAC | [S9], lines 144–151; [S11], lines 18–22 | FAC matches the present formal application more directly than a tool-transfer emphasis. | PASS: alternative identified | Retain as alternate target. | FAC instructions blocked; scope verified. |
| Current formatting checks remain open | Access log in companion record | An administrative verification gap. | NOT VERIFIED: G1 format | Recheck current guide at submission; preserve known working values without asserting current compliance. | Four reasonable official guide routes failed; no access-control bypass attempted. |

## Limitations and author-reported boundaries

The manuscript explicitly reports that the review policy and temporal histories are constructed; the five source families reuse 329 templates; held-out evaluation concerns family-instance conformance; and upstream lexical finding accuracy and relevant-evidence equivalence are separate inputs. The alternate executions reuse the frozen traces retrospectively. The external suppression projection covers four specified assertions; the upstream Alertmanager program was not executed. External-policy validation, operational effects, human-review effects and deployed reliability remain unmeasured. These are the author's existing boundaries in baseline lines 369–373, and they remain intact.

This venue report verifies journal scope, genre and the stated bounded benchmark. It does not independently rerun protected experiments or replace the novelty/method/production agents' gates. Current journal-specific formatting and the author-only disclosure facts remain recorded in `Venue_Requirements_and_Access_Ledger.md`.

**Venue handoff outcome:** scientific fit PASS; current journal-specific format NOT VERIFIED; no new scientific experiment required by the venue evidence; two inherited benchmark details corrected. The Chief Editor decides final G1–G12 and completion status.
