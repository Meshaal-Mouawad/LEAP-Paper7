# Paper 7: final source-bound production review

**G8 PASS. G10 PASS.** The final 16-file source archive compiles independently
to a 21-page PDF. All 21 pages were visually inspected. The independent build
and the delivered PDF have identical page text and identical rendered pixels
on every page at 130 dpi. No production correction is required.

Date: 18 November 2026. Reviewer: specialist F, figures, LaTeX and
reproducibility. The review covers the exact identities below and supersedes
the pending final-build rows in the earlier figure-provenance review.

## Final identities

| Object | SHA-256 |
|---|---|
| `LEAP_Paper7_Gold_LaTeX_20261118.zip` | `ff39f32c1da75f2489f78002d509d38ba4b56c3d5969ae20be8ff235f021e158` |
| `Paper7.tex`, extracted from that archive | `648c1113570430b4ec93bb8906f6503389d6693ea59eb16f4ba44ea2f0076dd9` |
| Delivered `LEAP_Paper7_Gold_Revision_20261118.pdf` | `bc317232943a13a9426f3b5c216e2c7a40488c62ff42cf82b73423c330d7f665` |
| Independently rebuilt `Paper7.pdf` | `7a10b2b00a0c84658b47acba478816ee7b62361616d8ce67459a2fd6a9f22bb4` |
| Preserved research reproduction ZIP | `b55949d177b3355bda1f49442015141ac382e84345b4cc283a7fc4a811a9db48` |

Both manuscript PDFs are 488,011 bytes and 21 pages. The differing whole-file
hashes are recorded explicitly. Page-text equality and raster equality were
checked separately and passed on all 21 pages.

## Archive and build

The source ZIP contains 16 unique, flat entries with safe relative paths and
no symbolic-link entries. CRC verification passed. `SHA256SUMS` covers all 15
payload files and every listed digest matches. The archive includes the main
source, bibliography database and generated BBL, `elsarticle.cls`,
`unsrtnat.bst`, all three PDF/SVG figure pairs, figure reproduction script,
data CSV and build/reproduction instructions.

The archive was extracted into the new isolated directory
`final_source_check/source/`. The build command was:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error Paper7.tex
```

The initial default-environment attempt stopped before reading the manuscript
because this container lacks a default `pdflatex.fmt`. The configured build
used the same installed TeX system and copied the previously documented format
and font-map files into this review's own environment directory. The exact
environment variables and the two environment-file hashes are retained in
`final_source_check/Build_Execution.json`. The successful build exited 0 using
latexmk 4.86, pdfTeX 1.40.26, TeX Live 2025/dev/Debian and elsarticle 3.4.

All 16 archive input files remained byte-identical after the independent build.
This includes the supplied bibliography output and all retained figure assets.
The successful run is in `final_source_check/BUILD.log`; the initial environment
diagnostic is separately retained as `BUILD_DEFAULT_ENV.log`.

### Log and reference checks

The final LaTeX log contains zero undefined references, zero undefined
citations, zero missing-character reports, zero overfull boxes and zero fatal
errors. There are 15 underfull-box notices. Their affected tables and
bibliographic material were included in the full visual reading; no text is
lost or overlaps. Latexmk also prints its known auxiliary-file UTF-8 advisory
for Sánchez. The name renders correctly on page 20.

The manuscript cites 28 distinct keys. The bibliography has the same 28 keys,
and all 28 resolve in the compiled bibliography. The check recognizes the
optional citation argument used for Smith's Definition 3. The two numbered
equations render on pages 8 and 9. The four propositions and their proofs are
complete and legible on pages 9-11.

The PDF metadata carries the manuscript's full title and Meshaal Obaid Mouawad
as author. The file is unencrypted, has no JavaScript or forms, and uses letter
pages (612 x 792 pt). All fonts listed by `pdffonts` are embedded. The retained
witness artwork has an embedded Type 3 font; its displayed labels were
visually inspected and read correctly.

## All-page visual inspection

The delivered PDF was rasterized with Poppler at 130 dpi. Every page was opened
and read at its final page layout. The independent build was rasterized with
the same command; an exact RGB-pixel comparison passed for every corresponding
page. The images and comparison record are retained under
`final_source_check/`.

| Page | Inspected content | Outcome |
|---:|---|---|
| 1 | Title, author/affiliation, abstract, keywords, first introduction paragraphs and author footnote | PASS; all text fits, with a clear title and footnote. |
| 2 | Introduction, questions/contributions and opening background | PASS; paragraph and section breaks remain clear. |
| 3 | Table 1, abstraction literature and temporal-monitoring heading | PASS; full table width and labels are readable. |
| 4 | Temporal monitoring, explanations and versioned-evidence literature | PASS; citations and paragraph flow are intact. |
| 5 | Final related-work paragraphs and first part of Table 2 | PASS; three columns fit; continuation notice is clear. |
| 6 | Continued Table 2 and beginning of the review contract | PASS; table number/header repeat; all five continued rows fit. |
| 7 | Figure 1, expanded caption and transition subsection | PASS; all boxes/connectors, strict expiry and output labels are legible; caption fits. |
| 8 | Decision/reason discussion and Equation 1 | PASS; case brace, operators, conditions and equation number are intact. |
| 9 | Formal definitions, Propositions 1-2, Equation 2 and witness callout | PASS; proof endpoints and formula are complete; the callout precedes Figure 2. |
| 10 | Figure 2, expanded caption, witness description and Proposition 3 | PASS; eight state labels/four times are clear; caption and proof are complete. |
| 11 | Proposition 4 and benchmark design | PASS; proof, subscripts and design arithmetic render correctly. |
| 12 | Table 3, boundary/partition account and reference protocol | PASS; all eleven intervention rows and their extents are readable. |
| 13 | AI/code and figure methods, endpoint definitions and SQL procedure | PASS; reproducibility text and inline metric fit. |
| 14 | Pinned PyContract/fixture details and first results | PASS; long commit/blob identities remain inside the text width. |
| 15 | Representation results, Table 4 and decision/episode findings | PASS; Table 4 follows its complete callout and retains aligned columns. |
| 16 | Figure 3, Table 5, invariance and reference checks | PASS; ten data marks/labels, axis denominator, legend and both captions are clear. |
| 17 | Concurrent checks, SQLite/PyContract results and Discussion opening | PASS; emphasized counts and wrapped retained case path are readable. |
| 18 | Discussion, Conclusion and consolidated Limitations | PASS; section hierarchy and complete paragraphs are intact. |
| 19 | Research materials, AI declaration and references 1-7 | PASS; responsibility sentence is exact; links and DOI wraps fit. |
| 20 | References 8-18 | PASS; names, accents, titles and URLs are readable. |
| 21 | References 18-28, including long pinned source references | PASS; source paths, commit/blob hashes, licenses and access dates fit. |

## Figure grounding and preservation

Figure 1 is a mechanistic schematic on page 7; its diagram and caption state
the active-episode guard, both version matches and strict expiry. The inspected
contract and monitor source establish the processing order. Figure 2 is the
constructed `privacy/o.c` witness on page 10; all eight state labels and four
times match its frozen record. Figure 3 is on page 16; all ten data labels and
coordinates match the independent arithmetic from saved predictions and
references for the 987 held-out base traces.

The preceding executed figure audit established those results and exported the
unchanged SVGs with Inkscape 1.4. The lead retained the approved PDF figure
assets in the final manuscript. The source ZIP supplies the same SVGs and the
executed verification/export program. This final pass confirms that those
assets remain legible when placed in the article.

The root editor's protected-content comparison is reused for the four exact
proposition/proof blocks, two protected equations, unchanged abstract and four
protected table bodies. It applies to the same final source hash shown above.
This reviewer independently checked the archive identities, unchanged input
files, final figure artwork, citations and rendered output.

## Final gate decisions

| Gate | Decision | Direct evidence |
|---|---|---|
| G8: explanatory, grounded, labeled and readable visuals | PASS | Frozen figure-data checks; all three final figure pages inspected; table and equation layouts checked. |
| G9: figure assets, package inputs and archive identities | PASS within this review's scope | All 16 source-package inputs unchanged; accepted SVGs preserved; locked research archive hash verified. Root's source-content preservation check is separately retained. |
| G10: source/PDF/reference/package production | PASS | Independent isolated build; 16-entry manifest/CRC check; 28 resolved citation keys; every final page inspected; exact 21-page text/raster agreement. |
| G12: production closure | PASS within this review's scope | No unresolved figure, LaTeX, reference-resolution or packaging defect found. |

## Retained administration item

Exact historical AI model builds remain unavailable in the archived activity
records. Their absence and the publisher-policy interpretation remain in the
external provenance/administration register. The retained Matplotlib version
identifies the vector renderer; it does not identify an AI model version. This
final production review makes no unrecorded affirmation of the author's
personal final review.
