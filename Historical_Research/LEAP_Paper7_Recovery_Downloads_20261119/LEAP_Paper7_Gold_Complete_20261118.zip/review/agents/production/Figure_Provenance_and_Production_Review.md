# Paper 7: figure provenance and production review

Date: 18 November 2026. Reviewer: specialist F, figures, LaTeX and reproducibility.
Scope: the Gold Niche working source, three retained SVGs, frozen reproduction
archive, historical activity records and the current publisher policy. The lead
editor owns manuscript integration. This report is an editorial evidence record.

## Finding

The retained artwork is reproducible from its editable SVG sources. The new
`reproduce_figures.py` successfully recalculated Figure 3's ten plotted values
from frozen per-trace outputs, verified the data labels and x-coordinates,
verified Figure 2's states and timestamps against its frozen witness, and
exported all three SVGs through Inkscape 1.4. The scored study was not executed.
All three resulting figure previews were visually inspected and passed.

The manuscript needs a short disclosure of figure preparation and verification
code, the data-to-plot procedure, and the recorded rendering tools. Preserve the
approved final sentence: **The author takes responsibility for the content of
the article.**

## Evidence and figure roles

Paths in this section are relative to `research/paper7_risk_alarm/`.

| Figure | Kind and reader question | Primary evidence | Current source check |
|---|---|---|---|
| 1, `method_pipeline` | Mechanistic schematic: in what order does an event become a displayed decision? | Locked archive `Paper7_Reproduction/study/protocol/SEMANTICS.md`, Transition order 1-6; `study/implementation/monitor.py`, `validate()` and `monitor()` | The diagram follows validation, reset, observation validity, activity update, display and eligible suppression. It includes the active guard, both version matches, strict expiry and all four outputs. |
| 2, `necessity_witness` | Constructed analytical witness: how can identical projected input require different decisions? | Locked archive `study/benchmark/witness_references.json`, record `privacy/o.c`; `study/benchmark/necessity_witnesses.json` | All eight displayed states and four timestamps match the frozen record. Deleting `o.c` makes the paired event inputs identical. |
| 3, `trace_mismatches` | Data visualization: do complete decisions and active intervals expose the same discrepancies? | Locked archive `study/benchmark/traces.jsonl`, `reference.jsonl`, `saved_run/results/predictions.jsonl`; cross-check against `analysis/endpoint_metrics.csv` | Select `split=heldout`, `variant=base`; compare saved state/activity/severity sequences and active-interval lists. All ten labels and linear x positions match the recalculated counts. |

### Verified Figure 3 values

Each row uses the same 987 held-out base traces and 5,286 supplied events.

| Method | Complete-decision mismatches | Active-interval mismatches |
|---|---:|---:|
| Full monitor | 0 | 0 |
| Timers only | 90 | 60 |
| Ignore observation version | 30 | 18 |
| Ignore suppression version | 30 | 0 |
| Remove stale-age check | 18 | 12 |

The current script compares complete sequences of `(state, active, severity)`.
An active interval is a maximal run of true activity over zero-based event
positions with an exclusive end; a run open at trace termination ends at the
trace length. Every saved prediction for the five plotted methods is present
once for each selected trace. The new counts also equal 987 minus the archived
agreement counts. No error bar or inferential statistic is introduced.

## Tool and asset provenance

All three original SVG metadata blocks identify **Matplotlib v3.10.8**. The
original locations are `current/r3/visual/method_pipeline.svg`,
`current/figures/necessity_witness.svg`, and
`current/scp_revision/figures/trace_mismatches.svg`. Their date metadata are
18 November 2026, at 20:01:56, 18:49:21 and 19:45:17 respectively. Those embedded
timestamps are source metadata, not an independent runtime clock audit.

The prompt-suite records establish the later SVG edits. In
`manuscript_suite_20261118/agents/evidence/Figure_blueprints.md`, Asset evidence,
Figure 1 received exact policy labels and Figure 3 received the stale-age label.
Figure 2 remained byte-identical. The accompanying `figure_asset_integrity.json`
records unchanged shape attributes, ordering and canvases. The current Gold SVGs
have the same hashes as those accepted candidates:

| SVG | SHA-256 |
|---|---|
| `method_pipeline.svg` | `dd5978656fc06915a9a0b8bd344275dc1a7950cc42c419a15e7d193502ec67aa` |
| `necessity_witness.svg` | `403ee2a1507fc14f5474f271f72480a9e81cbdb8103523ee0bd9e3f2bc3f202e` |
| `trace_mismatches.svg` | `49c8770675aa1ea03b4302cb0e5d47ba9dbf0a64c7319386d1bc459af9bd2c5b` |

Each SVG consists of vector primitives and text, with no embedded raster image.
The lead's task record states that no image-generation tool was used. The
current verification and export script was prepared with OpenAI ChatGPT/Codex
assistance and is retained beside this report. Its actual exporter is
**Inkscape 1.4 (e7c3feb100, 2024-10-09)**, running under Python 3.12.14.

The historic `build_witnesses.py` constructs witness JSON. The retained
`representation.py` encodes and decodes comparison packets, replays the monitor,
and prints counts. Neither file renders artwork. A bounded search of the 379
`.py` and `.sh` files present before this audit found no retained original
Matplotlib figure-generation script. The current reproducibility path therefore
uses the retained SVG as the drawing source.

### AI records inspected

| Record | Established facts |
|---|---|
| `current/logs/AI_ACTIVITY_RECORD.json` | System recorded as ChatGPT Work / Codex; research and reference tasks; deterministic Python scoring; separate AI sessions with instruction-based separation. |
| `revision_20261118/package_stage/LEAP_Paper7_Revision_20261118/provenance/AI_ACTIVITY_REVISION_20261118.json` | Strict-review task used ChatGPT/Codex and deterministic programs; assigned agents named `gpt-6.2-astra` and `gpt-6.2-sol`; high reasoning effort. These are revision-task assignments. |
| `manuscript_suite_20261118/package/LEAP_Paper7_Prompt_Suite_20261118/provenance/AI_ACTIVITY_PROMPT_SUITE_20261118.json` | Manuscript reorganization, source checks, figure-label corrections, source preservation, page inspection and packaging; no experiment rerun in that phase. |

## Current publisher policy and interpretation

Verified on 18 November 2026 at the official [Elsevier generative AI policy](https://www.elsevier.com/about/policies-and-standards/generative-ai-policies-for-journals), updated June 2026. Relevant locations: For authors, Disclosure; Explanatory images; Data visualizations; Use of AI tools in research methods; FAQ, AI-assisted writing of code.

The policy places research-code assistance and reproducible data-visualization
methods in Methods. It requests tool, version and use for explanatory-image
captions, together with the general AI declaration. The general declaration
names the tool and purpose and describes oversight. These are administrative
requirements separate from validation of the plotted data.

**Recorded interpretation:** the policy does not expressly distinguish
AI-assisted code that renders ordinary SVG/vector graphics from direct
generative-image output. Apply the disclosure to the actual assistance with
figure preparation and verification code. Identify the deterministic renderer
separately. Do not describe the scientific drawing as a directly generated
bitmap, and do not present a renderer version as an AI model version.

## Exact integration recommendations

### Methods: research assistance and visualization procedure

The lead should adapt the following compact text to the existing workflow
paragraph, with the data-visualization sentences after the endpoint definitions:

> OpenAI ChatGPT and Codex assisted with source recovery, implementation,
> reference construction, experiment orchestration, analysis and figure
> preparation code. Deterministic programs produced the scored decisions.
> Figure 3 plots the counts of held-out base traces whose complete decision
> sequences or active-interval lists differ from the frozen reference. The
> accompanying figure script recomputes those counts from saved outputs and
> verifies their SVG labels and coordinates. The retained vector artwork records
> Matplotlib 3.10.8; the reproducibility script exports it with Inkscape 1.4.

This accurately identifies the current source-to-render path and the underlying
data. The source trace and reference locations remain in the script and record.

### Explanatory captions: Figures 1 and 2

Append one short provenance sentence without changing either scientific caption:

> Figure preparation and verification code used OpenAI ChatGPT/Codex assistance;
> the vector source records Matplotlib 3.10.8.

The OpenAI tools are identified as code assistance. Matplotlib is identified as
the recorded vector renderer. The historically unavailable AI version belongs
in the retained provenance record and the submission administration check below.
Figure 3's computational method and disclosure belong in Methods.

### General declaration

> During preparation of this work, the author used OpenAI ChatGPT and Codex for
> manuscript drafting, editorial review, and figure preparation and verification
> code. The author takes responsibility for the content of the article.

This preserves the approved responsibility sentence and adds the demonstrated
purpose. It does not assert an unrecorded personal author review. Any separate
publisher-requested affirmation of personal review remains the author's
submission declaration.

## Current reproducibility command and outcome

From this review directory, or after packaging the script and artwork, run:

```sh
python reproduce_figures.py \
  --archive /path/to/LEAP_Paper7_Reproduction_20261118.zip \
  --svg-dir /path/to/figures \
  --output-dir /path/to/figure-reproduction \
  --previews
```

Actual run: exit 0, **PASS**. Outputs are in `figure_reproduction/`:
three PDFs, three PNG previews, `Figure3_Data.csv`, and
`Figure_Data_and_Render_Verification.json`. The JSON includes the archive hash,
entry count, source-entry hashes, SVG hashes, per-point coordinates, exporter
version, commands, PDF hashes and PDF dimensions. The archive hash remains
`b55949d177b3355bda1f49442015141ac382e84345b4cc283a7fc4a811a9db48`
with 188 entries and successful CRC verification.

The three exported PDFs preserve their SVG page canvases. All three previews
show intact labels, distinct markers, readable text and unobstructed connectors.
The original PDF figures can remain in the manuscript: the independent export
demonstrates the retained SVG reproduction route. Replacing them with the newly
exported PDFs is a production choice, not a scientific correction.

## Prior build evidence and final-pass status

**Final closure:** the integrated source ZIP was subsequently extracted and
compiled independently. All 21 final PDF pages passed visual inspection and
matched the independent build in page text and exact 130-dpi rendered pixels.
The source-bound evidence is in `Final_Production_Review.md` and
`final_source_check/PDF_and_Reference_Verification.json`. Final G8 and G10 are
PASS. The matrix below now includes that completed pass.

The inspected prior successful build is
`manuscript_suite_20261118/reports/PACKAGE_BUILD.log` (also copied in its package).
It records latexmk 4.86, pdfTeX 1.40.26, TeX Live 2025/dev/Debian,
LaTeX2e 2024-11-01 patch 2, elsarticle 3.4 and a 20-page PDF. The retained source
package supplies `elsarticle.cls`, `unsrtnat.bst`, bibliography and figure PDFs.
These records establish the prior build only.

| Gate/check | Present status | Evidence/action |
|---|---|---|
| G8, grounded figure content | PASS | Frozen contract/source; fresh raw-output arithmetic; all plotted labels and coordinates agree. |
| G8, standalone vector exports | PASS | Three Inkscape exports and visual inspection of all three PNGs. |
| G8, final manuscript layout size | PASS | All 21 pages inspected; Figures 1-3 legible on pages 7, 10 and 16. |
| G9, SVG and reproduction preservation | PASS | Current SVG hashes equal accepted assets; locked archive hash and CRC verified. |
| G10, figure reproduction path | PASS | Executed script, exact input hashes, renderer and generated outputs retained. |
| G10, final LaTeX ZIP and all PDF pages | PASS | Independent 16-file archive extraction/build; all 21 pages visually inspected and pixel-identical to the delivered PDF. |
| Historical AI model-version field | NOT VERIFIED | See limitations below; do not invent a version or transfer a later review-agent identity to the original figures. |

## Limitations and remaining administration

The original and prompt-suite activity records explicitly leave exact model
builds, temperature and seed unavailable. The strict-revision record supplies
some assigned model names for that revision, not the exact historical builds
used to create the figures or study. Those unavailable fields have not been
reconstructed. The original Matplotlib renderer script was not retained; the
current verified route uses the retained editable SVGs. The publisher's request
for an exact historical AI version remains a named submission-administration
check. A declaration of the author's personal final review must come from the
author; this review does not manufacture it. Final-layout and clean-source build
verification are complete for source SHA-256
`648c1113570430b4ec93bb8906f6503389d6693ea59eb16f4ba44ea2f0076dd9`.
