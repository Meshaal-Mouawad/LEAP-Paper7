# Paper 7: independent novelty and source verdict

**G2 Contribution: PASS. G5 Sources: PASS at the recorded claim-specific access levels.** The surviving contribution is a concrete causal representation result for the declared review lifecycle: three joint comparisons preserve the decision sequence; six separate comparisons suffice to preserve the prescribed reason sequence; an explicit collision shows that the joint encoding loses a distinction the reason requires. The contribution–evidence matrix contains direct proof or disclosed result for every retained claim.

Review date: **18 November 2026**. Reviewer role: independent literature/novelty agent. Root alone edits and integrates. The frozen baseline's complete LaTeX and all 20 pages of extracted PDF text were read. Its source, PDF and bibliography hashes remain identical to the identity brief; `Manuscript_Read_and_Preservation.json` records them. This review does not modify manuscript, experiments or protected outputs.

## 1. Decisive closest-work judgment

The output-specific representation contribution survives the inspected prior-work challenge. It survives as a **model-specific characterization of a composed temporal contract**. Its affirmative evidence is the transition-by-transition induction and the reason counterexample in Propositions 3–4, read against the policy in §3. The known general principle is that a retained representation must distinguish inputs whenever the required output distinguishes them. Henzinger et al., Jevitha et al., abstract TeSSLa and Antignac et al. establish different forms of that principle and its construction/verification machinery. The source ledger identifies their actual inputs, proofs, comparisons and author-stated limits.

What Paper 7 adds is the exact relation between its chosen applicability semantics and two output interfaces. A current context change and a current policy change have the same reset effect on the decision tuple. An obsolete observation context and an obsolete observation policy have the same unresolved decision effect. Suppression depends on the conjunction of the two matches and the expiry test. These facts allow three joint indicators to drive the state transitions causally. The specified diagnostic precedence preserves the distinction between context and policy causes, producing the explicit reason collision when those causes share one joint indicator. Six separate comparisons retain those causes and yield a straightforward induction over all admissible histories.

This is a direct analytical result. The 4,935-trace replay corroborates an implementation of the encodings; its success is not used to infer the universal preservation claim. The universal claim follows from the proof. The 585 changed reasons belong to the disclosed decoder. The pair of first events establishes why every decoder of that same joint interface cannot recover both prescribed reason labels.

The evaluated suppression-binding ablation adds a useful contract-level consequence: the same 987 held-out base episode sequences coexist with 30 changed complete decision sequences and 48 event-tuple errors. The comparison identifies a specific information loss that the episode endpoint misses. Alertmanager and the inspected code-scanning tools already separate suppression from retained finding information; those architectures are credited as predecessors.

## 2. What the bounded search changed

### Original preprocessing predecessor

Antignac, Sands and Schneider's 2017 original supplies the closer output-preserving preprocessing comparison. Definitions and ordering in §§3–4, together with the construction in §5, directly support the new short paragraph. Stucki et al. 2021 was the discovery route and explicitly attributes the formulation to Antignac. Root has independently read the original local PDF. The smallest justified repair is the original citation and connected comparison already supplied; no privacy claim is introduced.

### Implemented scoped-suppression predecessors

The bounded search verified two original repositories at pinned commits. skill-audit's source and original tests establish evidence/source/scanner-bound suppression with expiry and retained finding records. NVIDIA SkillSpector independently establishes exact source/scanner/evidence-bound baselines, including an explicit test of omitted-evidence collision and source/scanner drift. Exact fields, source locations, Git blob identities and access are preserved in the ledger and retrieval records. Their source/test semantics defeat any broad claim that revision-sensitive suppression or an omitted-evidence collision is a newly discovered mechanism.

The inspected source does not supply Paper 7's composed qualification, clearing, escalation, invalid-evidence and reset contract or the exact three/six-comparison result. Generic applicability checks in an implementation are evidence of prior capability; they do not by themselves prove that a particular compressed interface preserves every output of a different stateful contract. This is the exact logical distinction used in the G2 verdict.

Root's decision to cite skill-audit and retain NVIDIA SkillSpector in the discovery record is sufficient. A second near-duplicate manuscript paragraph would add little to the argument.

## 3. Source and comparison-table repairs

| Finding | Scientific/reader implication | Smallest repair | Verification status |
|---|---|---|---|
| Direct original preprocessing predecessor missing from the baseline comparison. | The relationship to established output-preserving input reduction was incomplete. | Add Antignac's original citation and brief comparison of fixed output functions. | Original full text checked; integrated paragraph inspected. |
| An implemented revision-sensitive suppression predecessor was absent. | The reader needs the actual operational capability before assessing the temporal representation contribution. | Add pinned skill-audit source comparison; retain SkillSpector as independently verified discovery evidence. | Original source and tests inspected; integrated paragraph inspected. |
| RTLola and Vamos shared one Table 2 row. | Monitor construction and event-delivery middleware are different mechanisms and outputs. | Give each its own source-grounded row. | Integrated rows inspected. |
| CauMon and WhyMon shared one row. | Causation semantics and certifying proof objects are distinct explanatory objects. | Give each its own row. | Integrated rows inspected; CauMon claim remains within preview-level evidence. |
| Audit-as-Code and Compliance-as-Code shared one row. | Assurance scoring/gates and release-bound completeness/provenance checks should remain distinguishable. | Give each its own row. | Publisher/author originals checked; integrated rows inspected. |

The exact approved replacement wording and BibTeX are preserved in `Table2_and_Targeted_Changes.md`. Root integrated the two new comparisons and separate rows. The targeted integrated-source inspection used SHA256 `648c1113570430b4ec93bb8906f6503389d6693ea59eb16f4ba44ea2f0076dd9`; root's later final-build identity is authoritative for delivery.

## 4. Claims to retain, and unsupported interpretations to reject

**Retain** the specified sufficient encodings, the joint-interface reason collision, the six separate projection experiments, and the complete-decision/episode discrepancy. Each has an explicit research operation and direct evidence. Retain Henzinger and Smith attribution for Propositions 1–2. Retain the distinction between causal preservation proofs and finite-corpus replay.

The following stronger interpretations would lack the necessary logical or evidential link; they are not needed in the manuscript:

| Stronger interpretation | Missing link | Smallest legitimate repair |
|---|---|---|
| Three comparisons or six comparisons are globally minimal. | No lower bound ranges over all allowed encodings; separate sufficiency and a particular projection collision do not supply one. | State sufficient encodings, as the current propositions do. |
| A raw version identifier must reach the downstream monitor. | Necessity witnesses remove the field and its comparison; the sufficiency results replace names with comparisons. | Describe required applicability distinctions and the permitted comparison interface. |
| The whole principle of output-dependent information preservation is new. | Direct original results in L1–L4 already establish it. | Attribute the principle and state the concrete contract result. |
| Version-bound evidence or revision-bound suppression is absent from existing systems. | L6, L8 and L9 implement those capabilities. | Credit their capabilities and locate the contribution in the analyzed lifecycle/interface. |
| Perfect episode agreement certifies displayed-decision correctness. | Paper 7 itself supplies 48 contrary event outputs under suppression-binding removal. | Score the complete decision tuple as well as the episode interval. |
| The internal/alternate implementations establish operational improvement. | No recorded organizational decisions or interventions are evaluated for that endpoint. | Keep their conclusion as conformance to the declared contract. |

No new application benchmark is required to establish the stated theoretical preservation claims. A later external-policy study would answer the separate empirical questions already assigned to the manuscript's Limitations section.

## 5. Gate evidence and closure

| Gate | Result | Evidence |
|---|---|---|
| **G2 — exact knowledge gap and supported contribution** | **PASS** | The specific causal interface and diagnostic distinction remain after the closest-work challenge; Propositions 3–4 prove them. The contribution matrix distinguishes inherited principles, present analysis and implementation corroboration. |
| **G5 — exact key source claims at stated access levels** | **PASS** | Original methods/results/author limits checked for the closest theoretical works; publisher/author full text checked for scoped-evidence works; two pinned operational alternatives inspected. All central sources have ten-field entries. Added claims and split table rows match inspected sources. |
| Full-text methods/results/author limits for the exact 2026 RTLola and CauMon journal papers | **NOT VERIFIED** | Available exact-journal preview/abstract supports only the mechanism descriptions used. The manuscript makes no detailed evaluation claim from inaccessible material. |
| Final integrated PDF identity and visual production | Assigned to root/production | This report records targeted integrated source inspection. It does not replace root's final source/PDF and layout checks. |

Required local deliverables are complete: `Source_Ledger.md`, `Closest_Work_and_Contribution_Matrices.md`, `Search_and_Access_Log.md`, `Table2_and_Targeted_Changes.md`, and the preservation record. Primary downloaded sources and pinned code remain in `sources/` with retrieval manifests.

## Limitations

The search was bounded and purposive; it does not establish universal historical priority. Source access levels are explicit. Original repository tests were inspected and were not run by this review. Detailed experiment reproduction is the methods agent's assignment. The baseline supplies a constructed review policy and corpus, so the present verdict concerns its formal contract and representation evidence. It does not assign an acceptance probability or treat the venue benchmark as proof of novelty.
