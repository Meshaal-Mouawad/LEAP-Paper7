# Targeted source and comparison repairs

18 November 2026. Independent novelty review. Baseline manuscript is read-only; the lead editor alone integrates changes.

## Table 2: separate the six existing works

The three combined rows obscure different operations and evidential objects. Gold §7 requires comparing individual pivotal studies when their mechanisms differ. Retain the table's three columns and replace each combined row with its two rows below. All other rows can remain.

| Approach | Input and established operation | Decision or evidential object |
|---|---|---|
| RTLola `baumeister2026rtlola` | Stream specifications and asynchronous inputs; derived streams, static analyses and executable monitor construction. | Stream values and Boolean notification triggers. |
| Vamos `chalupa2025vamos` | Heterogeneous event sources; preprocessing, buffering and explicit gaps or summaries when observations are lost. | Events and loss information supplied to downstream monitors. |
| CauMon `zhang2026caumon` | Signal traces and temporal requirements; online monitoring with causation semantics. | A verdict that identifies the relevance of incoming observations to satisfaction or violation. |
| WhyMon `lima2024explainable` | Metric first-order temporal requirements and event traces; proof-tree construction with a verified checker. | Explanations certifying satisfaction or violation. |
| Audit-as-Code `muhammad2026audit` | Versioned policy and schema-checked evidence bundles; deterministic assurance gates. | Pass/warn/block decisions with policy-linked evidence. |
| Compliance-as-Code `nwekeyeng2026compliance` | Control, release, environment and time-bound evidence; provenance and fixed-window completeness checks. | Evidence-linked findings and machine-readable assessment artifacts. |

Evidence: exact journal abstract/preview for RTLola and CauMon, as recorded in `manuscript_suite_20261118/reports/Bibliography_and_Claim_Audit.md`; Vamos full version of record §§3.3–3.4; WhyMon original TACAS chapter, abstract and explanation/checker construction; Muhammad et al. original publisher text §§3–4; Nweke and Yeng author-uploaded version of record §§IV–V. Access levels remain separate in the source ledger. No row makes a numerical performance claim.

## Direct predecessor for output-preserving preprocessing

Insert a short connected comparison in §2.2, adjacent to the existing abstraction discussion:

> Antignac et al. formalize a data preprocessor that preserves a program's output and give a procedure for constructing such preprocessors. Their ordering compares the input distinctions retained for a fixed output function. Here, the two output functions are the event decision and that decision with its prescribed reason; Propositions 3 and 4 establish concrete comparison encodings for the review lifecycle.

Attach `antignac2017minimisation` to the first or second sentence. The first two sentences are supported by Definitions 3 and 6, Proposition 2 and §5 of the complete author proceedings manuscript. The last sentence is the present comparison, directly supported by Paper7's definitions and proofs. This addition attributes a closer input-preprocessing predecessor and does not assert a privacy result.

```bibtex
@inproceedings{antignac2017minimisation,
  author = {Antignac, Thibaud and Sands, David and Schneider, Gerardo},
  title = {Data Minimisation: A Language-Based Approach},
  booktitle = {ICT Systems Security and Privacy Protection},
  series = {IFIP Advances in Information and Communication Technology},
  volume = {502},
  pages = {442--456},
  publisher = {Springer},
  year = {2017},
  doi = {10.1007/978-3-319-58469-0_30},
  url = {https://www.cse.chalmers.se/~gersch/ifip-sec17-data_min.pdf}
}
```

The journal paper by Stucki, Sánchez, Schneider and Bonakdarpour (2021), DOI `10.1007/s10703-020-00358-w`, supplied the discovery route and explicitly attributes this formulation to Antignac et al. Its Minion implementation checks distributed data minimality. Citing the original Antignac paper is the smaller and more direct repair.

## Direct implemented suppression precedent

The inspected `skill-audit` source at commit `e2e9ad679b8a0459bbb4bfad39621435aa354002` computes a finding fingerprint from scanner version, analyzer, rule identifier, path, source digest, evidence and optional source location. `applySuppressions` uses exact fingerprint equality and expiry; it retains findings and annotates matched suppressions. The source tests include dimension changes, changed-evidence reactivation, expiration, retention in reports and policy/score separation. This is a direct predecessor for revision-sensitive exception applicability.

Suggested concise addition to §2.4 after the Alertmanager explanation:

> Version-sensitive exceptions also occur in analysis tools. The `skill-audit` implementation binds a suppression to a fingerprint of the source, evidence, rule and scanner version; a changed fingerprint reactivates the finding. Its reports retain the finding and record the suppression separately. These mechanisms establish revision-scoped exception handling. The present analysis determines which comparisons preserve the complete temporal decision and its specified reason.

Attach a pinned repository citation to the first two or three sentences. Exact source: `skill-audit/src/suppress.ts`, lines 18–42 and 164–217; original tests in `skill-audit/src/suppress.test.ts`, `findingFingerprint`, `applySuppressions` and `scanSkill suppressions integration` groups. Source and tests have been read, with matching Git blob hashes recorded in `sources/skill_audit/retrieval.json`. No upstream test execution is claimed.

```bibtex
@misc{skillaudit2026suppression,
  author = {{skill-audit contributors}},
  title = {Finding Fingerprints and Governed Suppressions},
  year = {2026},
  howpublished = {skill-audit source repository},
  note = {Commit e2e9ad679b8a0459bbb4bfad39621435aa354002; accessed 18 November 2026},
  url = {https://github.com/harrypham2000/skill-audit/blob/e2e9ad679b8a0459bbb4bfad39621435aa354002/skill-audit/src/suppress.ts}
}
```

Scientific effect: these targeted additions credit the stronger predecessors exposed by the bounded search. They leave the contract-specific proofs, counterexample and frozen outputs intact. The representation claim rests on those proofs, not on a claim that previous tools lack suppression binding.
