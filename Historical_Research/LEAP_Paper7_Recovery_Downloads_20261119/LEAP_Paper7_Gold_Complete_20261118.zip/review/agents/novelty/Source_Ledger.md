# Paper 7: source-level novelty ledger

Review date: **18 November 2026**. Baseline: `gold_niche_20261118/baseline/Paper7.tex` and its 20-page PDF. This ledger separates original authors' statements (field 6) from this reviewer's appraisal (field 7). “Complete text available; inspected sections” identifies actual access and reading more accurately than claiming every line was read. Local filenames below are relative to this directory. Original-file hashes and retrieval URLs are in `sources/retrieval_log.json`; repository blobs and hashes are in the two repository retrieval records. Reused checks are explicitly identified.

## L1 — Henzinger, Mazzocchi and Saraç: abstract monitors

1. **Identity:** Thomas A. Henzinger, Nicolas Mazzocchi, N. Ege Saraç. *Abstract Monitors for Quantitative Specifications*. RV 2022, LNCS 13498, 200–220. [DOI](https://doi.org/10.1007/978-3-031-17196-3_11).
2. **Question:** How monitor precision trades against abstract monitor size.
3. **Inputs/method:** Quantitative specifications on words; right-monotonic prefix equivalence, class outputs, finite-prefix and limiting errors.
4. **Finding:** Exact and approximate monitor characterizations; Proposition 6 bounds value separation for prefixes sharing a class.
5. **Evaluation:** Definitions, proofs and worked specification examples; monitor-class comparisons.
6. **Authors' limits/future:** Concrete monitor construction, richer cost models including register-operation cost, alternative errors and resource reclamation (§5).
7. **Reviewer appraisal:** Establishes the general indistinguishability foundation. Paper 7's Proposition 1 is correctly an application. Its concrete causal encodings require separate analysis of the chosen transition rules.
8. **Location:** §§2.1–2.3, Proposition 6 (p. 205), §3, §5 (pp. 215–216).
9. **Access:** Complete proceedings PDF retrieved; main text including methods, proofs, examples and conclusion inspected. `sources/henzinger2022.pdf`, `.txt`.
10. **Role:** Central comparison; theoretical foundation.

## L2 — Jevitha, Jayaraman and Sethumadhavan: execution abstraction

1. **Identity:** K. P. Jevitha, Bharat Jayaraman, M. Sethumadhavan. *Runtime Verification on Abstract Finite State Models*. JSS 216 (2024), 112138. [DOI](https://doi.org/10.1016/j.jss.2024.112138); [author text](https://arxiv.org/html/2406.12715v1).
2. **Question:** Reduce finite execution models while retaining temporal-property checks.
3. **Inputs/method:** Instrumented Java executions, key attributes, user-specified data abstractions and path/state abstraction.
4. **Finding:** Property-preserving constructions and model reductions; construction/checking costs vary by abstraction and example.
5. **Evaluation:** Benchmarks including drone and OAuth examples; state counts and construction/verification time in Tables 2–3.
6. **Authors' limits/future:** Informal correctness argument, observed finite runs, abstraction choices and traversal costs; future C/C++ instrumentation, visualization and distributed monitoring (§§5.3, 7).
7. **Reviewer appraisal:** Property-specific abstraction is established. A finite execution graph/property checker supplies a different output interface from Paper 7's event-by-event decision and diagnostic sequence.
8. **Location:** §§3–6; Algorithms 4–6; Tables 2–3; §7.
9. **Access:** Complete author-version HTML retrieved; relevant model, abstraction, evaluation and conclusion sections inspected. Exact publisher version not newly obtained. `sources/jevitha2024.html`, `.txt`.
10. **Role:** Central comparison.

## L3 — Antignac, Sands and Schneider: output-preserving preprocessing

1. **Identity:** Thibaud Antignac, David Sands, Gerardo Schneider. *Data Minimisation: A Language-Based Approach*. IFIP SEC 2017, IFIP AICT 502, 442–456. [DOI](https://doi.org/10.1007/978-3-319-58469-0_30); [author proceedings PDF](https://www.cse.chalmers.se/~gersch/ifip-sec17-data_min.pdf).
2. **Question:** Retain only input distinctions needed for a program's output.
3. **Inputs/method:** Program and preprocessing functions; output preservation and idempotence; kernel-based disclosure ordering; symbolic execution and solver construction.
4. **Finding:** Monolithic/distributed minimizer definitions and best-minimizer results; DataMin construction procedure.
5. **Evaluation:** Formal results and small Java examples using KeY, Z3 and generated preprocessors.
6. **Authors' limits/future:** General best minimization is uncomputable; construction is a semi-procedure, with loop invariants, library specifications, data-structure and solver constraints (§§5–6).
7. **Reviewer appraisal:** A direct predecessor for output-preserving input reduction. Paper 7 should credit this principle; its surviving result is the concrete causal interface for its lifecycle and two specified outputs. No privacy result follows for Paper 7.
8. **Location:** §3.1 Definition 3; §4 ordering/results; §5 construction; §6.
9. **Access:** Complete original author PDF read. Direct download succeeded; web PDF endpoint returned 403. `sources/antignac2017.pdf`, `.txt`.
10. **Role:** Central comparison; targeted citation addition.

## L4 — Leucker et al.: abstract timed streams

1. **Identity:** Martin Leucker, César Sánchez, Torben Scheffel, Malte Schmitz, Daniel Thoma. *Runtime Verification for Timed Event Streams with Partial Information*. RV 2019, LNCS 11757, 273–291. [DOI](https://doi.org/10.1007/978-3-030-32079-9_16).
2. **Question:** Monitor streams containing known gaps and imprecise values.
3. **Inputs/method:** Abstract timed streams, concretizations and abstract TeSSLa operators.
4. **Finding:** Sound composition and operator-perfection results; a time-aware construction recovers precision in a composed example.
5. **Evaluation:** Proofs, TeSSLa macro implementation and comparison with enumerated concretizations on small traces.
6. **Authors' limits/future:** Some operator compositions lose precision; finite time precision and a simplified implementation affect perfection; exhaustive comparison uses short traces with few point gaps (§§4, 6).
7. **Reviewer appraisal:** Establishes formal reasoning about retained information and required outputs. Paper 7's whole-lifecycle induction remains necessary because preservation by separate components cannot simply be presumed to compose.
8. **Location:** Theorems 1–2, Corollary 1; §§4–6; conclusion.
9. **Access:** Complete proceedings PDF and main text inspected. `sources/leucker2019.pdf`, `.txt`.
10. **Role:** Central comparison.

## L5 — Carwehl et al.: changing requirements

1. **Identity:** Marc Carwehl, Thomas Vogel, Genaína Nunes Rodrigues, Lars Grunske. *Runtime Verification of Self-Adaptive Systems with Changing Requirements*. SEAMS 2023, 104–114. [DOI](https://doi.org/10.1109/SEAMS59076.2023.00024); [author manuscript](https://arxiv.org/pdf/2303.16530).
2. **Question:** Adapt a running monitor when requirements change.
3. **Inputs/method:** Property specification/adaptation patterns and timed observer automata; transfer relevant intermediate state during updates.
4. **Finding:** State-preserving adaptation implemented and compared with monitor regeneration/restart.
5. **Evaluation:** Body-sensor-network requirement changes and a Timescales comparison.
6. **Authors' limits/future:** No adapted-property ground truth for the correctness comparison; limited requirements/pattern coverage; extend adaptation patterns and probabilistic properties (§IV discussion/threats and conclusion).
7. **Reviewer appraisal:** Policy change and monitor-state handling are established. Paper 7 chooses reset-on-change as its contract semantics. The sufficiency proof must preserve that choice; it does not establish universal superiority of resetting.
8. **Location:** §§III–IV; discussion and threats near pp. 9–10 of author manuscript.
9. **Access:** Complete author manuscript retrieved; method, evaluation, threats and conclusion inspected. `sources/carwehl2023.pdf`, `.txt`.
10. **Role:** Central comparison.

## L6 — Nweke and Yeng: release-scoped compliance evidence

1. **Identity:** Livinus Obiora Nweke, Prosper Kandabongee Yeng. *Compliance-as-Code for AI-Driven Identity Systems: Clause-to-Control Traceability and Machine-Readable Evidence*. IEEE Access 14 (2026), 28258–28281. [DOI](https://doi.org/10.1109/ACCESS.2026.3665991).
2. **Question:** Automate traceable identity-system compliance assessments.
3. **Inputs/method:** Evidence tied to controls, release, environment and time; policy/configuration digests; fixed-window completeness and provenance checks.
4. **Finding:** Evidence-linked assessments and gate decisions; missing/stale evidence and release provenance handled explicitly.
5. **Evaluation:** Two identity workloads across four releases, gap injection and resource measurements.
6. **Authors' limits/future:** Bounded controls, trusted host/reference hashes, two workloads, fail-closed availability; future stronger integrity anchoring and production/assessor workflows (§IX-B, §XI).
7. **Reviewer appraisal:** Defeats any broad claim that binding evidence to current release/policy is new. Paper 7 analyzes the information interface of an additional temporal decision contract.
8. **Location:** §§IV–V; §VIII; §IX-B; §XI.
9. **Access:** IEEE identity/abstract checked; direct IEEE text blocked. Complete author-uploaded version-of-record text retrieved and relevant sections inspected. `sources/nweke2026.html`, `.txt`; original upload URL in retrieval log.
10. **Role:** Central comparison and separate Table 2 row.

## L7 — Muhammad, Yow and Alsenan: assurance gates

1. **Identity:** Aoun E. Muhammad, Kin-Choong Yow, Shrooq Alsenan. *Audit-as-Code: A Policy-as-Code Framework for Continuous AI Assurance*. Frontiers in Artificial Intelligence 9 (2026), 1759211. [DOI/full text](https://doi.org/10.3389/frai.2026.1759211).
2. **Question:** Produce repeatable assurance decisions from policy and evidence.
3. **Inputs/method:** Versioned policy, schema-validated evidence bundles and deterministic pass/warn/block gates.
4. **Finding:** Executable assurance scoring and policy-linked gate outputs.
5. **Evaluation:** 1,000 synthetic cases and five real-model configurations; checklist/heuristic and gate-setting comparisons.
6. **Authors' limits/future:** Quantifiable evidence does not exhaust organizational/normative dimensions; documentation quality matters; weights/thresholds need contextual calibration and blocker catalogues need curation (§§5.1–5.2).
7. **Reviewer appraisal:** Establishes policy/evidence gate automation. Its assurance-scoring mechanism warrants a separate comparison row from release-completeness checking.
8. **Location:** §§3–4; §§5.1–5.2.
9. **Access:** Complete publisher HTML retrieved; mechanism, evaluation and stated limits inspected. `sources/muhammad2026.html`, `.txt`.
10. **Role:** Central contextual comparison and separate Table 2 row.

## L8 — skill-audit: evidence-bound suppressions

1. **Identity:** skill-audit contributors. Source at commit `e2e9ad679b8a0459bbb4bfad39621435aa354002` (17 November 2026). [Pinned source](https://github.com/harrypham2000/skill-audit/blob/e2e9ad679b8a0459bbb4bfad39621435aa354002/skill-audit/src/suppress.ts).
2. **Question:** Reuse reviewed suppressions only for matching findings.
3. **Inputs/method:** Fingerprint includes scanner, analyzer/rule, source digest, evidence and location; exact matching plus expiry; annotate retained findings.
4. **Finding:** Changed fingerprint reactivates a finding; suppressed findings remain reportable separately from policy/score decisions.
5. **Evaluation:** Original tests cover dimension changes, reactivation, expiry, retention and scan integration. Tests inspected, not executed here.
6. **Maintainers' stated limits:** README marks SARIF CI acceptance unverified. No formal limitations/future-work section identified.
7. **Reviewer appraisal:** A direct implemented predecessor for revision-bound exceptions. It neither supplies nor invalidates the lifecycle-specific three/six-comparison proof.
8. **Location:** `findingFingerprint`, `applySuppressions`; matching test groups; README suppression and feature-status sections.
9. **Access:** Pinned source, README and tests retrieved via original GitHub API and inspected; blobs/hashes in `sources/skill_audit/retrieval.json`.
10. **Role:** Central operational comparison; targeted citation addition.

## L9 — NVIDIA SkillSpector: exact suppression baselines

1. **Identity:** NVIDIA/SkillSpector contributors. Commit `4bd05188dcf3875c22ac20c6c203f65429d8fbad` (18 November 2026). [Pinned documentation](https://github.com/NVIDIA/SkillSpector/blob/4bd05188dcf3875c22ac20c6c203f65429d8fbad/docs/SUPPRESSION.md).
2. **Question:** Preserve reviewed suppressions under finding identity and evidence checks.
3. **Inputs/method:** Version-2 fingerprints bind scanner version, complete source and finding/evidence fields; exact matching requires source and matching scanner version.
4. **Finding:** Source/scanner/evidence changes leave findings active; suppressed records remain inspectable.
5. **Evaluation:** Original tests include same-line malicious substitution and source/scanner changes. Inspected, not executed here.
6. **Maintainers' stated limits:** Migration documentation says version-1 fingerprints omitted source/evidence and could conflate benign/malicious content; exact legacy baselines are rejected. Glob rules intentionally tolerate drift.
7. **Reviewer appraisal:** Independently confirms scoped suppression and omission-induced collisions already occur in implementations. Retain in the discovery ledger; an additional manuscript example is redundant with L8.
8. **Location:** `docs/SUPPRESSION.md`, migration section; `suppression.py` lines 218–262, 330–378; `test_suppression.py` lines 807–872.
9. **Access:** Complete suppression documentation and relevant pinned source/test sections inspected; `sources/skillspector/retrieval.json`.
10. **Role:** Operational alternative testing the novelty claim.

## L10 — Prometheus Alertmanager: muting active alerts

1. **Identity:** Prometheus Authors. *Alertmanager*, official documentation, accessed 18 November 2026; v0.28.1 `TestSilencer`. [Documentation](https://prometheus.io/docs/alerting/latest/alertmanager/); [pinned test](https://github.com/prometheus/alertmanager/blob/v0.28.1/silence/silence_test.go).
2. **Question:** Route and mute notifications from incoming alerts.
3. **Inputs/method:** Label matchers and validity intervals for silences, plus inhibition/routing machinery.
4. **Finding:** Muting operates on an incoming alert and matching silence state.
5. **Evaluation:** Upstream unit assertions; Paper 7 maps the first four of eight assertions separately.
6. **Maintainers' stated limits/future:** No research limitations/future-work section on the inspected documentation page.
7. **Reviewer appraisal:** Display/notification suppression and alert existence are already separable concepts. The mapped fixture checks one part of Paper 7's contract, not the upstream implementation's full parity.
8. **Location:** Documentation introduction and Silences; `TestSilencer`, lines 1372–1443, blob `a65b1f6337723d3ba76140081b757088213f7d5a`.
9. **Access:** Official documentation reopened; pinned test verification reused from the source audit and preserved fixture manifest.
10. **Role:** Central operational context and fixture provenance.

## L11 — Lima, Huerta y Munive and Traytel: certified explanations

1. **Identity:** Leonardo Lima, Jonathan Julián Huerta y Munive, Dmitriy Traytel. *Explainable Online Monitoring of Metric First-Order Temporal Logic*. TACAS 2024, LNCS 14570, 288–307. [DOI](https://doi.org/10.1007/978-3-031-57246-3_16).
2. **Question:** Explain and certify temporal satisfaction/violation.
3. **Inputs/method:** MFOTL event traces; proof objects for variable assignments, proof-decision trees and a verified checker.
4. **Finding:** WhyMon produces checkable explanations with an interactive visualization.
5. **Evaluation:** Formal correctness, implementation and a database-log case study; comparison with MonPoly.
6. **Authors' limits/future:** Support equality between variables; improve performance, including stream slicing (§7). The formal fragment uses bounded future operators.
7. **Reviewer appraisal:** Establishes explanation as a richer output. Paper 7 studies preservation of a prescribed diagnostic label, a smaller and distinct object from WhyMon proof trees.
8. **Location:** §§2–5; §6 case study; §7, p. 304.
9. **Access:** Complete publisher chapter retrieved; model/proof-object construction and conclusion inspected, with prior source audit reused for the checker claim. `sources/lima2024.pdf`, `.txt`.
10. **Role:** Central comparison and separate Table 2 row.

## L12 — Taleb, Khoury and Hallé: access restrictions

1. **Identity:** Rania Taleb, Raphaël Khoury, Sylvain Hallé. *Runtime Verification Under Access Restrictions*. FormaliSE 2021. [Official conference record](https://conf.researchr.org/details/Formalise-2021/formalise-2021-papers/1/Runtime-Verification-Under-Access-Restrictions); [author PDF](https://constellation.uqac.ca/id/eprint/7361/1/paper.pdf).
2. **Question:** Compute meaningful monitor verdicts under degraded access to events.
3. **Inputs/method:** Stateful access proxies, sets of possible events, multi-traces and world-preserving transformations.
4. **Finding:** Loss-tolerant monitoring construction with quantified verdict ambiguity.
5. **Evaluation:** Formal results and BeepBeep examples comparing proxies with coarser over-approximation; precision, throughput and memory.
6. **Authors' limits/future:** Decide/repair ambiguity, restore soundness without world preservation, budgeted access, richer domains and enforcement (§VI).
7. **Reviewer appraisal:** Another direct predecessor to reasoning about interface-induced ambiguity. Its unresolved general questions do not themselves establish Paper 7's novelty; the latter supplies a specific causal factorization.
8. **Location:** §§III–V; §VI conclusion/future work.
9. **Access:** Complete author PDF retrieved; definitions, construction, evaluation and conclusion inspected. `sources/taleb2021.pdf`, `.txt`.
10. **Role:** Bounded synonym-search challenger; no mandatory extra manuscript citation.

## L13 — Stucki et al.: gray-box hyperproperty monitoring

1. **Identity:** Sandro Stucki, César Sánchez, Gerardo Schneider, Borzoo Bonakdarpour. *Gray-box monitoring of hyperproperties with an application to privacy*. FMSD 58 (2021), 126–159. [DOI/full text](https://doi.org/10.1007/s10703-020-00358-w).
2. **Question:** Extend monitorability using information about possible system executions.
3. **Inputs/method:** Relational HyperLTL, symbolic execution and an SMT oracle; distributed data minimality application.
4. **Finding:** Monitorability results and Minion detection of data-minimality violations.
5. **Evaluation:** Four Java methods, eager/lazy monitoring and deliberately contrasting workloads.
6. **Authors' limits/future:** Evaluation targets feasibility, not scalability; oracle implementation assumes source access; reactive data minimality, richer formulas and distributed/partial views remain future directions (§§5.4, 7).
7. **Reviewer appraisal:** Discovery route to the original output-preserving minimizer definition. §4.1 attributes that definition to Antignac et al.; credit the original for the smallest manuscript repair.
8. **Location:** §§4.1–4.2, 5.4, 7 and Antignac bibliography entries.
9. **Access:** Complete publisher HTML retrieved; listed sections inspected. `sources/stucki2021.html`, `.txt`.
10. **Role:** Citation-chain discovery and adjacent comparison.

## L14 — RTLola: derived-stream monitoring

1. **Identity:** Jan Baumeister, Bernd Finkbeiner, Florian Kohn, Frederik Scheerer. *Stream-based monitoring with RTLola*. SCP 253 (2026), 103495. [DOI](https://doi.org/10.1016/j.scico.2026.103495).
2. **Question:** Construct monitors from stream specifications.
3. **Inputs/method:** Asynchronous streams, derived streams, triggers, static memory/runtime-safety analysis and configurable integration.
4. **Finding:** The verified preview describes executable monitor construction and Boolean triggers.
5. **Evaluation:** Detailed exact-journal evaluation **NOT VERIFIED** at the available preview access level.
6. **Authors' limits/future:** **NOT VERIFIED**; no attribution invented from missing full text.
7. **Reviewer appraisal:** Distinguish a specification/monitor-construction tool from Vamos's event-delivery middleware.
8. **Location:** Exact journal preview and author-group abstract; source audit entry `baumeister2026rtlola`.
9. **Access:** Reused verified publisher preview/author abstract; no claim of a fresh complete-text reading.
10. **Role:** Table 2 mechanism comparison only.

## L15 — CauMon: causation semantics

1. **Identity:** Zhenya Zhang, Jie An, Paolo Arcaini, Ichiro Hasuo. *CauMon: A Tool for Online Monitoring against Signal Temporal Logic*. SCP 253 (2026), 103499. [DOI](https://doi.org/10.1016/j.scico.2026.103499).
2. **Question:** Make online accounts of signal evolution more informative.
3. **Inputs/method:** Signal Temporal Logic and signal traces; causation semantics addressing information masking in quantitative robustness.
4. **Finding:** The preview supports describing incoming observations' relevance to a verdict.
5. **Evaluation:** Detailed exact-journal evaluation **NOT VERIFIED** at preview access level.
6. **Authors' limits/future:** **NOT VERIFIED**; no attribution invented.
7. **Reviewer appraisal:** Causation-based online verdict information differs from WhyMon's certifying proof objects; separate rows preserve that distinction.
8. **Location:** Exact publisher preview and institutional abstract; source audit entry `zhang2026caumon`.
9. **Access:** Reused verified preview/abstract; no fresh full-text claim.
10. **Role:** Table 2 mechanism comparison only.

## L16 — Vamos: event-delivery middleware

1. **Identity:** Marek Chalupa, Fabian Muehlboeck, Stefanie Muroya Lei, Thomas A. Henzinger. *Vamos: Middleware for Best-Effort Third-Party Monitoring*. SCP 240 (2025), 103212. [DOI](https://doi.org/10.1016/j.scico.2024.103212); [version of record](https://research-explorer.ista.ac.at/download/18169/18831/2024_ScienceCompProg_Chalupa.pdf).
2. **Question:** Feed third-party monitors from heterogeneous event sources with controlled resource use.
3. **Inputs/method:** Event processing, buffers and explicit gap events with count/time summaries.
4. **Finding:** Downstream monitors receive events and information about losses; examples include approximate timestamp alignment.
5. **Evaluation:** Published implementation examples and monitoring applications; this review uses the mechanism claims, not numerical performance comparisons.
6. **Authors' limits/future:** Resource/architecture dependence, untested very large stream counts, benchmark selection and one author's recorded pointer inputs; future broader applications, higher-level languages, multiple arbiters and enforcement. This extraction is from the independently verified venue review.
7. **Reviewer appraisal:** Event collection/delivery is distinct from RTLola specification execution, warranting separate rows.
8. **Location:** §§3.3–3.4 and 5.3.3 for mechanisms; §5.4.1 p. 18 and §§7–8 pp. 19–20 for stated boundaries/future work; venue report `../venue/Venue_Fit_and_Benchmark.md`.
9. **Access:** Complete version of record verified in the retained source audit; mechanism passages reused. Venue reviewer independently inspected the full version's method, evaluation and boundary passages; root independently reopened it.
10. **Role:** Table 2 mechanism comparison; venue benchmark.

## L17 — Smith: single-guess recovery bound

1. **Identity:** Geoffrey Smith. *On the Foundations of Quantitative Information Flow*. FoSSaCS 2009, LNCS 5504, 288–302. [DOI](https://doi.org/10.1007/978-3-642-00596-1_21).
2. **Question:** Quantify information flow using an adversary's best single guess.
3. **Inputs/method:** Discrete distributions, observations and maximum posterior vulnerability.
4. **Finding:** The modal posterior choice gives optimal single-guess success.
5. **Evaluation:** Mathematical definitions, derivations and illustrative channels.
6. **Authors' limits/future:** Not newly extracted in this review; the reused exact claim is Definition 3.
7. **Reviewer appraisal:** Uniform mass over corpus occurrences gives Paper 7's modal-count sum. Proposition 2 is an attributed finite-corpus application, not its novel contribution.
8. **Location:** Definition 3 and §5, pp. 296–297; prior source-audit card.
9. **Access:** Reused full-text verification from `current/gap_execution/Cards.md` and the bibliography audit; no fresh full reading claimed.
10. **Role:** Methodological attribution for Proposition 2.

## Access limits

Preview-level sources support only the mechanism statements actually visible there. Publisher and author versions are distinguished above. No repository test suite was executed in this literature review. Search records document a bounded novelty challenge, not exhaustive literature coverage. Primary capabilities absent from inspected passages are not treated as proven absences from all versions or the wider field.
