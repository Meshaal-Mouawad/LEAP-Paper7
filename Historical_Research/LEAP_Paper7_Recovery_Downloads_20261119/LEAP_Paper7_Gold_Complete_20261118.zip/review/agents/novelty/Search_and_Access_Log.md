# Paper 7: bounded novelty search and access log

**Date:** 18 November 2026. **Purpose:** challenge the output-specific evidence/policy applicability contribution, including implemented alternatives capable of invalidating broad novelty claims. This is a bounded purposive search and citation chase, not a systematic review. Only primary publications, author copies, official documentation and original source repositories support the findings.

## Starting records

Read the exact frozen `baseline/Paper7.tex`, extracted its 20-page PDF to `Paper7_baseline_extracted.txt`, and read the identity brief and Gold protocol. Existing confirmed facts were reused from `manuscript_suite_20261118/reports/Bibliography_and_Claim_Audit.md`, `revision_20261118/manuscript/source_checks/Discovery_Update.md`, and `current/gap_execution/Cards.md`. Prior editorial PASS decisions did not determine this novelty verdict.

## Actual search strings

The two search engines are labeled by the web tool's own names. All searches occurred on the review date; no date restriction or complete historical coverage was claimed.

| Batch | Engine | Exact query | Purpose/selected route |
|---|---|---|---|
| 1 | system1 | `runtime verification abstraction monitor verdict explanation observation equivalence property preserving output` | Challenge with abstraction/monitoring terminology. |
| 1 | system1 | `"runtime verification" "policy" "version" "suppression"` | Look for composed revision/suppression mechanisms. |
| 1 | system1 | `"data minimisation" "monitor" "output" equivalence` | Found the minimization lineage, including Stucki and Antignac. |
| 1 | system1 | `"alert" "silence" "version" evidence policy monitoring` | Operational alternatives to the paper's application vocabulary. |
| 2 | system2 | `"Compliance-as-Code for AI-Driven Identity Systems" pdf` | Retrieve the exact scoped-evidence source. |
| 2 | system2 | `"Antignac" "data minimisation" "Sands" "Schneider"` | Trace the original output-preserving preprocessor publication. |
| 2 | system2 | `"version" "suppression" "fingerprint" "code scanning"` | Find implemented revision-sensitive exceptions. |
| 2 | system2 | `runtime verification "output" "abstraction" "reason" monitor` | Challenge the decision/reason distinction under alternate terminology. |
| 3 | system1 | `"hungpg" "skill-audit" github` | Resolve discovered implementation to its original repository. |
| 3 | system1 | `"source" "evidence" "rule" "scanner version" "suppression"` | Find exact implementation documentation and independent alternative. |
| 3 | system1 | `"Runtime Verification Under Access Restrictions"` | Retrieve Taleb et al. original paper. |
| 3 | system1 | `"Data Minimisation: A Language-Based Approach" 2017 doi` | Verify original Antignac identity and original full text. |

Search results were screened for a mechanism that could subsume the specific contribution. Irrelevant results and secondary descriptions were not used as evidence. There was no numerical screening-flow analysis. The bounded search stopped after the closest new theoretical predecessor and two operational alternatives had been checked in primary text/source.

## Primary access and evidence locations

| Source | Primary URL and result | Local record / inspected locations |
|---|---|---|
| Henzinger 2022 | [Institutional proceedings PDF](https://research-explorer.ista.ac.at/download/11775/12317/2022_LNCS_RV_Henzinger.pdf), HTTP 200 | `sources/henzinger2022.pdf`; §§2–5, Proposition 6, authors' future work. |
| Jevitha 2024 | [Versioned arXiv HTML](https://arxiv.org/html/2406.12715v1), HTTP 200 | `sources/jevitha2024.html`; abstraction methods, Algorithms 4–6, Tables 2–3, conclusion. |
| Leucker 2019 | [Coauthor PDF](https://software.imdea.org/~cesar/papers/leucker19runtime.pdf), HTTP 200 | `sources/leucker2019.pdf`; soundness/perfection, composition, evaluation, conclusion. |
| Carwehl 2023 | [Author manuscript](https://arxiv.org/pdf/2303.16530), HTTP 200 | `sources/carwehl2023.pdf`; §§III–IV, threats and future work. |
| Antignac 2017 | [Author proceedings PDF](https://www.cse.chalmers.se/~gersch/ifip-sec17-data_min.pdf), web route 403; direct original download HTTP 200 | `sources/antignac2017.pdf`; full main text, especially §§3.1, 4–6. |
| Stucki 2021 | [Publisher full text](https://link.springer.com/article/10.1007/s10703-020-00358-w), HTTP 200 | `sources/stucki2021.html`; §§4.1–4.2, 5.4, 7, original Antignac attribution. |
| Taleb 2021 | [Institutional PDF](https://constellation.uqac.ca/id/eprint/7361/1/paper.pdf), HTTP 200 | `sources/taleb2021.pdf`; §§III–VI. |
| Muhammad 2026 | [Publisher full text](https://www.frontiersin.org/journals/artificial-intelligence/articles/10.3389/frai.2026.1759211/full), HTTP 200 | `sources/muhammad2026.html`; §§3–5.2. |
| Nweke 2026 | [IEEE record](https://ieeexplore.ieee.org/document/11398064/), metadata/abstract available, direct text blocked; [author-uploaded version of record](https://www.researchgate.net/publication/400811779_Compliance-as-Code_for_AI-Driven_Identity_Systems_Clause-to-Control_Traceability_and_Machine-Readable_Evidence), HTTP 200 | `sources/nweke2026.html`; §§IV–V, VIII, IX-B, XI. Author upload status is explicit on the source page. |
| WhyMon 2024 | [Publisher chapter PDF](https://link.springer.com/content/pdf/10.1007/978-3-031-57246-3_16.pdf), HTTP 200 | `sources/lima2024.pdf`; formal fragment/proof objects, case-study and conclusion passages. |
| Alertmanager | [Official documentation](https://prometheus.io/docs/alerting/latest/alertmanager/), accessible | Introduction and Silences. Pinned test-source verification reused from existing audit. |
| skill-audit | [Pinned repository](https://github.com/harrypham2000/skill-audit/tree/e2e9ad679b8a0459bbb4bfad39621435aa354002), GitHub API source/blob retrieval succeeded | `sources/skill_audit/`: README, suppression source and tests; `findingFingerprint`, `applySuppressions`, reactivation/expiry/integration tests. |
| NVIDIA SkillSpector | [Pinned repository](https://github.com/NVIDIA/SkillSpector/tree/4bd05188dcf3875c22ac20c6c203f65429d8fbad), GitHub API source/blob retrieval succeeded | `sources/skillspector/`: suppression documentation, fingerprint/matching source, tests for omitted evidence and source/scanner drift. |

All original scholarly downloads have byte counts and SHA256 hashes in `sources/retrieval_log.json`. Both software repositories have their commit metadata and file Git blob identities preserved in `sources/*_metadata.json`; source-file hashes and exact API routes are in `sources/skill_audit/retrieval.json` and `sources/skillspector/retrieval.json`. Tests were read as primary evidence; this review did not execute them.

## Reused checks

RTLola and CauMon mechanism descriptions use the exact 2026 journal previews and institutional/author abstracts recorded in the existing bibliography audit. Their full journal methods/results/limitations were not newly verified. Vamos uses the audit's full-version-of-record passages, plus the independently assigned venue review. Smith's maximum-posterior definition and the pinned Alertmanager fixture use the retained original source checks. Those access distinctions are carried into the source ledger.

## Search outcome

Antignac supplies a closer original predecessor for output-preserving preprocessing. The two source implementations directly establish revision-sensitive suppression and evidence-fingerprint collisions as prior operational mechanisms. None of the inspected primary results supplies Paper 7's exact causal three-comparison decision interface, six-comparison sufficient reason interface, and mismatch-reason counterexample for the declared lifecycle. This is a bounded source finding; the affirmative contribution judgment additionally rests on the actual proofs, as recorded in the contribution matrix.
