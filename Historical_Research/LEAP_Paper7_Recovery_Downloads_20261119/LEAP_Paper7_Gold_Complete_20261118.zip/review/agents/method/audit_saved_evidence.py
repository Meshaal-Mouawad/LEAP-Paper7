"""Independent rescore of frozen inputs and saved outputs; no study execution.

This audit imports no study program and writes only under the methods-agent tree.
It derives the manuscript's counts from raw records, not retained PASS labels.
"""
from pathlib import Path
from collections import Counter, defaultdict
import copy
import csv
import hashlib
import json
import re
import zipfile

OUT = Path(__file__).resolve().parent
PROJECT = OUT.parents[2]
R = OUT / 'frozen/Paper7_Reproduction'
READS = {}

def read(path):
    path = Path(path)
    data = path.read_bytes()
    READS[str(path)] = hashlib.sha256(data).hexdigest()
    return data.decode()

def js(path):
    return json.loads(read(path))

def jl(path):
    return [json.loads(line) for line in read(path).splitlines() if line]

def keyed(rows, key):
    result = {key(row): row for row in rows}
    assert len(result) == len(rows), 'Duplicate record key'
    return result

def canon(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'))

def decision(out):
    return [(e['state'], e['active'], e['severity']) for e in out]

def intervals(out):
    # Derive half-open spans independently from change edges.
    flags = [False] + [e['active'] for e in out] + [False]
    starts = [i for i in range(len(out)) if not flags[i] and flags[i + 1]]
    ends = [i for i in range(1, len(out) + 1) if flags[i] and not flags[i + 1]]
    return list(zip(starts, ends, strict=True))

def normalize(trace):
    result = copy.deepcopy(trace)
    for e in result:
        factor = 1 if e['unit'] == 's' else .001
        e['unit'] = 's'
        e['t'] *= factor
        e.pop('metadata', None)
        if 'o' in e:
            e['o']['at'] *= factor
            e['o'].pop('snapshot', None)
            e['o'].pop('snapshot_sha256', None)
        if 's' in e:
            e['s']['until'] *= factor
    return result

def metric(rows, predictions, refs):
    c = Counter(traces=0, events=0, trace_agreement=0, episode_agreement=0,
                event_agreement=0, missed_active=0, unwarranted_active=0,
                reference_active=0, reference_inactive=0, reference_unknown=0,
                severity_agreement=0, reason_agreement=0, failures=0)
    for row in rows:
        gold = refs[row['id']]['outputs']
        record = predictions[row['id']]
        actual = record['outputs']
        assert len(gold) == len(row['trace'])
        failed = bool(record.get('error')) or len(actual) != len(gold)
        c['traces'] += 1
        c['events'] += len(gold)
        c['failures'] += failed
        c['reference_active'] += sum(e['active'] for e in gold)
        c['reference_inactive'] += sum(not e['active'] for e in gold)
        c['reference_unknown'] += sum(e['state'] == 'UNKNOWN' for e in gold)
        if failed:
            continue
        c['trace_agreement'] += decision(actual) == decision(gold)
        c['episode_agreement'] += intervals(actual) == intervals(gold)
        for a, b in zip(actual, gold, strict=True):
            c['event_agreement'] += decision([a]) == decision([b])
            c['severity_agreement'] += a['severity'] == b['severity']
            c['reason_agreement'] += a['reason'] == b['reason']
            c['missed_active'] += b['active'] and not a['active']
            c['unwarranted_active'] += a['active'] and not b['active']
    c['trace_mismatches'] = c['traces'] - c['trace_agreement']
    c['episode_mismatches'] = c['traces'] - c['episode_agreement']
    c['event_mismatches'] = c['events'] - c['event_agreement']
    c['severity_mismatches'] = c['events'] - c['severity_agreement']
    c['reason_mismatches'] = c['events'] - c['reason_agreement']
    return dict(c)

traces = jl(R / 'study/benchmark/traces.jsonl')
trace_by_id = keyed(traces, lambda x:x['id'])
refs = keyed(jl(R / 'study/benchmark/reference.jsonl'), lambda x:x['id'])
raw = jl(R / 'saved_run/results/predictions.jsonl')
methods = sorted({x['method'] for x in raw})
preds = {m:keyed([x for x in raw if x['method'] == m], lambda x:x['id']) for m in methods}
assert set(refs) == set(trace_by_id)
assert all(set(p) == set(trace_by_id) for p in preds.values())
groups = defaultdict(list)
for row in traces:
    groups[row['group']].append(row)
for group, rows in groups.items():
    assert {x['variant'] for x in rows} == {'base','metadata','milliseconds'}
    assert len({x['split'] for x in rows}) == 1
    assert all(normalize(rows[0]['trace']) == normalize(x['trace']) for x in rows)

scopes = {
    'full':traces,
    'development_all':[x for x in traces if x['split'] == 'development'],
    'heldout_all':[x for x in traces if x['split'] == 'heldout'],
    'development_base':[x for x in traces if x['split'] == 'development' and x['variant'] == 'base'],
    'heldout_base':[x for x in traces if x['split'] == 'heldout' and x['variant'] == 'base'],
}
metrics = [{'scope':scope,'method':m, **metric(rows,preds[m],refs)}
           for scope, rows in scopes.items() for m in methods]
invariance = {}
for m in methods:
    result = Counter(pairs=0,equal=0,metadata_pairs=0,milliseconds_pairs=0)
    for group, rows in groups.items():
        base = preds[m][group + '/base']['outputs']
        for variant in ['metadata','milliseconds']:
            result['pairs'] += 1
            result[variant+'_pairs'] += 1
            result['equal'] += preds[m][group+'/'+variant]['outputs'] == base
    invariance[m] = dict(result)

family_templates = {}
for family in sorted({x['family'] for x in traces}):
    family_templates[family] = {x['group'].split('/',1)[1]:normalize(x['trace'])
                                for x in traces if x['family'] == family and x['variant'] == 'base'}
assert all(x == family_templates['audit'] for x in family_templates.values())
assert not ({x['source'] for x in scopes['development_all']} & {x['source'] for x in scopes['heldout_all']})
assert not ({x['family'] for x in scopes['development_all']} & {x['family'] for x in scopes['heldout_all']})

def category(row):
    m = row['mechanism']
    return m if m in ['exhaustive','control'] else ('boundary' if m.startswith('boundary_') else 'intervention')
design_counts = defaultdict(Counter)
for row in traces:
    c = design_counts[category(row)]
    c['traces'] += 1
    c['events'] += len(row['trace'])
    c['base_traces'] += row['variant'] == 'base'

# Reconstruct all 55 intervention designs independently from manuscript rules.
def ordinary(t, value):
    return {'t':t,'unit':'s','c':'c1','p':'p1','o':{'value':value,'c':'c1','p':'p1','at':t}}
control = [ordinary(t, 1 <= t <= 7) for t in range(12)]
intervention_check = []
for row in traces:
    if category(row) != 'intervention':
        continue
    op, j = row['mechanism'], int(row['group'].rsplit('/',1)[1])
    assert j in [2,3,5,7,9]
    expected = copy.deepcopy(control)
    if op == 'missing':expected[j].pop('o')
    elif op == 'conflict':expected[j]['o']['value'] = None
    elif op == 'stale':expected[j]['o']['at'] = j - 3
    elif op == 'future':expected[j]['o']['at'] = j + 1
    elif op in ['context_old_obs','context_fresh']:
        for e in expected[j:]:
            e['c'] = 'c2'
            e['o']['c'] = 'c1' if op.endswith('old_obs') else 'c2'
    elif op in ['policy_old_obs','policy_fresh']:
        for e in expected[j:]:
            e['p'] = 'p2'
            e['o']['p'] = 'p1' if op.endswith('old_obs') else 'p2'
    else:
        assert op in ['suppression_valid','suppression_old_context','suppression_old_policy']
        for e in expected[j:]:
            e['s'] = {'c':'c0' if op == 'suppression_old_context' else 'c1',
                      'p':'p0' if op == 'suppression_old_policy' else 'p1','until':j+2}
    equal = normalize(row['trace']) == expected
    assert equal,row['id']
    intervention_check.append({'id':row['id'],'equal':equal})

# Reconstruct the information classes without executing a monitor.
witnesses = js(R/'study/benchmark/witness_references.json')
wc = defaultdict(lambda:defaultdict(Counter))
pair_records = []
for pair in witnesses:
    field = pair['projection_drop']
    projected = {}
    for side in ['left','right']:
        ev = copy.deepcopy(pair[side])
        outer, inner = field.split('.')
        for event in ev:
            target = event if outer == 'event' else event.get(outer,{})
            target.pop(inner,None)
        visible = {'events':ev,'rule':pair['rule'],'policy':js(R/'study/benchmark/policy.json'),'base_severity':'High'}
        projected[side] = visible
        wc[field][canon(visible)][canon(decision(pair[side+'_reference']))] += 1
    same = projected['left'] == projected['right']
    different = decision(pair['left_reference']) != decision(pair['right_reference'])
    assert same and different,pair['id']
    pair_records.append({'id':pair['id'],'same_projected_input':same,'different_decision':different})
bounds = [{'field':field,'traces':sum(sum(c.values()) for c in classes.values()),
           'classes':len(classes),'heterogeneous_classes':sum(len(c)>1 for c in classes.values()),
           'B':sum(max(c.values()) for c in classes.values())}
          for field,classes in wc.items()]

# Independent implementations: raw predictions, not agreement flags.
replications = {}
for name, subdir in [('SQLite','replication_r2'),('PyContract','r3/baseline')]:
    rows = jl(R/f'saved_run/{subdir}/predictions.jsonl')
    p = keyed(rows,lambda x:x['id'])
    assert set(p) == set(refs)
    result = metric(traces,p,refs)
    for label in ['witness','hand_trace']:
        checked = js(R/f'saved_run/{subdir}/{label}_results.json')
        result[label+'_checks'] = len(checked)
        result[label+'_exact'] = sum(x['outputs'] == x['reference'] for x in checked)
    malformed = js(R/f'saved_run/{subdir}/malformed_results.json')
    result['malformed_checks'] = len(malformed)
    result['malformed_correct'] = sum(x['expected'] == x['actual'] == 'ValueError' for x in malformed)
    if name == 'PyContract':
        result['engine_events'] = sum(x['engine_audit']['engine_events'] for x in rows)
        result['state_transitions'] = sum(x['engine_audit']['state_transitions'] for x in rows)
        assert all(x['engine_audit']['engine_events'] == len(trace_by_id[x['id']]['trace']) for x in rows)
    replications[name] = result

cases = js(R/'review_checks/method/targeted_cases.json')
case_by_id = keyed(cases,lambda x:x['id'])
target = js(PROJECT/'revision_20261118/evidence/empirical/review_checks/targeted_results.json')
concurrent = Counter(cases=len(cases),events_per_method=sum(len(x['trace']) for x in cases),
                     implementation_case_checks=0,final_exact=0,full_sequence_equal_cases=0,failures=0)
assert {x['id'] for x in target} == set(case_by_id)
for result in target:
    expected = case_by_id[result['id']]['expected_final']
    outs = []
    assert result['expected_final'] == expected
    assert set(result['methods']) == {'Bound','Reference_v2','SQLite','PyContract'}
    for method, v in result['methods'].items():
        concurrent['implementation_case_checks'] += 1
        concurrent['failures'] += v['error'] is not None
        concurrent['final_exact'] += v['outputs'][-1] == expected
        assert len(v['outputs']) == len(case_by_id[result['id']]['trace'])
        outs.append(v['outputs'])
    concurrent['full_sequence_equal_cases'] += all(x == outs[0] for x in outs)

external = js(R/'saved_run/scp_revision/external_fixture/results.json')
fixture_cases = js(R/'study/scp_revision/external_fixture/cases.json')
fixture_data = fixture_cases['cases'] if isinstance(fixture_cases,dict) else fixture_cases
fixture_map = {x['id']:x for x in fixture_data}
external_count = Counter(cases=0,mapped_exact=0,complete_reference_exact=0,active_setup=0,execution_failures=0)
for row in external['cases']:
    external_count['cases'] += 1
    external_count['mapped_exact'] += (row['monitor_output'][-1]['state'] == 'SUPPRESSED') == row['expected_mutes']
    external_count['complete_reference_exact'] += row['monitor_output'] == row['oracle_output']
    external_count['active_setup'] += row['monitor_output'][1]['active'] and row['monitor_output'][-1]['active']
    external_count['execution_failures'] += row['execution_failure'] is not None

# Primary chronology/source records retained in the original private archive.
historical_zip = PROJECT/'recovered/LEAP_Paper7_Research_and_Submission_Draft_20261118.zip'
READS[str(historical_zip)] = hashlib.sha256(historical_zip.read_bytes()).hexdigest()
with zipfile.ZipFile(historical_zip) as archive:
    def original(name):
        b = archive.read('paper7_risk_alarm/'+name)
        READS[str(historical_zip)+'!paper7_risk_alarm/'+name] = hashlib.sha256(b).hexdigest()
        return json.loads(b)
    original_reference = original('reviews/reference_checks.json')
    corrected_reference = js(R/'study/reviews/reference_checks_v2.json')
    original_cases = {x['name']:x for x in original_reference['cases']}
    corrected_cases = {x['name']:x for x in corrected_reference['cases']}
    assert set(original_cases) == set(corrected_cases)
    changed_cases = []
    for name, old in original_cases.items():
        new = corrected_cases[name]
        if 'trace' in old and old['trace'] != new['trace']:
            old_trace = copy.deepcopy(old['trace'])
            for event in old_trace:event.setdefault('unit','s')
            assert old_trace == new['trace']
            changed_cases.append(name)
        assert old['expected'] == new['expected']
        if isinstance(old['expected'], list):
            assert old['expected'] == old['actual']
            assert new['expected'] == new['actual']
        else:
            # These historical records retain only the exception-match flag.
            # check_reference_v2.py:51-57 sets it only on caught ValueError;
            # the retained executed log documents completion of this branch.
            assert old['expected'] == new['expected'] == 'ValueError'
            assert old['pass'] and new['pass']
    correction = original('reviews/oracle_v2_correction.json')
    freeze = original('protocol/FREEZE.json')
    chronology = {
        'original_freeze':freeze['utc'],'original_freeze_stage':freeze['stage'],
        'original_expectations':len(original_cases),
        'original_valid_expectations':sum(isinstance(x['expected'],list) for x in original_cases.values()),
        'original_error_expectations':sum(not isinstance(x['expected'],list) for x in original_cases.values()),
        'v2_correction_utc':correction['utc'],
        'v2_regression_valid':sum(isinstance(x['expected'],list) for x in corrected_cases.values()),
        'v2_regression_errors':sum(not isinstance(x['expected'],list) for x in corrected_cases.values()),
        'v2_input_repairs':changed_cases,
        'separate_schema_probes':len(correction['schema_cases']),
        'schema_correct_both':sum(x['oracle_v2'] == x['incremental'] == 'ValueError' for x in correction['schema_cases']),
        'benchmark_traces':correction['benchmark_traces'],
        'benchmark_mismatches':len(correction['benchmark_mismatches']),
        'witness_traces':correction['witness_traces'],
        'witness_mismatches':len(correction['witness_mismatches']),
    }
    historical = original('reviews/archived_alarm_checks.json')
    source_results = []
    for case in historical['fixtures']:
        content = archive.read('paper7_risk_alarm/'+case['fixture'])
        assert hashlib.sha256(content).hexdigest() == case['sha256']
        comment = re.search(r'Expected Compliance Rule\(s\): (.*)',content.decode()).group(1)
        expected = [] if comment == 'None' else [x.strip() for x in comment.split(',')]
        observed = [x['rule_id'] for x in case['alarms']]
        assert expected == case['expected'] and observed == case['actual']
        source_results.append({'fixture':case['fixture'],'expected':expected,'observed':observed,'exact':sorted(expected)==sorted(observed)})
    for path,h in historical['source_hashes'].items():
        assert hashlib.sha256(archive.read('paper7_risk_alarm/'+path)).hexdigest() == h
    historical_trace_rows = [json.loads(x) for x in archive.read('paper7_risk_alarm/benchmark/traces.jsonl').decode().splitlines()]
    projected_count = 0
    snippets = 0
    for old in historical_trace_rows:
        new = trace_by_id[old['id']]
        reduced = copy.deepcopy(old)
        for event in reduced['trace']:
            if 'o' in event and 'snapshot' in event['o']:
                snippets += 1
                assert hashlib.sha256(event['o']['snapshot'].encode()).hexdigest() == event['o']['snapshot_sha256']
                event['o'].pop('snapshot');event['o'].pop('snapshot_sha256')
        assert reduced == new
        projected_count += 1

# Retained executions remain evidence; this audit does not repeat them.
commands = js(R/'saved_run/fresh_execution/commands.json')
execution_logs = []
for command in commands:
    stdout = read(R/'saved_run/fresh_execution'/command['stdout'])
    stderr = read(R/'saved_run/fresh_execution'/command['stderr'])
    execution_logs.append({'sequence':command['sequence'],'command':command['command'],
                           'exit_code':command['exit_code'],'stdout_bytes':len(stdout.encode()),
                           'stderr_bytes':len(stderr.encode())})

representation_three = json.loads(read(R/'saved_run/fresh_execution/04_representation.stdout.log'))
representation_six = json.loads(read(R/'saved_run/fresh_execution/03_verify.stdout.log'))
reason_expected = Counter()
for outputs in refs.values():
    for event in outputs['outputs']:
        if event['reason'] in ['POLICY_MISMATCH','POLICY_CHANGE']:
            reason_expected[event['reason']] += 1
assert reason_expected == {'POLICY_MISMATCH':510,'POLICY_CHANGE':75}

run = 'audit/suppression_old_context/2/base'
running_case = [{'index':i,'input':trace_by_id[run]['trace'][i],
                 'bound':a,'no_suppression_binding':b}
                for i,(a,b) in enumerate(zip(preds['bound'][run]['outputs'],preds['no_suppression_binding'][run]['outputs'],strict=True))
                if a != b or i in [0,1,2,3,4]]

summary = {
    'audit_type':'New independent static inspection and raw-output rescore; no study execution',
    'corpus':{'traces':len(traces),'events':sum(len(x['trace']) for x in traces),
              'groups':len(groups),'families':len(family_templates),'templates_per_family':len(family_templates['audit']),
              'same_templates_across_all_families':True,'historical_projection_exact_traces':projected_count,
              'historical_boolean_snapshots_with_verified_sha256':snippets},
    'design_categories':dict(design_counts),
    'primary_metrics':metrics,'invariance':invariance,
    'interventions':{'representations':len(intervention_check),'matched':sum(x['equal'] for x in intervention_check)},
    'witnesses':{'pairs':len(pair_records),'valid_pairs':sum(x['same_projected_input'] and x['different_decision'] for x in pair_records),'bounds':bounds},
    'replications':replications,'concurrent':dict(concurrent),'external_fixture':dict(external_count),
    'reference_chronology':chronology,'source_fixtures':source_results,
    'representation_three_retained_execution':representation_three,
    'representation_six_retained_execution':representation_six,
    'reason_mapping_source_counts':dict(reason_expected),
    'retained_execution_logs':execution_logs,'running_case':running_case,
}
(OUT/'Raw_Evidence_Audit.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'Read_Input_Hashes.json').write_text(json.dumps(READS,indent=2)+'\n')
with (OUT/'Recomputed_Metrics.csv').open('w') as f:
    writer=csv.DictWriter(f,fieldnames=list(metrics[0]));writer.writeheader();writer.writerows(metrics)
print(json.dumps({k:v for k,v in summary.items() if k not in ['primary_metrics','source_fixtures','running_case','retained_execution_logs']},indent=2))
print('HELDOUT BASE')
print(json.dumps([x for x in metrics if x['scope']=='heldout_base'],indent=2))
