# Paper 7 — Numerical and source ledger

**All audited study numbers match the frozen record.** Locations refer to the baseline `Paper7.tex`; the integrated symmetric-reset sentence has the same line placement. `R/`, `H!/` and `E/` have the meanings defined in `METHOD_EVIDENCE_REVIEW.md`. Every claimed count is tied to a population, unit and condition below. The independent recomputation is `Raw_Evidence_Audit.json`; exact metric rows are `Recomputed_Metrics.csv`.

| Manuscript location / claim | Value, denominator and unit | Direct primary source and audit operation | Interpretation |
|---|---|---|---|
| §3.1 duration configuration, line 121 | D=C=F=2 s; E=4 s | R/study/benchmark/policy.json; monitor.py:42–62 | Configured policy durations, not empirical latency |
| §3.1 boundaries | Inclusive qualification/clearing/escalation/freshness; strict suppression expiry | monitor.py:42–64; SEMANTICS.md steps 3–6 | Decisions at supplied event times |
| §4, six projections, line 192 | event.c, event.p, o.c, o.p, s.c, s.p | R/study/benchmark/necessity_witnesses.json; field-deletion rescore | Six separately restricted interfaces |
| Abstract; §6.1, line 284 | 30 pairs, 60 witness sides | Actual paired inputs and references; all projected pairs equal and decisions differ | Six structural pairs × five rule identifiers |
| §6.1 bound, line 284 | Per projection: 10 traces; five classes; five heterogeneous classes; B=5; B/N=5/10 | Independent class count from witness inputs with retained rule/policy/base severity | Separate finite-multiset bound for each projection |
| §4, Proposition 3; §6.1, line 289 | Six comparisons; 4,935 complete sequences, including reasons, reproduced | R/study/scp_revision/equality/verify.py; saved_run/fresh_execution/03_verify.stdout.log | Sufficiency replay over whole frozen corpus |
| §4, Proposition 4; §6.1, line 290 | At most three joint comparisons; 26,430/26,430 decisions across 4,935 traces | R/study/r3/analysis/representation.py; saved_run/fresh_execution/04_representation.stdout.log | Decision preservation by specified encoder/decoder |
| Abstract; §6.1, line 290 | 585 reason differences = 510 policy mismatch + 75 policy change | Retained representation log; independent raw reference reason counts | Specific decoder's reason remapping |
| §5.1, line 217 | 329 base designs per family = 256+3+55+15 | Original build_benchmark.py:18–50; raw group inventory | Finite mechanism coverage |
| §5.1, line 217 | 4^4=256 length-four designs | Four values and Cartesian product in generator; actual IDs/events | 0,2,4,6 s event times |
| §5.1 controls, line 217 | Three controls, each 12 events | Generator controls and actual traces | All negative; all positive; one negative + seven positive + four negative |
| §5.1 intervention taxonomy, lines 219–242 | 11 operations × five positions = 55 designs/family | Independent reconstruction of each operation at j∈{2,3,5,7,9} | Event-local evidence interventions; suffix version/suppression interventions |
| §5.1 boundary designs, line 244 | Five boundaries × three offsets = 15 designs/family | Generator and actual traces | Offsets −0.5,0,+0.5 s; event lengths 2,4,3,2,3 by boundary |
| §5.1 representations, line 246 | Three forms/design; ms scaling factor 1,000 | All 1,645 groups normalized and compared directly | Base, metadata and equivalent milliseconds |
| §5.1 corpus, line 246 | 1,645 groups; 4,935 traces; 26,430 events | Raw traces parsed; unique groups and event lengths counted | Five families share 329 templates |
| §5.1 exhaustive category, line 246 | 3,840 representations; 15,360 events | Raw mechanism and event counts | 256×5×3 traces, four events each |
| §5.1 controls category, line 246 | 45 representations; 540 events | Raw control labels/counts | 3×5×3 traces, 12 events each |
| §5.1 interventions category, line 246 | 825 representations; 9,900 events | Independent reconstruction matched 825/825; raw event count | 55×5×3 traces, 12 events each |
| §5.1 boundary category, line 246 | 225 representations; 630 events | Raw boundary labels/counts | 15×5×3 traces, varying event lengths |
| §5.1 split, line 249 | 658 development base traces; 987 held-out base traces | Family-based raw partitions and groups | Two development families; three held-out families |
| §5.1; §6.2 base denominators | Held-out 987 traces; 5,286 events | Full base subset parsed and rescored | Each family-design base instance counted once |
| §5.1; §6.2 transformed held-out population | 2,961 traces; 15,858 events | All variants in held-out family subset | Three representations of each base instance |
| §6.4 development match, line 342 | 1,974/1,974 traces | New raw rescore of development predictions; H!/logs/development_checks.json | Development variants under same contract |
| §5.2 original expectations, line 252 | 29 = 21 intended-valid + eight malformed cases | H!/reviews/reference_checks.json; original checker and freeze provenance | Original pre-evaluation expectation set |
| §5.2; §6.4 v2 regression, line 342 | 29 = 21 valid + eight malformed cases | R/study/reviews/reference_checks_v2.json; checker lines 24–61; retained execution log | Post-evaluation replay, three missing unit fields repaired |
| §5.2; §6.4 schema, lines 254/342 | 28 malformed probes, explicit ValueError for both implementations | H!/reviews/oracle_v2_correction.json | Separate schema-probe denominator |
| §6.4 reference preservation, line 342 | 4,935 benchmark sequences and 60 witness sequences unchanged | Same correction record, source hashes and frozen references | Correction changes malformed input validation |
| §5.3 environment, line 260 | Python 3.12.14, Linux x86-64 | Saved primary environment and retained execution logs | Executed historical environment |
| §5.4 SQL version, line 269 | SQLite 3.53.1 | saved_run/replication_r2/summary.json; fresh_execution/result.json | Executed SQLite version |
| §5.4 PyContract pin, line 272 | e378eed38699bcff33e2ae71426e6b161690cdfa | Upstream FETCH_METADATA.json; nine Git blobs independently recalculated | Specific supplied upstream snapshot |
| §6.2 active denominators, lines 294/298 | 1,293 active; 3,993 inactive; sum 5,286 | Reference active booleans counted independently | Binary activity partition |
| §6.2 unresolved count, line 294 | 1,803 UNKNOWN/5,286 base events | Reference state values counted independently | Display state can coexist with activity |
| §6.2 table complete and episode agreement | Bound 987/987; timer 897/927; no evidence 957/969; no suppression 957/987; no freshness 969/975; snapshot 246/246 | Raw tuple sequences and independently derived active intervals | Both columns denominator 987 traces |
| §6.2 table active-event errors | Missed/unwarranted: bound 0/0; timer 0/192; no evidence 0/84; no suppression 0/0; no freshness 6/18; snapshot 408/1,179 | Reference and actual active booleans | Missed denominator 1,293; unwarranted denominator 3,993 |
| §6.2 tuple/severity/reason discrepancy table | Bound 0/0/0; timer 342/342/282; no evidence 204/204/204; no suppression 48/48/48; no freshness 51/51/18; snapshot 1,851/1,761/5,286 | Actual raw output fields compared directly | Each denominator 5,286 events |
| §6.2 timer-all-variants, line 310 | 270 trace mismatches and 576 unwarranted active events | Independent heldout_all/timer_only metric row | Denominators 2,961 traces and 11,979 inactive events |
| §6.2 suppression result, line 312 | 30 trace differences, 48 tuple differences; 987/987 interval matches | Independent heldout_base/no_suppression_binding row | Endpoint failure visible in display/severity, hidden by interval-only scoring |
| §6.2 full fields, line 334 | 15,858/15,858 reason and severity agreements | Raw held-out complete-monitor fields | All held-out representations |
| §6.3 invariance, line 337 | 3,290/3,290 per method = 1,645 metadata + 1,645 unit pairs | Saved complete output equality per group for six methods | Same finite transformed corpus |
| §6.4 source fixtures, line 340 | 11/11 expected rule-set matches | Source-file hashes, fixture comments and actual saved alarm objects | Archived lexical-rule fixtures |
| §6.4 concurrent cases, line 344 | 24 cases; 96/96 implementation–case final matches; 75 events/implementation | Frozen expected_final objects compared to actual four-implementation outputs | 24×4 final comparisons; full sequences separately agree |
| §6.5 SQL, line 347 | 4,935/4,935 traces; 26,430/26,430 events; zero failures | Independent rescore of raw SQL predictions | Same whole frozen corpus |
| §6.5 SQL checks, line 347 | 60/60 witnesses; 21/21 valid hand traces; 28/28 malformed probes | Raw outputs/reference pairs and expected/actual exception names | Separate check populations |
| §6.5 PyContract, line 349 | 4,935/4,935 traces; 26,430/26,430 tuples/reasons/severities; intervals exact | Independent rescore of raw PyContract predictions | Same whole frozen corpus |
| §6.5 PyContract active denominators | 6,465 active; 19,965 inactive; zero missed/unwarranted | Whole-corpus reference and raw predictions | Event-level activity comparison |
| §6.5 PyContract split and checks | 1,974 development and 2,961 held-out matching traces; 60/60 witness, 21/21 hand, 28/28 malformed | Raw predictions/check outputs and frozen partition | Retrospective executions |
| §6.5 dispatch, line 351 | 26,430 dispatcher events and 26,430 state transitions | Sum of raw per-trace engine_audit counters | Actual upstream dispatch participation |
| §6.5 dependency checks, line 351 | Three disabled methods fail; restoration succeeds | Source and observed engine_dependency_checks.json outcomes | Three interruption checks plus one restoration |
| §5.4; §6.6 pinned suppression | Four mapped expectations false,false,true,false; four setup checks; zero failures | Original silence_test.go lines 1383/1392/1402/1408 and raw mapped output sequences | Fixed-label projected suppression conformance |
| Limitations external coverage, line 373 | Four of eight TestSilencer suppression assertions | Count of Mutes assertions in source lines 1372–1443; mapping ledger | Remaining assertions explicitly outside projection |
| Running example, lines 31/117/357 | Positive run starts 1 s; old-context deferral at 2 s; qualifies 3 s; expires 4 s | Raw audit/suppression_old_context/2/base inputs and outputs | At 3 s bound ACTIVE vs ablation SUPPRESSED; both ACTIVE at 4 s |

## Preservation ledger

| Protected object | Verification |
|---|---|
| Four propositions and four proofs | Byte-identical baseline/working source blocks |
| Two displayed equations and five table data blocks | Byte-identical baseline/working source blocks |
| Frozen reproduction ZIP | 188 entries; CRC clean; SHA-256 b55949d177b3355bda1f49442015141ac382e84345b4cc283a7fc4a811a9db48 |
| Package / review / study / saved-input manifests | 173 / 13 / 58 / 58 entries verified, zero mismatches; overlapping scopes |
| Pinned upstream files | Nine PyContract Git blobs and two Alertmanager source/license blobs recomputed and matched |
| Original/public temporal input relationship | All 4,935 historical records become supplied temporal packets after only snapshot text/hash removal; all 18,600 snippet hashes verified |

External-paper numerical claims in the literature section belong to the separate source-verification review; they are not represented as original-study results in this ledger.
