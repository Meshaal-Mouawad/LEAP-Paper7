# Paper 7 — Method, statistics and evidence review

**Decision: PASS for G6, G7 and the methods scope of G2; PASS for G9 on the inspected working source and frozen research record.** The one identified methods-description ambiguity has been corrected by the lead editor. No numerical correction, new experiment or change to protected scientific material is required.

**Review date:** 18 November 2026. **Reviewer:** independent Gold Niche methods/evidence agent. **Baseline:** `baseline/Paper7.tex`, SHA-256 `78297924bc2607ef52d01bdfdfb3b244589389c0271f5ca4ea9d6d9208f281b8`. **Inspected integrated source:** `manuscript/Paper7.tex`, SHA-256 `2c5d3a169ab7149c69cb1fa3678168ae00ee36c260e4c36d18ce162946faf342`.

The complete Chief Editor Protocol and Paper Identity and Evidence Brief were read. This review read the entire manuscript source and the primary implementation, specification, benchmark, saved predictions, reference records, source fixtures, pinned suppression test and relevant execution logs. The prior integrated PASS report was used as a locator; its conclusions were checked against primary records.

## 1. New audit work and reused executions

The review performed **new static inspection and independent rescoring of saved outputs**. It did not rerun the frozen experiment. The new `audit_saved_evidence.py` imports no study program. It reads actual reference and prediction records, calculates complete-decision and event agreement, derives half-open activity intervals from the saved active flags, reconstructs intervention inputs from the manuscript's rules, and verifies the original-to-public temporal-packet projection. Its results are in `Raw_Evidence_Audit.json`, `Recomputed_Metrics.csv` and `Read_Input_Hashes.json`.

The archive was freshly read and CRC-checked: 188 entries, no CRC errors, SHA-256 `b55949d177b3355bda1f49442015141ac382e84345b4cc283a7fc4a811a9db48`. A separate direct hash check verified all 173 entries in `PACKAGE_SHA256SUMS`, all 13 in `REVIEW_SHA256SUMS`, and all 58 in each of the `study` and `saved_run` input manifests. These are overlapping manifest scopes, not additive file counts. Every check matched. The record is `Preservation_and_Source_Checks.json`.

The retained execution sequence contains nine commands, their zero exit codes, stdout and stderr files, input hashes and environment. The inspected `saved_run/fresh_execution/result.json` records Python 3.12.14, SQLite 3.53.1, 4,935 traces and 26,430 events. The nine command logs were read. The two representation replays are reused unchanged executions; their source encoders were also inspected. The 585 reported reason differences were independently reconciled to the 510 `POLICY_MISMATCH` and 75 `POLICY_CHANGE` labels in the frozen reference, which this decoder deliberately maps to their context counterparts. No timing value was introduced into the manuscript.

### Primary evidence locators

Within this report, **R/** means `agents/method/frozen/Paper7_Reproduction/`, extracted directly from the locked reproduction ZIP. **H!/** means the `paper7_risk_alarm/` prefix inside `../recovered/LEAP_Paper7_Research_and_Submission_Draft_20261118.zip`. **E/** means `../revision_20261118/evidence/empirical/`.

| Evidence object | Exact source |
|---|---|
| Event, policy and transition contract | R/study/protocol/SEMANTICS.md; R/study/protocol/PROTOCOL.md |
| Incremental implementation and ablations | R/study/implementation/monitor.py:12–75 |
| Original retrospective reference | R/study/implementation/oracle.py:22–130 |
| Corrected reference and regression implementation | R/study/implementation/oracle_v2.py; R/study/reviews/check_reference_v2.py:24–61 |
| Corpus and references | R/study/benchmark/traces.jsonl; reference.jsonl; policy.json |
| Actual primary predictions | R/saved_run/results/predictions.jsonl |
| Witness inputs and references | R/study/benchmark/necessity_witnesses.json; witness_references.json |
| Original generator | ../current/replay_extras/implementation/build_benchmark.py:18–80; build_witnesses.py:5–16 |
| SQL implementation and outputs | R/study/replication_r2/monitor.sql; sqlite_baseline.py:17–54; R/saved_run/replication_r2/predictions.jsonl |
| PyContract encoding and outputs | R/study/r3/baseline/pycontract_baseline.py:44–145; R/saved_run/r3/baseline/predictions.jsonl |
| Concurrent expectations and outputs | R/review_checks/method/targeted_cases.json; E/review_checks/targeted_results.json |
| Historical source fixtures and original reference checks | H!/reviews/archived_alarm_checks.json; reference_checks.json; oracle_v2_correction.json |
| Pinned external test and mapped results | R/study/scp_revision/external_fixture/source/silence_test.go:1372–1443; mapping.json; R/saved_run/scp_revision/external_fixture/results.json |

## 2. Question → method → finding → interpretation

| Question | Method and exact operation | Direct finding | Valid interpretation |
|---|---|---|---|
| Q1: Which version distinctions preserve decisions and reasons? | Four propositions; delete one field at a time from paired inputs; preserve all other visible side inputs; reconstruct six separate comparisons or three joint comparisons and replay the frozen corpus. | Thirty pairs have identical projected inputs and different decision sequences. Each of six separate projection assays has 10 traces, five heterogeneous classes and bound 5/10. Six comparisons reproduce all 4,935 complete sequences, including reasons. Three reproduce 26,430 decision tuples; the explicit decoder changes 585 reason labels. | Raw names can be replaced by the stated comparisons under the defined contract. Decision preservation and reason preservation require different distinctions. The six-comparison construction is sufficient. The pair in Proposition 4 proves that the three-comparison interface cannot recover both mismatch reasons in general. |
| Q2: How do omitted binding and stale-age checks affect warnings and episodes? | Matched packets, policy and categorical severity are supplied to the complete monitor, four reduced monitors and a snapshot comparator. Compare all state/activity/severity tuples; separately compare active intervals, active-event errors, severity and reasons. | Both numerical tables independently reproduce exactly. Removing suppression binding causes 30/987 complete-trace mismatches and 48/5,286 tuple mismatches while preserving 987/987 interval sequences. Removing stale-age rejection yields six missed and 18 unwarranted active events. | Under this constructed policy, an activity-only endpoint misses a real display/severity error. Freshness can affect active decisions in both directions. Each effect is defined against the same reference contract and the disclosed finite corpus. |
| Q3: Do metadata edits and equivalent time-unit changes alter outputs? | For each of 1,645 family-design groups, compare the base output to a metadata variant and a normalized millisecond variant. | Each of six methods preserves all 3,290 complete-output comparisons: 1,645 of each kind. Normalized input equivalence was independently verified. | The implementations preserve the stated transformations. The same checks also pass for reduced implementations that disagree with the reference, so invariance and semantic conformance answer separate questions. |
| Execution support for Q1–Q3 | Retrospective reference, hand-derived checks, schema checks, concurrent-condition cases, SQL and PyContract encodings, external expected suppression Booleans. | Original and corrected reference chronology is preserved; 96/96 concurrent final checks; SQL and PyContract each reproduce 4,935 traces and 26,430 events; four mapped external suppression outcomes agree. | The implementations execute the specified policy consistently across the tested representations. These records support contract conformance and reproducibility. |

All three declared questions have an operation, direct evidence and a supported interpretation. The central contribution has no empty direct-evidence or interpretation cell. Its proof evidence concerns the defined transition contract, and its empirical evidence concerns exact conformance on constructed traces. The literature reviewer must separately decide the contribution's distinction from the closest published work; methods evidence alone does not settle historical novelty.

## 3. Mathematical audit

### Proposition 1: indistinguishable evidence — PASS

`Paper7.tex:167–172` applies a deterministic function to two identical projected inputs. One output cannot equal two unequal required sequences. The output object is explicitly the sequence of state, activity and severity. Policy parameters and remaining side inputs are retained at `:165`. The witness data satisfy both premises; the audit compared the actual projected traces and actual reference tuples. It did not rely on the saved witness PASS field.

### Proposition 2: finite-benchmark bound — PASS

`Paper7.tex:174–183` partitions the finite multiset by projected input and counts the largest required-sequence group in each class. The classes are disjoint, so summing these maxima is the exact best full-trace lookup score and an upper bound for causal monitors. The proof distinguishes lookup attainability from the bound's application to causal monitors. The Limitations section accurately retains causal attainability as unestablished.

The numerical result is **six separate bounds of 5/10**, not a pooled test of one interface over 60 traces. The five classes per field retain the rule identifier and fixed `High` base severity, as specified by the original class audit. The six structural witness pairs are instantiated across five identifiers; they are not described as 30 independent temporal mechanisms. Removing the rule identifier would merge repeated structures without changing the 5/10 bound.

### Proposition 3: six-comparison sufficiency — PASS

`Paper7.tex:194–199` is a valid state induction. Separate current-context and current-policy change indicators determine reset and reset-reason precedence. Separate observation comparisons determine the first applicable mismatch condition. The retained value, times and policy parameters determine observation validity and timer updates. Suppression comparison and expiry determine the overlay. All future-relevant timers and activity are preserved, which completes the induction.

The proof's conditions are explicit: admissible trace; common initial state; correct comparisons; packet presence; observation values; timestamps; expiry; policy and categorical base severity. The producer must have the version information needed to compute those comparisons. The manuscript states this implementation location at `:200` and `:361`. The claim is sufficiency; no minimum of six bits is asserted. In fact, suppression mismatch types share the same reason semantics, which explains why a joint suppression comparison works for that part of the interface.

### Proposition 4: three-comparison decision interface — PASS

`Paper7.tex:202–209` preserves the only version distinctions used by the decision components: any current-pair reset, joint observation applicability and joint suppression applicability. Context-only and policy-only mismatch each yield the same unresolved decision once the retained fields are fixed. The reason counterexample is valid: first events with obsolete observation context versus obsolete observation policy have identical joint mismatch information and different specified reasons. This is a general information collision, independent of the particular retrospective decoder.

The three-comparison replay's 585 discrepancies are correctly reported as the outcome of the explicit decoder that represents all changes/mismatches as context changes/mismatches. Those counts do not assert that every decoder must make 585 errors. The manuscript states this distinction at `:290`.

## 4. Design, inputs, comparators and scoring

The generator contains 256 exhaustive length-four designs, three length-twelve controls, 55 intervention designs and 15 boundary designs for each of five families. The stated durations are `D=C=F=2` seconds and `E=4` seconds. Qualification, clearing, escalation and freshness comparisons are inclusive; suppression expiry is strict. Event time is normalized to seconds. Decisions occur at supplied event times, with contiguous valid observations providing the specified sample-and-hold timer continuity. `monitor.py:31–65`, the retrospective reconstruction at `oracle.py:86–130`, and the SQL recursion implement this order.

The new audit independently rebuilt all 825 intervention representations from the manuscript's 11 operations at indices 2, 3, 5, 7 and 9. Every policy-input field matched after unit normalization. It also checked all 1,645 groups for exactly one base, metadata and millisecond form. The five families instantiate the same 329 normalized templates, and family/source identifiers are disjoint across development and held-out partitions. All 4,935 historical traces match the reproduction traces exactly after removal of snippet text and snippet hash fields; all 18,600 retained Boolean snippet hashes verify.

The comparator definitions match the implementation:

| Comparator | Verified operation | Interpretation of its score |
|---|---|---|
| Version-bound | All specified checks and transitions | Conformance with the specified reference contract |
| Timer-only | Removes version resets and both observation/suppression binding; retains other temporal and quality conditions | Joint effect of those omissions |
| No evidence binding | Keeps resets and timing; ignores observation context/policy mismatch | Effect of accepting obsolete observations under otherwise unchanged processing |
| No suppression binding | Keeps the complete policy except suppression context/policy equality | Effect of accepting an obsolete authorization to hide a warning |
| No freshness | Removes stale-age rejection and retains future-evidence rejection | Effect of accepting stale observations |
| Snapshot | Reads current packet value, emits immediate ACTIVE/CLEAR/UNKNOWN and fixed `SNAPSHOT` reason | Descriptive difference between snapshot and lifecycle interfaces |
| SQLite and PyContract | Separately encode the same policy on the same frozen traces | Retrospective execution conformance, with independent computational representations |

The exact-trace score compares every state/activity/severity tuple. A single differing event makes the whole trace disagree. Interval agreement uses complete lists of half-open active event-index spans, including an open final episode ending at trace length. Missed and unwarranted activity use reference-active and reference-inactive events respectively. `UNKNOWN` is a display state that can preserve activity; it is not a third disjoint category in the active/inactive denominator. The new audit derives all these quantities from the raw output fields.

Exact descriptive counts are appropriate. The corpus is deliberately enumerated and constructed; transformations and family instantiations share temporal structure. No probability sample, inferential hypothesis test, confidence interval, predictive calibration or causal operational effect is claimed. The base-only table gives each of the 987 held-out family-design instances one trace contribution and does not triple this denominator through transformations.

## 5. Numerical findings

### Held-out base endpoints independently recomputed

The common denominator is **987 traces and 5,286 events**, including **1,293 reference-active events, 3,993 reference-inactive events and 1,803 UNKNOWN displays**.

| Method | Trace agreement | Episode agreement | Missed active | Unwarranted active | Tuple errors | Severity errors | Reason errors |
|---|---:|---:|---:|---:|---:|---:|---:|
| Version-bound | 987 | 987 | 0 | 0 | 0 | 0 | 0 |
| Timer-only | 897 | 927 | 0 | 192 | 342 | 342 | 282 |
| No evidence binding | 957 | 969 | 0 | 84 | 204 | 204 | 204 |
| No suppression binding | 957 | 987 | 0 | 0 | 48 | 48 | 48 |
| No freshness | 969 | 975 | 6 | 18 | 51 | 51 | 18 |
| Snapshot | 246 | 246 | 408 | 1,179 | 1,851 | 1,761 | 5,286 |

Both manuscript data tables match this rescore entry for entry. All six methods have zero output failures. The full held-out subset has 2,961 traces and 15,858 events; the complete monitor agrees in all decision components and reasons. The development subset has 1,974 matching traces. Full-corpus SQL and PyContract records each reproduce 4,935 traces and 26,430 events, including 6,465 reference-active and 19,965 reference-inactive events. Each separately passes all 60 witness sequences, 21 hand-derived valid traces and 28 malformed-input probes.

PyContract raw per-trace logs sum to 26,430 upstream dispatcher events and 26,430 state transitions. The state definitions at `pycontract_baseline.py:91–128` correctly distinguish Dormant/Qualifying and Raised/Recovering. It imports the upstream package and neither the incremental monitor nor oracle. `verify_engine_dependency.py:9–19` disables each of `Monitor.eval`, `Monitor.eval_states` and `State.eval`; the retained observations are dispatch-count failures, followed by restored PENDING/ACTIVE output. This supports the manuscript's claim that the integration check fails without these engine dispatch methods. Git blob hashes were recalculated for all nine supplied upstream files and matched the pinned commit record.

### Reference chronology

The original archive records **29 original hand-derived expectations: 21 intended-valid traces and eight malformed-input expectations**. The original freeze is `2026-11-18T15:47:46.012123+00:00`, after development checks and before held-out comparison. The archived AI activity instructions explicitly assign a separate agent to construct the reference from `SEMANTICS.md` without inspecting the monitor.

At `2026-11-18T15:53:37.888243+00:00`, a final reviewer recorded the missing-unit defect: the original reference silently defaulted an absent required unit to seconds. Three intended-valid historical cases had missing-observation events without that field. The version-two regression adds `unit=s` to those three events and preserves all expected outputs. The affected cases are `unknown_before_open_breaks_dwell`, `unknown_active_retained_clock` and `reset_invalid_uses_quality_reason`. The separate v2 schema verification has 28 probes, with recorded `ValueError` outcomes for both reference and incremental monitor; it records zero disagreements with all 4,935 benchmark and 60 witness sequences.

The new audit compared every retained valid expected/actual sequence for both generations. The eight historical malformed-case records retain a named expected exception and a pass flag, rather than complete actual-output objects; inspection of `check_reference_v2.py:51–57` confirms that this flag is set only on caught `ValueError`, and the executed log documents 29/29 completion. The manuscript accurately distinguishes the original expectations from the post-evaluation 21-plus-eight regression and from the separate 28 schema probes. **Retain this chronology unchanged.**

### Concurrent conditions

The 24 separately frozen cases contain 75 events per implementation. The audit compared the final actual decision-and-reason object from each of four implementations to the independently stored `expected_final`, producing **96/96 final checks**. It also compared all four complete output sequences in each case, giving **24/24 full-sequence agreements** over **75 events per implementation**. The study does not claim 300 independently hand-adjudicated event expectations; only the final outputs are hand-derived expectations in this extension. Its current wording reports this distinction correctly.

### Source fixtures and external suppression outcomes

For the 11 historical fixtures, the audit verified fixture hashes, extracted expected rule identifiers from the fixture comments, and compared them to the saved alarm objects' actual `rule_id` fields. All 11 match. The archived source functions at `governance_patch.py:633–708` implement exactly the five lexical predicates described in Table 1. Their rule names and categorical severity labels are inherited identifiers; this evidence evaluates lexical source signals and temporal policy behavior.

The pinned Alertmanager `TestSilencer` contains eight `Mutes` assertions. The four mapped assertions are at source lines 1383, 1392, 1402 and 1408 and require `false, false, true, false`. Their retained source has freshly recomputed Git blob `a65b1f6337723d3ba76140081b757088213f7d5a`. The mapped temporal inputs establish activity before the query. Saved actual displays reproduce all four expectations, all four activation setups and all four complete reference sequences, with zero failures. The matching-silence projection retains the matching candidate when the source also retains a nonmatching candidate. This is stated in the manuscript. The four remaining source assertions concern scheduling/activation and overlapping or regular-expression silences; the manuscript locates them in Limitations. No Alertmanager execution or broader external-policy validation is claimed.

## 6. Issue and closure register

| ID | Finding and exact location | Primary evidence | Interpretation | Severity | Required action and closure | Access/confidence |
|---|---|---|---|---|---|---|
| M01 | Baseline §3.2, `Paper7.tex:135`: “Opposite findings reset the corresponding qualification run” does not clearly name interruption of clearing. | `monitor.py:49` sets negative timer to None on valid positive; `:54` clears positive timer on valid negative. `SEMANTICS.md` step 4 and `oracle.py:97–105` agree. | Both reset directions belong in the operation description. | MINOR, precise methods clarification | Replace with “A valid negative finding resets qualification, and a valid positive finding resets clearing.” Lead integrated this exact sentence; confirmed present in inspected working source. **CLOSED.** | Direct code and source, high confidence |
| M02 | Original 29 cases, later 21+8 regression and 28 schema probes have distinct chronology. | H!/reviews/reference_checks.json; H!/reviews/oracle_v2_correction.json; R/study/reviews/reference_checks_v2.json; executed regression log. | Current manuscript accurately reports all three scopes. | VERIFIED RECORD | Preserve current wording. No correction. | Original archive and later raw/log records inspected |
| M03 | Three-comparison decoder changes 585 reasons; six comparisons preserve reasons. | Representation encoder sources; retained replay logs; independently counted 510 policy mismatch and 75 policy change reference labels; Proposition 4 collision. | Decoder-specific counts support the implementation check; the proof supplies the general impossibility example. | VERIFIED RECORD | Preserve distinction between specific decoder counts and general collision. | Source and executed logs; no new replay required |
| M04 | Shared 329 templates across five families. | Independent normalized comparison of all templates and source/family split sets. | Held-out score measures conformance across family instances. | VERIFIED RECORD | Preserve current design and Limitations wording. | Full frozen corpus inspected |
| M05 | Retained proof, formula, table and archive identities remain exact. | `Preservation_and_Source_Checks.json` and fresh archive checks. | The one prose repair preserves the protected scientific record. | VERIFIED RECORD | Production reviewer should bind final PDF/package to final source after any later permitted edits. | Source and archive verified; PDF rendering belongs to production review |

No unresolved methods or numerical finding remains. The proposed symmetric reset wording changes explanation only and leaves the formal contract and scored outputs intact.

## 7. Gate decisions

| Gate | Verdict | Evidence and exact scope |
|---|---|---|
| G2, methods/evidence portion | **PASS** | Four sound propositions; complete Q→method→finding trace; central claims have direct proof or saved-output evidence; no inferential promotion from conformance to operational benefit. Closest-work novelty is assigned to the literature reviewer. |
| G6 Methods | **PASS** | Actual inputs, constructed coverage, partition, transitions, ablations, reference chronology, metrics and retrospective checks are described. Symmetric timer-reset wording was corrected and verified. |
| G7 Results | **PASS** | Independent full raw rescore reproduces all study-table values, denominators and transformations; witness bounds, intervention grid, concurrency, engine records and mapped fixture outcomes match. Descriptive uncertainty treatment fits a fixed constructed corpus. |
| G9 Preservation | **PASS** | Four propositions, four proofs, two displayed equations and five tabular data blocks are byte-identical between baseline and inspected integrated source; the locked ZIP remains exact; all manifest checks pass. |

## 8. Production handoff

The complete numerical/source ledger is `NUMERICAL_SOURCE_LEDGER.md`. The new raw rescore and its script are separate from the preserved research archive. The extracted `frozen/` directory is an audit workspace; the archive itself was not edited.

Known editable figure sources already located are `gold_niche_20261118/figures/{method_pipeline,necessity_witness,trace_mismatches}.svg`, with earlier sources under `../current/r3/visual/method_pipeline.svg`, `../current/figures/necessity_witness.svg` and `../current/scp_revision/figures/trace_mismatches.svg`. No original figure-generation program was located during this methods audit; locating or changing one was outside this pass.

## Limitations of this review

This is a methods/evidence review of the stated constructed-policy contribution. The source content inspected is the preserved local primary record; no live software service was executed. The original AI-agent separation is documented by assigned instructions and provenance, not enforced filesystem isolation. Original eight-case malformed regression outputs are retained as exception-match flags with source and executed-log support, while the separate 28-case schema record retains explicit observed exception names. The full manuscript's literature claims, venue rules and final rendered PDF are assigned to the relevant reviewers. A later source change needs a bounded recheck of the affected claim; the G9 decision above is bound to the exact working-source hash stated at the beginning.

## 9. Final integrated source signoff

**Final decision: G6 PASS, G7 PASS, G9 PASS, and the evidence/methods portion of G2 PASS.** This final signoff is bound to `manuscript/Paper7.tex` SHA-256 **`648c1113570430b4ec93bb8906f6503389d6693ea59eb16f4ba44ea2f0076dd9`** and supersedes the earlier intermediate source identity for these gates. The final recheck inspected every change from the authoritative baseline and independently compared the protected source blocks. It did not repeat any study execution or raw-output rescore.

The final Results, Discussion and Conclusion sections are byte-identical to the audited baseline. The abstract, four propositions, four proofs and two displayed equations also remain byte-identical. The four scientific table bodies—recovered source predicates, intervention taxonomy, complete/episode agreement and attribute discrepancies—remain byte-identical. Table 2 is the intentionally expanded qualitative literature comparison; its new predecessor rows and separated source descriptions do not alter the method, studied population, measured endpoints or contribution's evidential reach.

The symmetric reset sentence remains exact and correctly states both timer interruptions. The original-reference/v2 chronology and all benchmark, schema, concurrency, representation and external-fixture denominators are unchanged. Replacing the internal paper number with “review-policy context” and “study implementations” preserves the externally mapped fixture's meaning. The shortened AI workflow passage retains the relevant provenance disclosures, and the retained source still identifies separate reference construction from the specification.

The added figure-code description was checked against `agents/production/reproduce_figures.py` and its existing `figure_reproduction/Figure_Data_and_Render_Verification.json`. The script reads the locked archive's saved inputs and predictions, calculates the held-out base mismatch counts, checks SVG labels and plotted coordinates, and exports the retained SVGs through Inkscape. Its recorded execution identifies Inkscape 1.4 and original SVG creator metadata Matplotlib 3.10.8. These additions describe verification of the existing figures and preserve the study evidence.

The reproduction archive was rehashed directly and remains `b55949d177b3355bda1f49442015141ac382e84345b4cc283a7fc4a811a9db48`. The root's `validation/Preservation_and_Reference_Verification.json` was inspected alongside this independent final check. The source-bound machine record is `agents/method/Final_Source_Method_Signoff.json`.

| Final gate | Verdict | Final-source evidence |
|---|---|---|
| G2 evidence/methods | **PASS** | Central proof and output evidence remain unchanged; added predecessor context preserves the precise contract-specific contribution. |
| G6 Methods | **PASS** | Corrected reset description, reference chronology, comparator definitions and added figure verification procedure match the inspected implementations and retained records. |
| G7 Results | **PASS** | Entire Results section and its scientific table data are unchanged from the independently rescored source. Discussion and Conclusion preserve the audited inferential reach. |
| G9 Preservation | **PASS** | Protected mathematics, abstract and four scientific table bodies are exact; the intentional Table 2 literature expansion is identified; locked archive hash is unchanged. |

**No methods, numerical or preservation blocker remains in this final integrated source.**
