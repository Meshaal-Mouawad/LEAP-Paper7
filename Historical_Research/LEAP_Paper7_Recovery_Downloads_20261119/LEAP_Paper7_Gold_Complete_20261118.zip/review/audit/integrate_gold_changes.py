from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / 'manuscript/Paper7.tex'
text = path.read_text()

def replace(old, new):
    global text
    assert text.count(old) == 1, (old[:100], text.count(old))
    text = text.replace(old, new)

replace(r'\usepackage{float}', r'\usepackage{float,longtable}')

anchor = r'\subsection{Temporal monitoring and explanations}'
paragraph = r'''Antignac et al. formalize a data preprocessor that preserves a program's output and give a procedure for constructing such preprocessors. Their ordering compares the input distinctions retained for a fixed output function \cite{antignac2017minimisation}. Here, the two output functions are the event decision and that decision with its prescribed reason; Propositions~3 and~4 establish concrete comparison encodings for the review lifecycle.

'''
replace(anchor, paragraph + anchor)

anchor = r'Companion LEAP studies examine checks on generated KPI documentation'
paragraph = r'''Version-sensitive exceptions also occur in analysis tools. The \code{skill-audit} implementation binds a suppression to a fingerprint of the source, evidence, rule and scanner version; a changed fingerprint reactivates the finding. Its reports retain the finding and record the suppression separately \cite{skillaudit2026suppression}. These mechanisms establish revision-scoped exception handling. The present analysis determines which comparisons preserve the complete temporal decision and its specified reason.

'''
replace(anchor, paragraph + anchor)

start = text.index('\\begin{table}[H]', text.index('\\subsection{Versioned evidence'))
end = text.index('\\end{table}', start) + len('\\end{table}')
rows = r'''RTLola \cite{baumeister2026rtlola} & Stream specifications and asynchronous inputs; derived streams, static analyses and executable monitor construction. & Stream values and Boolean notification triggers. \\
Vamos \cite{chalupa2025vamos} & Heterogeneous event sources; preprocessing, buffering and explicit gaps or summaries when observations are lost. & Events and loss information supplied to downstream monitors. \\
Abstract TeSSLa \cite{leucker2019partial} & Timed streams with gaps or imprecise values; abstract operators and analysis of compositional precision. & Sound abstract outputs; operator-level perfection and selected perfect compositions. \\
Abstract monitors \cite{henzinger2022abstract} & Equivalence classes of observation prefixes; precision and resource requirements for quantitative monitors. & Common outputs for indistinguishable histories; bounds relating prompt error to specification-value separation. \\
Property-preserving Java models \cite{jevitha2024abstract} & User-defined data and control abstractions of execution-state models. & Preserved predicates and path conditions for runtime verification on reduced models. \\
Data minimisation \cite{antignac2017minimisation} & A program's input domains and output function; construction and comparison of output-preserving preprocessors. & The program's output with reduced input distinctions. \\
CauMon \cite{zhang2026caumon} & Signal traces and temporal requirements; online monitoring with causation semantics. & A verdict identifying the relevance of incoming observations to satisfaction or violation. \\
WhyMon \cite{lima2024explainable} & Metric first-order temporal requirements and event traces; proof-tree construction with a verified checker. & Explanations certifying satisfaction or violation. \\
Changing-requirement monitoring \cite{carwehl2023changing} & Requirement changes in self-adaptive systems; adaptation through timed-automata patterns. & Updated verification behavior with transfer of relevant monitor state. \\
Audit-as-Code \cite{muhammad2026audit} & Versioned policy and schema-checked evidence bundles; deterministic assurance gates. & Pass/warn/block decisions with policy-linked evidence. \\
Compliance-as-Code \cite{nwekeyeng2026compliance} & Control, release, environment and time-bound evidence; provenance and fixed-window completeness checks. & Evidence-linked findings and machine-readable assessment artifacts. \\
Temporal engineering compliance \cite{ratiu2026runtime} & Changes to related engineering artifacts; incremental checking of temporal constraints. & Feedback on process deviations as artifact histories evolve. \\
Alertmanager \cite{prometheus2026alertmanager} & Active alerts, label matchers and temporary silences. & Notification suppression separated from stored active alerts. \\
\code{skill-audit} \cite{skillaudit2026suppression} & Source, evidence, rule and scanner fingerprints; exact suppression matching with expiry. & Findings retained in reports with separate suppression annotations. \\
Present study & Current, observation and suppression bindings; interface projections and a specified review lifecycle. & Necessary applicability distinctions, sufficient comparison representations, complete decision sequences and active-episode intervals. \\
'''
table = r'''{\small
\setlength{\tabcolsep}{4pt}
\renewcommand{\arraystretch}{1.12}
\setlength{\LTleft}{0pt}
\setlength{\LTright}{0pt}
\begin{longtable}{@{}>{\raggedright\arraybackslash}p{.235\linewidth}>{\raggedright\arraybackslash}p{.38\linewidth}>{\raggedright\arraybackslash}p{\dimexpr.385\linewidth-4\tabcolsep\relax}@{}}
\caption{Comparison of input abstractions, monitored objects, and output contracts established in the cited sources.}\label{tab:related-matrix}\\
\toprule
Approach & Input and established operation & Decision or evidential object \\
\midrule
\endfirsthead
\multicolumn{3}{l}{Table~\thetable\ (continued)}\\
\toprule
Approach & Input and established operation & Decision or evidential object \\
\midrule
\endhead
\midrule
\multicolumn{3}{r}{Continued on next page}\\
\endfoot
\bottomrule
\endlastfoot
''' + rows + r'''\end{longtable}
}'''
text = text[:start] + table + text[end:]

replace(r'Release-linked evidence contracts and label-scoped silences provide independent precedents for these choices \cite{nwekeyeng2026compliance,prometheus2026alertmanager}.', r'Release-linked evidence contracts, revision-sensitive suppressions and label-scoped silences provide independent precedents for these choices \cite{nwekeyeng2026compliance,skillaudit2026suppression,prometheus2026alertmanager}.')

replace(r'''\paragraph{AI-assisted research workflow}
ChatGPT and Codex assisted with source recovery, implementation, reference construction, experiment orchestration, and analysis. The archived activity record identifies the assigned prompts, agent roles, and available settings. Separate AI sessions authored and checked the reference from the written contract. Deterministic programs produced every scored decision, and the retained inputs and programs support replay of those decisions.''', r'''ChatGPT and Codex assisted with source recovery, implementation, reference construction, experiment orchestration, and analysis. Deterministic programs produced every scored decision, and the retained inputs and programs support replay of those decisions.''')
path.write_text(text)

bibpath = ROOT / 'manuscript/Paper7_References.bib'
bib = bibpath.read_text()
assert 'antignac2017minimisation' not in bib and 'skillaudit2026suppression' not in bib
bib += r'''

@inproceedings{antignac2017minimisation,
  author = {Antignac, Thibaud and Sands, David and Schneider, Gerardo},
  title = {Data Minimisation: A Language-Based Approach},
  booktitle = {ICT Systems Security and Privacy Protection},
  series = {IFIP Advances in Information and Communication Technology},
  volume = {502},
  pages = {442--456},
  publisher = {Springer},
  year = {2017},
  doi = {10.1007/978-3-319-58469-0_30}
}

@misc{skillaudit2026suppression,
  author = {{skill-audit contributors}},
  title = {Finding Fingerprints and Governed Suppressions},
  year = {2026},
  howpublished = {skill-audit source repository},
  note = {Commit e2e9ad679b8a0459bbb4bfad39621435aa354002; accessed 18 November 2026},
  url = {https://github.com/harrypham2000/skill-audit/blob/e2e9ad679b8a0459bbb4bfad39621435aa354002/skill-audit/src/suppress.ts}
}
'''
bibpath.write_text(bib)
print('Integrated Gold literature, study-comparison, contract-context and authorial-voice repairs.')
