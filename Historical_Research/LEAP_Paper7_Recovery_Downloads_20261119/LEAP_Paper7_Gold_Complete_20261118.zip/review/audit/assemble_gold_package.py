"""Assemble and verify the complete Gold research/editing record."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]
PROJECT=ROOT.parent
OUT=ROOT/'deliverables'
PACKAGE=ROOT/'package/LEAP_Paper7_Gold_Complete_20261118'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def put(src,dest):
    dest=PACKAGE/dest
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dest)
def write(dest,text):
    p=PACKAGE/dest;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text.strip()+'\n')

prod=json.loads((ROOT/'agents/production/Final_Production_Gates.json').read_text())
identity=json.loads((ROOT/'validation/final_identity.json').read_text())
assert prod['G8']==prod['G10']=='PASS'
assert prod['source_sha256']==identity['files']['Paper7.tex']
assert prod['final_pdf_sha256']==identity['files']['Paper7.pdf']
assert prod['all_pages_text_equal_after_independent_build'] and prod['all_pages_pixel_equal_at_130_dpi']
assert len(prod['all_pages_visually_inspected'])==21
report_review=ROOT/'agents/production/Report_Visual_Review.json'
assert report_review.exists(),'Wait for report visual review before packaging.'
review=json.loads(report_review.read_text())
assert review['status']=='PASS',review
assert review['report_sha256']==sha(OUT/'LEAP_Paper7_Gold_Review_20261118.pdf')

if PACKAGE.exists(): shutil.rmtree(PACKAGE)
PACKAGE.mkdir(parents=True)

for p in sorted((ROOT/'manuscript').iterdir()):
    if p.name in identity['files']: put(p,'manuscript/'+p.name)
for p in sorted((ROOT/'figures').glob('*.svg')):put(p,'figures/'+p.name)
for name in ['reproduce_figures.py','README.md']:
    put(ROOT/'agents/production'/name,'figures/'+name)
put(ROOT/'agents/production/figure_reproduction/Figure3_Data.csv','figures/Figure3_Data.csv')
for p in sorted((ROOT/'baseline').iterdir()):
    if p.is_file():put(p,'baseline/'+p.name)
put(ROOT/'instructions/Gold_Niche_Chief_Editor_Protocol.md','instructions/Gold_Niche_Chief_Editor_Protocol.md')
put(ROOT/'audit/Baseline_Identity.json','review/audit/Baseline_Identity.json')
for p in sorted((ROOT/'audit').glob('*.py')):put(p,'review/audit/'+p.name)
for p in sorted((ROOT/'reports').iterdir()):
    if p.is_file():put(p,'review/reports/'+p.name)
for role in ['venue','novelty','method','reader','production']:
    folder=ROOT/'agents'/role
    for p in sorted(folder.iterdir()):
        if p.is_file() and p.suffix in ['.md','.json','.csv','.py','.tex']:
            put(p,'review/agents/'+role+'/'+p.name)
for p in sorted((ROOT/'agents/novelty/sources').rglob('*.json')):
    put(p,'review/agents/novelty/sources/'+p.relative_to(ROOT/'agents/novelty/sources').as_posix())
for sub in ['figure_reproduction','final_source_check']:
    folder=ROOT/'agents/production'/sub
    for p in sorted(folder.iterdir()):
        if p.is_file() and p.suffix in ['.json','.csv','.log']:
            put(p,'review/agents/production/'+sub+'/'+p.name)
for p in sorted((ROOT/'validation').iterdir()):
    if p.is_file() and p.suffix in ['.json','.log'] and 'library' not in p.name.lower() and p.name!='Complete_Package_Verification.json':
        put(p,'validation/'+p.name)

prior=PROJECT/'manuscript_suite_20261118'
for name in ['Bibliography_and_Claim_Audit.md','Published_Article_Benchmark.md']:
    put(prior/'reports'/name,'review/prior_audits/'+name)
put(prior/'package/LEAP_Paper7_Prompt_Suite_20261118/editorial/Author_Statements_To_Complete.md','review/prior_audits/Author_Statements_To_Complete.md')
put(PROJECT/'current/submission/Author_and_Declarations.md','review/prior_audits/Original_Author_and_Declarations.md')

repro=PROJECT/'revision_20261118/deliverables/LEAP_Paper7_Reproduction_20261118.zip'
assert sha(repro)=='b55949d177b3355bda1f49442015141ac382e84345b4cc283a7fc4a811a9db48'
put(repro,'research/'+repro.name)
historical=PROJECT/'recovered/LEAP_Paper7_Research_and_Submission_Draft_20261118.zip'
put(historical,'recovered/'+historical.name)
put(PROJECT/'revision_20261118/evidence/empirical/review_checks/targeted_results.json','revision_20261118/evidence/empirical/review_checks/targeted_results.json')
history=prior/'deliverables/LEAP_Paper7_Prompt_Suite_Complete_20261118.zip'
assert sha(history)=='190ffd2df41bffbbe78e8f818c08464d50fbc1d528ca388239789f71156583b3'
put(history,'history/'+history.name)

for p in sorted((ROOT/'submission/Journal_Files').iterdir()):put(p,'journal_files/'+p.name)
for ext in ['pdf','md']:
    p=OUT/('LEAP_Paper7_Gold_Review_20261118.'+ext);put(p,p.name)

activity={
 'date':'2026-11-18','task':'Gold Niche Chief Editor Protocol for Paper7',
 'tools':'OpenAI ChatGPT/Codex; deterministic Python, TeX, SVG and PDF tools',
 'exposed_assistant_label':'GPT-6 Astra Pro','exact_model_build':None,'temperature':None,'seed':None,
 'model_configuration':'Specialist agents inherited parent configuration; no model override was requested.',
 'specialist_roles':{'gold_venue':'B: venue and journal benchmark','gold_novelty':'C: literature and novelty','gold_method':'D: methods and evidence','gold_reader':'E: unfamiliar reader and narrative','gold_production':'F: figures, LaTeX and reproducibility'},
 'lead_responsibility':'Only the lead edited the unified manuscript and issued final gates.',
 'new_executions':['Independent raw saved-output audit','Figure raw-count/SVG verification and export','Main and isolated LaTeX builds','PDF/page/reference/archive checks'],
 'original_study_rerun_this_pass':False,
 'historical_version_provenance':'Original exact model builds were unavailable in retained logs. Later model-family labels are not attributed to original figure generation.',
 'final_source_sha256':identity['files']['Paper7.tex'],'final_pdf_sha256':identity['files']['Paper7.pdf'],
 'approved_responsibility_sentence':'The author takes responsibility for the content of the article.',
 'external_submission_or_publication':False,
}
write('provenance/AI_ACTIVITY_GOLD_20261118.json',json.dumps(activity,indent=2))
for p in sorted((prior/'package/LEAP_Paper7_Prompt_Suite_20261118/provenance').glob('*.json')):
    put(p,'provenance/prior/'+p.name)
for name in ['AI_ACTIVITY_RECORD_ORIGINAL.json','AI_ACTIVITY_REVISION_20261118.json']:
    put(PROJECT/'revision_20261118/package_stage/LEAP_Paper7_Revision_20261118/provenance'/name,'provenance/prior/'+name)

write('README.md',r'''
# LEAP Paper 7 - complete Gold revision

18 November 2026. **COMPLETE WITH RECORDED VENUE/ADMIN CHECK.**

Start with `LEAP_Paper7_Gold_Review_20261118.pdf` and
`manuscript/Paper7.pdf`. The report explains the completed work and the exact
remaining venue/author facts. The manuscript is the final 21-page revision.

## Contents

- `manuscript/`: final source, PDF, bibliography/BBL, class/style and approved PDF figures.
- `figures/`: unchanged editable SVG artwork, independently checked plot data and export/verification script.
- `journal_files/`: clean manuscript PDF, flat LaTeX source ZIP, locked research supplement, cover letter and highlights.
- `review/reports/`: identity brief, full protocol execution register, source/bibliography diffs, change/closure register, gates and administrative record.
- `review/agents/`: five specialist reports with source-level, method, reader and production evidence.
- `review/prior_audits/`: retained earlier claim/benchmark/declaration records. The new venue report corrects two benchmark details.
- `validation/`: final identities, preservation checks, package checks and build records.
- `research/`: unchanged executable reproduction ZIP.
- `recovered/` and `revision_20261118/`: exact original historical inputs required by the new independent saved-output audit.
- `baseline/`: the authoritative 20-page pre-Gold manuscript and source assets.
- `history/`: the entire preceding prompt-suite completion package.
- `instructions/`: the exact attached Gold Niche protocol.
- `provenance/`: actual current and historical AI activity records.

Primary external publication URLs, access outcomes and retrieval hashes are in
the novelty source ledger/search log and venue access ledger. Local source names
in those reports identify the originals inspected in this session. Repository
commit and blob identities are retained in their retrieval metadata.

## Build the manuscript

For the cleanest build, extract the flat source ZIP in `journal_files/` and run:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error Paper7.tex
```

The independent production review records the actual successful build environment
and verifies exact text/rendered-page equivalence with the delivered PDF.

## Replay the preserved study

Extract `research/LEAP_Paper7_Reproduction_20261118.zip`. From its
`Paper7_Reproduction` directory:

```sh
python -B run_all.py ../paper7-run
```

The archive retains its original entry point, inputs, outputs, source/licenses
and execution logs. The Gold phase independently rescored saved outputs and
preserved earlier actual executions.

## Repeat the independent saved-output audit

From this complete package directory:

```sh
python -m zipfile -e research/LEAP_Paper7_Reproduction_20261118.zip review/agents/method/frozen
python review/agents/method/audit_saved_evidence.py
```

This audit imports no study implementation. It uses the extracted frozen data,
the original `recovered/` archive and the retained targeted-check JSON. It writes
the raw evidence audit, metric CSV and read-input hashes in its own directory.
Absolute paths in the originally delivered JSON describe the inspected workspace;
new execution records will identify the directory where this package is extracted.

## Repeat the figure audit/export

```sh
python figures/reproduce_figures.py --archive research/LEAP_Paper7_Reproduction_20261118.zip --svg-dir figures --output-dir figure-reproduction --previews
```

See `figures/README.md` for dependencies. The script independently checks plotted
counts and SVG data positions, then exports the retained artwork to a separate
directory. Approved manuscript PDF figures are preserved. Export metadata may vary.

## Preservation and current administrative checks

All protected theory, numerical tables, Results/Discussion/Conclusion, figure
assets and the locked research archive retain their identities. Qualitative
Table 2 and the targeted literature/method/provenance wording have the documented
changes. The final bibliography contains 28 cited entries.

`review/reports/Venue_and_Author_Checks.md` lists the live journal guide, author-only
declarations and unavailable historical AI build identifiers. No submission or
publication was performed. SHA256SUMS covers every other file in this package.
''')

payloads=[p for p in sorted(PACKAGE.rglob('*')) if p.is_file()]
write('SHA256SUMS','\n'.join(f'{sha(p)}  {p.relative_to(PACKAGE).as_posix()}' for p in payloads))
target=OUT/'LEAP_Paper7_Gold_Complete_20261118.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(PACKAGE.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(PACKAGE).as_posix())
with zipfile.ZipFile(target) as z:
    names=z.namelist()
    assert len(names)==len(set(names)) and z.testzip() is None
    for info in z.infolist():
        p=PurePosixPath(info.filename)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in info.filename
        assert (info.external_attr>>16)&0o170000!=0o120000
    rows=[line.split('  ',1) for line in z.read('SHA256SUMS').decode().splitlines()]
    assert {n for _,n in rows}==set(names)-{'SHA256SUMS'}
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h for h,n in rows)
    assert hashlib.sha256(z.read('research/'+repro.name)).hexdigest()==sha(repro)
    assert hashlib.sha256(z.read('manuscript/Paper7.pdf')).hexdigest()==identity['files']['Paper7.pdf']
    assert hashlib.sha256(z.read('journal_files/LEAP_Paper7_Gold_LaTeX_20261118.zip')).hexdigest()==prod['source_zip_sha256']
record={'file':target.name,'bytes':target.stat().st_size,'sha256':sha(target),'entries':len(names),'manifest_payloads':len(rows),'crc':'PASS','safe_paths':'PASS','all_payload_hashes':'PASS','nested_reproduction_identity':'PASS','final_source_and_pdf_identity':'PASS'}
(ROOT/'validation/Complete_Package_Verification.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
