"""Verify preserved science and package the final Gold manuscript."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import shutil
import zipfile
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
PRIOR = ROOT.parent / 'manuscript_suite_20261118'
OUT = ROOT / 'deliverables'
OUT.mkdir(exist_ok=True)
LOCK = 'b55949d177b3355bda1f49442015141ac382e84345b4cc283a7fc4a811a9db48'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write(p, text):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text.strip() + '\n')

def manifest(folder):
    paths = [p for p in sorted(folder.rglob('*')) if p.is_file() and p.name != 'SHA256SUMS']
    write(folder/'SHA256SUMS', '\n'.join(f'{sha(p)}  {p.relative_to(folder).as_posix()}' for p in paths))

def zipped(folder, path):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(folder.rglob('*')):
            if p.is_file(): z.write(p, p.relative_to(folder).as_posix())
    with zipfile.ZipFile(path) as z:
        names=z.namelist()
        assert len(names)==len(set(names)) and z.testzip() is None
        for name in names:
            p=PurePosixPath(name)
            assert not p.is_absolute() and '..' not in p.parts and '\\' not in name
        if 'SHA256SUMS' in names:
            records=[line.split('  ',1) for line in z.read('SHA256SUMS').decode().splitlines()]
            assert {name for _,name in records} == set(names)-{'SHA256SUMS'}
            assert all(hashlib.sha256(z.read(name)).hexdigest()==digest for digest,name in records)
    return {'filename':path.name,'bytes':path.stat().st_size,'sha256':sha(path),'entries':len(names),'crc':'PASS','safe_paths':'PASS'}

base=(ROOT/'baseline/Paper7.tex').read_text()
current=(ROOT/'manuscript/Paper7.tex').read_text()
checks={}
for kind,expected in [('proposition',4),('proof',4),('equation',2),('abstract',1)]:
    pattern=r'\\begin\{'+kind+r'\}.*?\\end\{'+kind+r'\}'
    a=re.findall(pattern,base,re.S); b=re.findall(pattern,current,re.S)
    assert len(a)==expected and a==b,kind
    checks[kind]={'count':len(a),'byte_identical':True}
for key in ['title','author','ead','address']:
    pattern=r'^\\'+key+r'.*$'
    assert re.findall(pattern,base,re.M)==re.findall(pattern,current,re.M),key
checks['author_and_title']='PASS'
tables={}
for label in ['recovery','intervention-taxonomy','results','attributes']:
    def get(source):
        start=source.rfind('\\begin{table}',0,source.index('\\label{tab:'+label+'}'))
        end=source.index('\\end{table}',start)
        block=source[start:end]
        return re.search(r'\\begin\{(tabularx?)\}.*?\\end\{\1\}',block,re.S).group(0)
    assert get(base)==get(current),label
    tables[label]='byte identical'
checks['protected_table_bodies']=tables
checks['related_work_table']='Intentional source-grounded correction: 15 individual rows; same table number.'
for name in ['method_pipeline','necessity_witness','trace_mismatches']:
    assert sha(ROOT/'manuscript'/f'{name}.pdf')==sha(ROOT/'baseline'/f'{name}.pdf')
    assert sha(ROOT/'figures'/f'{name}.svg')==sha(PRIOR/'figures'/f'{name}.svg')
checks['figure_pdf_and_svg_assets']='All three pairs unchanged'
sentence='The author takes responsibility for the content of the article.'
assert current.count(sentence)==base.count(sentence)==1
assert '1.924' not in current
checks['approved_ai_sentence']='verbatim; unsupported historical timing remains absent'
bib=(ROOT/'manuscript/Paper7_References.bib').read_text()
keys=set(re.findall(r'@\w+\s*\{\s*([^,]+)',bib))
cited=set()
for entry in re.findall(r'\\cite(?:\[[^]]*\])?\{([^}]+)\}',current): cited.update(entry.split(','))
assert keys==cited and len(keys)==28,(keys-cited,cited-keys)
checks['references']={'active_bib_entries':len(keys),'cited_keys':len(cited),'unresolved_keys':[]}
repro=ROOT.parent/'revision_20261118/deliverables/LEAP_Paper7_Reproduction_20261118.zip'
assert sha(repro)==LOCK
with zipfile.ZipFile(repro) as z:
    assert len(z.namelist())==188 and z.testzip() is None
checks['locked_reproduction']={'sha256':LOCK,'entries':188,'crc':'PASS'}
pdf=ROOT/'manuscript/Paper7.pdf'
reader=PdfReader(pdf)
pdftext='\n'.join(p.extract_text() or '' for p in reader.pages)
assert '(??)' not in pdftext and 'Reference ??' not in pdftext
assert len(re.findall(r'\\begin\{figure\}',current))==3
assert len(re.findall(r'\\begin\{table\}',current))+len(re.findall(r'\\begin\{longtable\}',current))==5
checks['structure']={'pages':len(reader.pages),'tables':5,'figures':3,'propositions':4,'abstract_words':len(re.search(r'\\begin\{abstract\}(.*?)\\end\{abstract\}',current,re.S).group(1).split()),'keywords':6}
files=['Paper7.tex','Paper7.pdf','Paper7_References.bib','Paper7.bbl','elsarticle.cls','unsrtnat.bst','method_pipeline.pdf','necessity_witness.pdf','trace_mismatches.pdf']
identity={'version':'Gold Niche revision, 18 November 2026','pages':len(reader.pages),'files':{name:sha(ROOT/'manuscript'/name) for name in files}}
write(ROOT/'validation/final_identity.json',json.dumps(identity,indent=2))
write(ROOT/'validation/Preservation_and_Reference_Verification.json',json.dumps(checks,indent=2))
shutil.copy2(pdf,OUT/'LEAP_Paper7_Gold_Revision_20261118.pdf')
stage=ROOT/'submission/LaTeX_Source'
if stage.exists(): shutil.rmtree(stage)
stage.mkdir(parents=True)
for name in files:
    if name!='Paper7.pdf': shutil.copy2(ROOT/'manuscript'/name,stage/name)
for name in ['method_pipeline','necessity_witness','trace_mismatches']:
    shutil.copy2(ROOT/'figures'/f'{name}.svg',stage/f'{name}.svg')
shutil.copy2(ROOT/'agents/production/reproduce_figures.py',stage/'reproduce_figures.py')
shutil.copy2(ROOT/'agents/production/README.md',stage/'Figure_Reproduction_README.md')
shutil.copy2(ROOT/'agents/production/figure_reproduction/Figure3_Data.csv',stage/'Figure3_Data.csv')
write(stage/'README.md',r'''
# Paper 7 - editable Gold revision

Version: 18 November 2026. Main source: `Paper7.tex`.
All source files, bibliography, class, style and figure assets are at one folder level.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error Paper7.tex
```

Use a standard LaTeX installation with the packages listed in the source,
including longtable. The generated BBL, elsarticle class and unsrtnat style are
included. Preserve the original license notices within the class and style.
The three PDF figures are the approved assets used by the manuscript. Matching
editable SVGs are included. Their original metadata identifies Matplotlib 3.10.8.

To recompute the plotted counts from saved outputs and export the SVGs:

```sh
python reproduce_figures.py --archive ../LEAP_Paper7_Reproduction_20261118.zip --svg-dir . --output-dir ../figure-reproduction --previews
```

See Figure_Reproduction_README.md for dependencies. Re-exported PDF metadata may
differ; this verification preserves the scientific values and vector artwork.
The locked research archive is supplied beside this source ZIP in the clean
journal-file bundle. Extract it and run from its Paper7_Reproduction directory:

```sh
python -B run_all.py ../paper7-run
```

The Gold review retains the frozen archive byte for byte. It adds independent
raw-output rescoring, literature and source audits, reader review and production
checks. Those records and the substantive diff are in the complete Gold package.
SHA256SUMS covers every payload file in this source ZIP.
''')
manifest(stage)
sourcezip=OUT/'LEAP_Paper7_Gold_LaTeX_20261118.zip'
source_record=zipped(stage,sourcezip)
clean=ROOT/'submission/Journal_Files'
if clean.exists(): shutil.rmtree(clean)
clean.mkdir(parents=True)
for p in [OUT/'LEAP_Paper7_Gold_Revision_20261118.pdf',sourcezip,repro]: shutil.copy2(p,clean/p.name)
for name in ['Cover_Letter.txt','Highlights.txt']:
    shutil.copy2(PRIOR/'submission/Journal_Files'/name,clean/name)
journal_record=zipped(clean,OUT/'LEAP_Paper7_Gold_Submission_Files_20261118.zip')
write(ROOT/'validation/Manuscript_Package_Verification.json',json.dumps({'source':source_record,'journal':journal_record,'structure':checks['structure'],'locked_reproduction_sha256':LOCK},indent=2))
print(json.dumps({'source':source_record,'journal':journal_record,'structure':checks['structure']},indent=2))
