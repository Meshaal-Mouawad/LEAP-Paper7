# Paper 7 declarations

## Manuscript declaration

Place immediately before the references.

**Declaration of generative AI and AI-assisted technologies in the manuscript preparation process**

During preparation of this work, the author used OpenAI ChatGPT and Codex for manuscript drafting and editorial review. The author takes responsibility for the content of the article.

Add “The author reviewed and edited the manuscript as needed.” before the responsibility sentence once the author has reviewed the final manuscript and can confirm the statement. The responsibility sentence already reflects the author-approved wording.

## Research methods disclosure

Use in the methods discussion of the reference, implementations and evaluation. Retain the more specific procedural facts in the methods and reproduction package.

> OpenAI ChatGPT and Codex assisted with source recovery, software implementation, reference construction, experiment orchestration and analysis. Separate AI sessions implemented and checked the reference against the written policy. The reference implementation and monitor generated the scored outputs by deterministic execution of the saved code. The tool runtime did not expose the model build, temperature or seed for the AI-assisted sessions.

The manuscript preparation and research methods disclosures serve the publisher’s two reporting requirements. The Paper 7 work record identifies the actual tools. The author’s prior LeapSpace wording authorizes the responsibility sentence and supplies a precedent for phrasing.

## Data and code availability

Use after assembling the reproduction ZIP and supplying it with the manuscript.

> The accompanying offline reproduction supplement contains the executable policy, frozen constructed traces and reference sequences, saved monitor outputs, and scripts and instructions to regenerate the reported results. The supplement starts at the observation interface and records the provenance of the source rules. From the extracted `Paper7_Reproduction` directory, run `python -B run_all.py ../paper7-run`. The command verifies the package, replays the study, independently rescores the outputs, and runs the taxonomy and concurrent-condition checks.

## Author statements for submission

| Field | Information needed |
|---|---|
| Competing interests | Declare any relevant financial or personal interests or confirm that there are none. Generate or review the publisher’s editable declaration file based on that answer. |
| Funding | Identify each source, grant number and sponsor’s role, or confirm that the research received no specific funding. |
| Submission declaration | Confirm final author approval, originality and current exclusivity, and disclose any related prior dissemination when the submission form asks. |
| CRediT | Confirm the roles actually performed by Meshaal Obaid Mouawad before entering the contribution statement. |

The recovered author information is Meshaal Obaid Mouawad, Department of Electrical and Computer Engineering, Mississippi State University, Box 9571, Mississippi State, MS 39762, USA, mmouawad@ece.msstate.edu, ORCID 0000-0002-1152-8324. The study uses constructed traces and recruited no human participants. A publisher declaration form can use those facts if it asks about human-participant research.
