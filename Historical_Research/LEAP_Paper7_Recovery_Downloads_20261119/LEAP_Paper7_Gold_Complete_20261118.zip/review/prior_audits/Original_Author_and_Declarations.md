# Paper 7 author and declaration register

Sole author: **Meshaal Obaid Mouawad** (explicit session instruction).
Recovered affiliation: Department of Electrical and Computer Engineering, Mississippi State University, Box 9571, Mississippi State, MS 39762, USA.
Recovered correspondence: mmouawad@ece.msstate.edu.
Recovered ORCID: 0000-0002-1152-8324.
Source: supplied JSS submission LaTeX lines 69–96. The previous document included another author; Paper 7 follows the explicit sole-author instruction and does not import that authorship list.

## Supported data statement
The private preparation package contains the executable specification, controlled simulated traces, reference outputs, source snapshots, raw monitor outputs, and analysis scripts. No external repository deposit or DOI has been created. Original sources retain their recorded provenance. The experiment used no recruited human participants or personal event records.

## AI work record
ChatGPT/Codex performed source recovery, code generation, experiment execution orchestration, analysis, manuscript drafting and editorial preparation. Separate AI agents reviewed novelty/overlap, developed and checked the oracle, and performed final scientific/editorial review. No AI agent is a human adjudicator or author. The tool runtime did not expose an exact underlying model build, temperature, or seed; these fields are recorded as unavailable, not invented. No runtime language model generated benchmark judgments or monitor decisions. All experimental decision outputs came from saved deterministic Python implementations. Separate agents inherited the same parent model; no model substitution was requested.

Prompt provenance: the full research task is represented in README/task record; the exact scientific contract is in protocol/SEMANTICS.md. AI oracle agent received that contract and was explicitly prohibited from reading monitor.py before authoring the reference. Novelty reviewer received research topic/source context and then the information-necessity proposition; final reviewer received full frozen inputs, source and manuscript. Agent reports identify roles and independence limits.

## Personal attestations not supplied
Funding/grant identifiers, competing interests, author review-and-responsibility attestation, submission exclusivity, and any final CRediT role declaration remain unconfirmed. Historical JSS files explicitly marked several of these pending. This record does not substitute a statement of no funding or no interests. A complete journal AI declaration requiring author review/responsibility cannot be finalized by the assistant. A proposed disclosure can use the factual AI-work record above once the author completes the required attestation.
