# Paper 7 - Gold revision change log and issue closure

18 November 2026. The lead editor alone integrated the manuscript. The selected
20-page prompt-suite manuscript is the frozen baseline. This revision is 21 pages.
The change set follows demonstrated source, reader and production findings.

## Substantive changes

| Location | Original issue | Action in the final manuscript | Primary evidence basis | Scientific impact |
|---|---|---|---|---|
| Related work, Section 2.2 | The closest preprocessing predecessor was absent. | Added Antignac, Sands and Schneider (2017), its original citation, and the relationship between a fixed output function and the decision/reason interfaces. | Original proceedings manuscript, Definition 3, Section 4 and Section 5; novelty ledger L3. | Attributes output-preserving preprocessing and identifies the actual contract-specific analysis. |
| Related work, Section 2.4; contract motivation | Implemented revision-sensitive suppression was missing from the operational comparison. | Added pinned skill-audit source and test evidence; linked its capability to the contract motivation. NVIDIA SkillSpector is retained as independent corroborating discovery evidence. | Original suppression implementation and tests at commit e2e9ad679b8a0459bbb4bfad39621435aa354002; novelty ledger L8-L9. | Credits existing scoped-exception handling and strengthens the relevance of the chosen applicability question. |
| Table 2 | Three rows combined studies with different mechanisms and outputs. | Separated RTLola/Vamos, CauMon/WhyMon, and Audit-as-Code/Compliance-as-Code. Added Antignac and skill-audit rows. The 15-row table continues across two pages with repeated headings. | Exact claim-level source checks in the novelty ledger; final rendering. | Readers can distinguish each prior capability and the present output object. |
| Section 3.2 | “Opposite findings” did not explicitly name both timer resets. | States: “A valid negative finding resets qualification, and a valid positive finding resets clearing.” | Frozen monitor.py lines 49/54; specification step 4; retrospective reference contiguous-run reconstruction. | Clarifies existing semantics; no transition or experiment changed. |
| Section 5.2 | Prompts, assigned agent roles/settings and repeated session narration leaked into the scientific prose. | Removed the process heading and diary details; retained tools, research purposes, reference construction and deterministic computation. | Gold protocol Section 10; fresh-reader finding R1; current publisher Methods-disclosure policy. | Preserves relevant provenance in a readable research method. |
| Sections 5.4 and 9 | Internal “Paper 7” prose labels assumed project context. | Replaced them with “review-policy context” or “study implementations.” Actual archive filenames remain exact. | Fresh-reader finding R2. | Makes the article standalone without changing the externally mapped test. |
| Methods; Figure 1-2 captions; AI declaration | Figure-code assistance and renderer provenance were absent from the manuscript disclosure. | Added factual tool/purpose statements, original Matplotlib 3.10.8 metadata, the current Inkscape 1.4 export workflow and raw-output figure verification. | SVG metadata, existing AI activity logs, new figure-data verification and current Elsevier policy. | Makes the figure workflow inspectable. Figure values, geometry, SVGs and approved figure PDFs remain unchanged. |
| Figure reproduction companion | The original Matplotlib generator program was not retained. | Added an executable script that recomputes plotted counts from frozen outputs, checks SVG labels/coordinates and exports the authoritative editable SVGs. | New executed Figure_Data_and_Render_Verification.json and Figure3_Data.csv. | Supplies a concrete reproducible path for the delivered artwork and its data. |
| External editorial benchmark | detectEr was treated too broadly as a research-article benchmark; Stemmer's example enumeration was incomplete. | Marked detectEr as an Original Software Publication used for explanation only. Included Stemmer's third, sensor-aware in-vehicle example. | Full published PDFs; venue report and access ledger. | Corrects the journal-bar assessment. No research claim or manuscript result changed. |

## Protected record

Four propositions, four proofs, two displayed equations and the abstract remain
byte-identical. The source-rule, intervention-taxonomy and two numerical table
bodies remain byte-identical. The qualitative literature table changes are the
justified exception identified above. The author, affiliation, title and contact
fields are unchanged. All three SVGs and all three manuscript figure PDFs are
unchanged. The approved responsibility sentence remains verbatim.

The reproduction archive retains 188 entries and SHA-256
`b55949d177b3355bda1f49442015141ac382e84345b4cc283a7fc4a811a9db48`.
Its study data and saved outputs were not edited. The unsupported historical
1.924-second timing remains absent. Validation is recorded in
`validation/Preservation_and_Reference_Verification.json` and the independent
methods report.

## Original strict-review register

These findings are from the supplied strict review. Prior completed corrections
were rechecked against the current source and primary records. A closed finding
does not require a new experiment solely because this is a new editing session.

| Original ID | Status | Closure evidence in the current revision |
|---|---|---|
| P7-C1 - closest-work novelty challenge | CLOSED | Henzinger and Jevitha attribution retained; original Antignac preprocessing comparison and implemented scoped-suppression evidence added. The independent G2 report locates the contribution in the causal comparison interface and reason collision, supported by Propositions 3-4. |
| P7-M1 - significance of the constructed applicability contract | CLOSED | The source-review example, release-scoped evidence, notification suppression and revision-sensitive finding exceptions establish the contract's design question. The exact display/interval discrepancy and comparison proofs establish the reported consequence. |
| P7-M2 - 55 intervention designs | CLOSED | Eleven operations at five positions produce 55 designs per family, 275 groups and 825 representations. The new independent audit reconstructed all 825 normalized interventions and reconciled 9,900 events. |
| P7-M3 - simultaneous reason conditions | CLOSED | Ordered reset and validity semantics, explicit reason equation and boundary examples are retained. The saved concurrent records independently recount to 24 cases, four implementations, 96/96 final-output matches and 75 events per implementation. |
| P7-M4 - research archive and provenance | CLOSED | The locked archive, actual replay entry point, raw outputs, saved execution logs, source provenance and licenses are delivered. This pass independently rescored the saved evidence and checked archive identity. Earlier actual replay logs remain in the archive/history. |
| P7-M5 - gap-discovery audit | CLOSED | Twelve new recorded queries, citation chasing, 17 ten-field source entries, two pinned operational alternatives, a closest-work matrix and a contribution-evidence matrix are delivered. Access levels and authors' own limitations are explicit. |
| P7-M6 - held-out evaluation wording | CLOSED | The source says held-out rule families sharing 329 temporal templates. The method audit verified the family partition and all 4,935 trace projections. |
| P7-M7 - table placement interrupting a sentence | CLOSED, final rendering verified separately | Numerical tables remain after complete callouts; Table 2 uses a continuing table with repeated headers. Production review identifies the actual final page checks. |
| Recovery-history editorial finding | CLOSED | The manuscript gives the source predicates and interfaces needed to understand the study. Detailed recovery records remain in the evidence package. |
| Approved AI declaration editorial finding | CLOSED for approved wording | The final sentence is exactly “The author takes responsibility for the content of the article.” Tool purposes are factual. Author-only and historical-version checks are listed separately in Venue_and_Author_Checks.md. |

## New Gold findings

| ID | Finding | Resolution |
|---|---|---|
| GN-1 | Missing original output-preserving preprocessing comparison | Antignac paragraph, citation and Table 2 row integrated; novelty agent inspected final source. |
| GN-2 | Missing implemented revision-sensitive suppression comparison | Pinned skill-audit paragraph/citation/row integrated; SkillSpector checked and retained in discovery records. |
| GN-3 | Combined incompatible comparison rows | Six individually attributed rows replace the three combined rows. |
| GM-1 | Qualification/clearing reset sentence ambiguous | Explicit symmetric sentence checked against original source and reference. |
| GR-1 | Research prose contained process diary | Removed; final reader G11 signoff records closure. |
| GR-2 | Internal paper-number labels | Replaced with standalone study terminology. |
| GP-1 | Figure provenance and reproducibility description incomplete | Actual editable sources, independent raw-count verification, current export script and factual disclosure supplied. Historical model-version absence is recorded as an administrative fact. |
| GV-1 | detectEr genre misclassified for benchmark purposes | Corrected in the new venue benchmark; it remains a useful explanatory comparator. |
| GV-2 | Stemmer example enumeration incomplete | Third in-vehicle example added to the benchmark record. |

## Change evidence

`Paper7.tex.diff` and `Paper7_References.bib.diff` show the complete source changes
against the frozen baseline. No whole-paper rewrite was performed in this pass.
The bibliography increases from 26 to 28 cited entries. The added comparison rows
and provenance text produce a 21-page final PDF from the 20-page baseline.

## Remaining boundaries

The live journal guide and author-only declarations are separate administrative
checks. Original AI model builds cannot be reconstructed from records that stored
them as unavailable. These facts are enumerated in `Venue_and_Author_Checks.md`.
The scientific manuscript retains its dedicated end Limitations section.
