# Paper 7 — Gold Niche identity and evidence brief

18 November 2026. Task: execute the complete supplied Chief Editor Protocol,
independently test the scientific contribution, implement justified corrections,
and deliver the verified manuscript and evidence-linked G1–G12 decisions.

## Identity and authority

- Title: *Version Comparisons Preserve Governance Alert Decisions Across Evidence and Policy Revisions*.
- Author: Meshaal Obaid Mouawad; Department of Electrical and Computer Engineering,
  Mississippi State University; mmouawad@ece.msstate.edu. The sole-author record
  and approved AI responsibility sentence are protected.
- Discipline/genre: software engineering and runtime verification; completed
  formal contract/representation analysis with a deterministic constructed-trace
  evaluation and separately encoded implementations.
- Authoritative baseline: the 20-page prompt-suite revision in
  `../manuscript_suite_20261118/manuscript/`. PDF SHA-256
  `73c843da88d0b14d71e6300f625800295fb910d44c9387fb8fe2613483fe3720`;
  source `78297924bc2607ef52d01bdfdfb3b244589389c0271f5ca4ea9d6d9208f281b8`;
  bibliography `9f29dfb032e9cca4a64e54d4047d1579f520017538cebba2abd6676e3c8486bc`.
- Submission status: prepared manuscript; no Paper 7 submission is recorded.
- Primary journal: *Science of Computer Programming*, Research Papers Track.
  Reader: a software-engineering/runtime-verification researcher who understands
  state machines but has no prior knowledge of LEAP. Current scope, article type
  and a closest alternative are assigned to the venue reviewer. The manuscript
  uses Elsevier elsarticle and numbered author-name references (unsrtnat).
- Earlier journal checks: official author-guide routes returned HTTP 403. A dated
  26 April 2026 guide supports a 250-word abstract and 1–7 keywords; accessible
  current publisher policies were separately checked. The baseline abstract is
  238 words with six keywords. Live guide fields remain explicitly unverified.

Evidence authority is: frozen primary data/source code and execution records;
the selected manuscript; original publications and publisher records; accepted
editorial decisions; official venue requirements; secondary commentary. Resolve
any contradiction against the relevant primary record, not a previous PASS label.

## Cold-start scientific map

**Problem.** A finding can support an active review episode at the current
revision while a deferral names another revision. Accepting that deferral can
hide the warning without changing the stored episode interval.

**Existing ability.** Abstract monitors already formalize common outputs for
indistinguishable observation histories. Property-preserving execution-model
abstractions already retain distinctions needed by a chosen property. Stream
monitors implement temporal logic; release-linked evidence and temporary
notification silences already exist.

**Question.** For the stated evidence-and-policy applicability contract, which
version comparisons preserve the displayed decision and which also preserve the
specified reason? Which errors are missed by scoring only active intervals?

**Response.** The paper defines resets, observation validity, qualification,
clearing, escalation, scoped suppression and reason precedence. It analyzes
field-deleted inputs and constructs three joint and six separate Boolean
comparison interfaces, retaining packet presence, values, times and expiry.

**Evidence.** Four propositions/proofs and paired counterexamples establish the
specified representation properties. Frozen replay and independent scoring
measure complete decisions, active intervals, severity and reasons. SQLite and
PyContract encodings and pinned external fixtures provide further execution
checks. The Gold Niche contribution gate must assess the exact advance against
the closest prior capabilities; passing internal tests does not settle that gate.

**Candidate contribution.** An explicit, verified instance of output-dependent
version applicability: three joint comparisons suffice for state/activity/severity;
six separate comparisons also suffice for the prescribed reason. A constructed
collision shows that the three-comparison interface loses some reason distinctions.
The obsolete-deferral ablation demonstrates an endpoint failure invisible to
active-interval agreement. Evaluate the scientific significance of this precise
claim without inventing a minimality claim or an unmeasured operational benefit.

## Questions and fixed evidence

- Q1: Which version distinctions preserve exact decision sequences and reasons?
  Evidence: Propositions 1–4, 30 witness pairs, complete three-/six-comparison replay.
- Q2: How do omitted observation-version, deferral-version or stale-age checks
  affect the warning and episode? Evidence: six implementations on 987 held-out
  base traces, scored at trace, event and interval endpoints.
- Q3: Do metadata edits and equivalent time-unit changes alter outputs?
  Evidence: paired transformations for 1,645 family-design groups.

Protected scored record: 4,935 traces; 26,430 events; five rule families sharing
329 temporal templates; 987 held-out base traces and 5,286 base events.
Without suppression binding: 987/987 active intervals, 957/987 complete trace
decisions, 48 event-tuple errors across 30 traces. Three joint comparisons reproduce
all decisions; the recorded decoder changes 585 reasons (510 policy mismatches,
75 policy changes). Six separate comparisons reproduce decisions and reasons.
All 55 intervention designs per family are 11 operations at five positions:
275 groups, 825 representations, 9,900 events. Concurrent checks: 24 cases in
four implementations, 96/96 agreements. Twenty-nine post-evaluation corrected-
reference regressions comprise 21 valid and eight malformed cases; the original
protocol's 29 hand-derived expectations have separate chronology.

The running case is `audit/suppression_old_context/2/base`: current c1,p1;
positive observations start at 1 s; a deferral at 2 s names c0,p1 and expires at
4 s; qualification occurs at 3 s. Full monitor ACTIVE, ablation SUPPRESSED at
3 s; both ACTIVE at 4 s. Do not invent a prior current-context change from c0.

## Protected materials and prior closure

Baseline copies are in this revision's `baseline/`. The source and figure working
copies are separate. Preserve all four propositions/proofs, both displayed
equations, table data, study inputs and outputs, and the locked reproduction ZIP.
Its 188 entries and compressed bytes have SHA-256
`b55949d177b3355bda1f49442015141ac382e84345b4cc283a7fc4a811a9db48`.

The prior prompt-suite phase completed 74 editorial checks and compiled the
source in isolation. Its five table data blocks and proofs remained exact;
Table 1 lost one obsolete caption sentence; Table 3 and all figures were anchored
after complete callouts. All 20 final pages passed visual inspection. The final
figures are on pp. 6, 9 and 15. No original experiment was repeated in that phase.

Closed issues include closest-work attribution, the 55-design taxonomy, reason
precedence, source/archive provenance, the held-out-family description, figure
guards/labels, and layout. Do not reopen them without a new evidenced defect.
The inherited 1.924-second timing was removed because its matching raw log was
unavailable. Preserve that removal. The manuscript does not claim comparative
runtime performance, industrial benefit or superiority over monitor engines.

The author-approved declaration ends: “The author takes responsibility for the
content of the article.” Existing author funding, conflict and CRediT facts should
be recovered if present; absent facts must remain unfilled, not guessed.

## Work plan and handoff contract

The lead editor alone integrates manuscript changes. Specialist reviewers read
the complete Gold protocol and the selected paper, inspect primary evidence in
their scope, and return: finding; evidence/location; interpretation; severity;
required action; access/confidence boundary. Classify gates PASS/FAIL/NOT VERIFIED.

Run the venue, novelty and methods passes in parallel. Follow with an unfamiliar-
reader pass and figures/LaTeX/archive pass after integration. New experiments are
appropriate only to resolve a demonstrated scientific gap; retain any distinct
extension separately and preserve the frozen evaluation. Reuse completed primary
checks when the relevant files are unchanged, identifying reused versus new work.

Outputs: actual final manuscript/source/PDF; Paper Identity Brief; contribution–
evidence matrix; closest-source ledger including authors' limitations/future work;
journal-fit and alternative decision; prioritized issue/closure register;
substantive diff/change log; preservation and production evidence; G1–G12 matrix;
one of the protocol's exact completion verdicts; clean journal files and complete
evidence package. Scientific correctness determines the verdict. A missing guide
or author-only declaration is recorded separately from a scientific failure.
