# Paper 7 - remaining venue and author checks

18 November 2026. Scientific target: **Science of Computer Programming,
Research Papers Track - FIT**. The closest alternate by genre is **Formal
Aspects of Computing**. Current primary scope and the published-paper comparison
are in the venue reports. No Paper 7 submission or external publication was made.

## Recorded non-scientific checks

| ID | Status | Exact outstanding fact | Evidence already available | Action at submission |
|---|---|---|---|---|
| A1 | NOT VERIFIED | Current SCP journal-specific abstract/keyword/length/highlights/style/anonymization rules and required submission fields. | Four official guide routes failed; current official scope and publisher-wide LaTeX/AI policies were accessible. Final manuscript has 238 abstract words, six keywords, 21 pages and 28 cited references. Historical guide values are identified as dated evidence. | Check the live Guide for Authors and submission form. Apply any required title-page/anonymized-file treatment to this verified version. |
| A2 | NOT VERIFIED, author-only | Final personal review of the revised manuscript, funding and grant facts, competing interests, final contribution declarations and submission exclusivity. | Sole author/contact/affiliation and the approved responsibility sentence are retained. Earlier author-declaration records explicitly leave these facts unconfirmed. | Complete the actual required declarations from the author's facts. The package does not invent “no funding,” “no interests” or a final-review attestation. |
| A3 | NOT RECOVERED, provenance fact | Exact historical AI model build/version for original research/figure assistance. | Original and prompt-suite logs record unavailable exact builds; a later revision names assigned model families but does not identify the original figure model. Matplotlib 3.10.8 is verified renderer metadata, not an AI model identifier. | Preserve this accurate record and disclose available tool/version information in the form requested by the venue. Recover an exact identifier only if an original record exists. |

The current publisher policy requests disclosure of AI research/code assistance,
figure creation support and reproducible data visualization. The manuscript now
states actual tools and purposes in Methods, explains the figure verification
pipeline, adds factual explanatory-figure caption provenance and extends the
general declaration. Its approved responsibility sentence remains unchanged.
Application of the explanatory-image provision to AI-assisted rendering code is
identified as the editor's provenance-based interpretation in the production
report; the publisher does not separately define a code-rendered-image exception.

## Prepared files

The clean bundle contains the final manuscript PDF, flat LaTeX source ZIP,
locked reproduction supplement, cover letter and highlights. The source includes
the bibliography, generated BBL, class, style, PDF figures and editable SVGs.
The letter describes the actual research contribution and journal scope. It does
not assert unverified exclusivity, conflicts, funding or acceptance status.

The identifiable manuscript is the author's working submission version. It is
not labeled anonymized. Any anonymization required by the live journal rule must
cover the source, metadata and supplements as appropriate.

## Primary sources and retained records

- [Official SCP scope](https://shop.elsevier.com/journals/science-of-computer-programming/0167-6423).
- [Official SCP Guide for Authors](https://www.sciencedirect.com/journal/science-of-computer-programming/publish/guide-for-authors), inaccessible during this review.
- [Elsevier LaTeX instructions](https://www.elsevier.com/researcher/author/policies-and-guidelines/latex-instructions).
- [Elsevier generative AI policy](https://www.elsevier.com/about/policies-and-standards/generative-ai-policies-for-journals), updated June 2026 and inspected on 18 November 2026.
- [FAC's BCS owner scope](https://www.bcs.org/about-us/learned-publishing/formal-aspects-of-computing/).
- Prior `current/submission/Author_and_Declarations.md` and prompt-suite `editorial/Author_Statements_To_Complete.md`.
- New `agents/production/Figure_Provenance_and_Production_Review.md` and figure verification JSON.

## Completion classification

These are the named checks associated with **COMPLETE WITH RECORDED VENUE/ADMIN
CHECK** once the scientific and production gates pass. They do not require an
invented declaration, guessed journal rule or another experiment. No final
submission has been performed.
