# LEAP Paper 7 — final editable source (M1–M6)

This source was reconstructed from the November 18 Gold editable baseline using the November 19 final 22-page PDF as a content reference, then revised for the independent peer review M1–M6. The frozen experiments and original figure PDFs are unchanged.

## Build

The supplied compiled `Paper7.bbl` allows a local build without BibTeX:

```sh
pdflatex -interaction=nonstopmode -halt-on-error Paper7.tex
pdflatex -interaction=nonstopmode -halt-on-error Paper7.tex
```

To regenerate the bibliography from its fully editable `.bib` file, run `bibtex8 -8 Paper7` (or a compatible BibTeX command) after the first LaTeX pass, then run `pdflatex` twice.

The production PDF is supplied separately; review and verification materials are not part of the manuscript source.
