# Paper 7 — reader-first narrative revision (19 November 2026)

`Paper7.tex` is the matching editable source for `LEAP_Paper7_Reader_First_Revised_20261119.pdf`.

## What changed

The abstract, introduction, background, contract explanation, motivation for the formal propositions, methods framing, results interpretation, discussion, and conclusion were substantively revised to introduce the software context and its inputs before referring to internal LEAP terminology or mathematical abstractions. The preceding M1–M6 version is preserved separately.

All five propositions and proofs, equations, scientific table content, and three figure assets are unchanged. No study data were modified.

## Build

The frozen bibliography output (`Paper7.bbl`) is supplied for an offline build that does not require BibTeX:

```sh
sh build.sh
```

This script runs `pdflatex` twice; run from the directory containing `Paper7.tex`. The `.bib` file is editable if a compatible BibTeX installation is available. The PDF can also be built by the standard `elsarticle` LaTeX workflow.

## Research evidence

The existing frozen reproduction archive is distributed separately in the complete package. Its contents were not altered in this narrative revision.
