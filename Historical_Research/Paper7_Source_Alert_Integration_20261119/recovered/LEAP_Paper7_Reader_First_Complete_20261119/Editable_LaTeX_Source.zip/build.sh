#!/bin/sh
set -eu
pdflatex -interaction=nonstopmode -halt-on-error Paper7.tex
pdflatex -interaction=nonstopmode -halt-on-error Paper7.tex
