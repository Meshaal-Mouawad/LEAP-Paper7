# LEAP Paper 7 — journal decision and research plan
18 November 2026. Select Science of Computer Programming, regular research article. Its 2026 RTLola and CauMon papers and the 2025 Vamos paper place the work in a current runtime-monitoring conversation. Preferred route is MSU-funded OA if the title, author and remaining credits qualify. Elsevier subscription publication with SSRN preprint is the verified fee-free fallback. SABIC T&I coverage is unverified.
 
## Mouawad gap assessment started
RTLola (10.1016/j.scico.2026.103495) addresses stream-monitor construction. CauMon (10.1016/j.scico.2026.103499) addresses causal explanations. Vamos (10.1016/j.scico.2024.103212) handles heterogeneous event streams and missing events. Vamos was assessed from full text. The CauMon comparison remains at abstract level. Cross-journal full-text comparison with Audit-as-code (10.3389/frai.2026.1759211) establishes prior deterministic policy gates and versioned evidence. OPA Decision Logs already preserve decision identifiers and policy bundle revisions. Historical replay and version recording alone cannot carry the contribution.
 
Paper 7 asks which fields are necessary to preserve the ordered reviewer's displayed decisions and latent episode activity under a specified evidence and policy revision contract. Paper 6 compares KPI definitions to implementations. A suppression tied to an obsolete revision is the discriminating example: activity intervals may remain correct while the displayed action is wrong. The frozen evaluation found this discrepancy on 90 held-out traces in the suppression-binding ablation.
 
## Work sequence and owners
1. Recovery and oracle reviewer — GPT-6.2 Sol, high. Preserve source hashes and reconstruct event semantics independently from monitor code. Existing fixture and reference checks stay frozen.
2. Journal and fee researcher — GPT-6.2 Sol, medium. Record exact-title inclusion, credits, author status, publisher preprint rules and any SABIC T&I agreement.
3. Literature and overlap reviewer — GPT-6.2 Sol, high. Compare full methods and benchmarks, chain citations and challenge the six-field result against revision-aware monitoring.
4. Author bibliography researcher — GPT-6.2 Sol, medium. Verify authorship, version and public status. Cite prior work at the claim it supports.
5. Scientific lead — GPT-6.2 Astra, high. Decide whether the published comparisons leave a distinct question. Preserve the original holdout and estimates. Specify any additional experiment separately before accessing its outputs.
6. Implementation and reproducibility — GPT-6.2 Sol, high. Implement an established revision-aware baseline on identical inputs if warranted. Report policy encoding, reference agreement, activity and displayed actions, execution failures and reproducible commands.
7. Independent final scientific/editorial reviewer — GPT-6.2 Astra, high. Verify proof assumptions, references, limits of simulated evidence, declarations, current journal requirements and rendered PDF after revision. Record AI review separately from human adjudication.

## Decision and resume checkpoint
Submission NOT READY. Obtain title-specific OA and author eligibility evidence if electing OA. Confirm applicable journal requirements, permitted redistribution and Paper 7 declarations. Finish full-text frontier challenge and baseline comparison before expanding claims. No new experiment was scored in this journal revision. Retain original frozen study and verification records in the parent directory.

Priority cross-journal challenge: Compliance-as-Code for AI-Driven Identity Systems (IEEE Access, DOI 10.1109/ACCESS.2026.3665991) already binds decisions, versioned policy and release-specific evidence and tests stale or missing evidence. Compare its actual output semantics to Paper 7's separately evaluated suppression display and episode activity. The residual novelty judgment is open.
