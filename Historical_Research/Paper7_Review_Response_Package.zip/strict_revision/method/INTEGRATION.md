# Strict revision — M2 and M3 integration

## M2: complete experimental taxonomy

Replace the complete paragraph beginning "For each family, 329 base designs..." (including its transformation sentence) with `taxonomy.tex`. It uses existing booktabs/tabularx packages and adds label `tab:intervention-taxonomy`. Do not retain the old abbreviated intervention list.

The frozen generator has eleven named operations, each applied at five zero-based indices: 2, 3, 5, 7, 9. These indices equal seconds in the length-twelve base control. Missing/conflict/stale/future operations affect one event. Current-context/current-policy revision with old/fresh evidence affects the suffix. Suppression operations attach packets over the suffix, including after expiry. "Single intervention" identifies one operation, not necessarily one modified event.

Verified category totals:

| Category | Designs per family | Groups, five families | Traces, three variants | Events |
|---|---:|---:|---:|---:|
| Four-symbol sequences | 256 | 1,280 | 3,840 | 15,360 |
| Long controls | 3 | 15 | 45 | 540 |
| Eleven intervention types × five positions | 55 | 275 | 825 | 9,900 |
| Five boundaries × three offsets | 15 | 75 | 225 | 630 |
| Total | 329 | 1,645 | 4,935 | 26,430 |

`audit_taxonomy.py` checks every original freeze digest, independently reconstructs all eleven mutation operations and verifies all 825 frozen intervention representations after normalizing time units. It preserves counts by family/split/variant/category/mechanism and all 55 type-position keys. 825/825 intervention comparisons passed. No benchmark files changed.

## M3: expected reasons for concurrent conditions

Insert `precedence.tex` immediately after the paragraph explaining output reasons in the transitions section. It defines the full diagnostic-priority equation and explains its relation to the state update order. If the policy/event section already lists the validity-order chain, keep that short definition; the new paragraph supplies the previously missing joint-condition behavior.

State reset occurs before quality checks. Diagnostic reason prioritizes quality over reset, policy-reset over context-reset, and valid reset over suppression. Within quality: missing, observation-context mismatch, observation-policy mismatch, future timestamp, stale timestamp, then conflict. Timer updates precede escalation/suppression display, so clearing at its boundary ends an episode even at its escalation boundary. UNKNOWN dominates suppression display. Every event has one current policy identifier; the precedence is for simultaneous contract conditions.

Twenty-four new hand-calculated traces were frozen before running targeted tests. All four complete-contract implementations were called directly: Bound, oracle v2, SQLite and authentic PyContract. The tests passed all 96 expected-final-output checks (24 × four) and showed full-sequence equality on all 24 traces, 75 events per implementation. These are explicitly post-study verification; they do not enlarge or alter the original 4,935-trace benchmark.

## Commands and evidence

```bash
PYTHONDONTWRITEBYTECODE=1 python research/paper7_risk_alarm/strict_revision/method/audit_taxonomy.py
PYTHONDONTWRITEBYTECODE=1 python research/paper7_risk_alarm/strict_revision/method/run_targeted_checks.py
```

- `taxonomy_summary.json`: original freeze verification and exact category totals.
- `taxonomy_full_counts.csv`: all family/split/variant/category/mechanism counts.
- `intervention_grid_55.json`: full operation-position grid.
- `intervention_record_checks.json`: 825 individual reconciliation checks.
- `targeted_cases.json`: trace inputs and hand-calculated expected final outputs.
- `TARGETED_FREEZE.json`: prescoring targeted-case/source/specification hashes.
- `targeted_results.json`: complete outputs from all four implementations.
- `targeted_summary.json`: 24/24 cases, 96/96 expected outputs, 75 events/method.
- `targeted_expected_outputs.csv`: readable expected final-state/reason table.
- Execution logs and `CHECKSUMS.sha256` accompany these records.

The camera-ready fragments report only checked counts and deterministic policy behavior. Rendering remains part of the parent manuscript integration.
