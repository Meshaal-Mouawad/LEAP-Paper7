# Paper 7 strict revision requirements and declaration authority

## Review record

Use the review text in the current user message as the available review record. Its final sentence describes the external research package as unsupplied to that reviewer. “Download the full review” appears as plain text. The complete, separate strict-review and issue-closure register has no recoverable attachment identifier or link in that text. Searches for its exact likely filename, alternate title forms, issue-closure phrases, and recent Paper 7 uploads found the earlier Gold companion report and strict reviews for Papers 6 and 8. The Paper 7 Gold companion report is an independent earlier record. It cannot supply the later review's exact issue IDs, wording or closure conditions. Record each visible strict finding verbatim from the current user message and mark the unavailable full-register cross-check as open. The current revision's package can establish reproducibility by its own checks even though it was not supplied to the earlier reviewer.

The author-supplied Paper 7 task defines the work-specific obligations. It requires a separate sequence-level question from Paper 6, explicit alarm semantics, preserved source versions and frozen evidence, matched comparisons, reporting by evaluation unit, accurate AI provenance, sole authorship by Meshaal Obaid Mouawad, and recovery of authoritative identity and declaration information. It expressly prohibits invented personal attestations. The prior task is available in [Pasted text(8).txt](https://chatgpt.com/library?file_id=libfile_fde3_f-5d2ea77f4ed88191bccc5f17754cc2a6_6246015f02148191b6fb1aaa7040b316&account_id=personal), Paper 7 items 3–6, 12–23 and 24–28.

## Declaration recommendation

**Safe for the current manuscript, before the references.**

> **Declaration of generative AI and AI-assisted technologies in the manuscript preparation process**
>
> During the preparation of this manuscript, ChatGPT and Codex assisted with drafting and editorial review.

Retain this factual research-methods disclosure alongside the reference and experiment provenance.

> ChatGPT and Codex assisted with source recovery, implementation, reference construction, experiment orchestration, and analysis. Separate AI sessions produced and reviewed the executable reference. Deterministic implementations produced the scored outputs.

The approved general form naming Elsevier LeapSpace and other tools is wording precedent. Paper 7's work record identifies ChatGPT and Codex and provides no evidence of Elsevier LeapSpace use on this manuscript. The earlier form also uses author responsibility language. A manuscript-specific review, editing, and responsibility attestation has yet to be confirmed in Paper 7's work record. If the author confirms those actions for the final Paper 7, append the following sentence to the manuscript-preparation disclosure.

> After using these tools, the author reviewed and edited the manuscript as needed and takes full responsibility for its content.

The publisher's general policy calls for tool and purpose disclosure, author oversight, and responsibility before journal submission. The factual disclosure for the present draft is supported now. Funding, competing interests, contributor roles, exclusivity, and author responsibility remain submission checks pending work-specific confirmation. No general wording or prior manuscript declaration closes those checks. [Elsevier general journal policy](https://www.elsevier.com/about/policies-and-standards/generative-ai-policies-for-journals)

## Evidence checked

- [Paper 7 author and declaration register](../../submission/Author_and_Declarations.md) identifies tools and roles, confirms the recovered correspondence and ORCID, and lists all outstanding personal attestations.
- [Post-gap manuscript](../../gap_execution/Paper7.tex) places a factual ChatGPT/Codex statement before the references.
- [Prior Gold editorial review](../../gap_execution/Editorial.md) records the work-specific personal declarations and current journal verification as submission gates. The current user's strict review governs the present issue closures.
