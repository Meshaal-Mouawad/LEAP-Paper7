# Paper 7 — research gap discovery and strict-review revision

The following closest-work challenge updates the contribution verdict in the preserved journal-first assessment. The revised introduction and related work appear in Paper7.pdf.

# Paper 7 discovery update

Verified 18 November 2026. This supplement extends the existing discovery record where two close studies challenge the claimed advance. The question under review is which input comparisons preserve the decision tuple and which also preserve the reason label of a single, specified review lifecycle. The comparison concerns completed primary studies, including their definitions, methods, evaluated outcomes and stated boundaries.

## Search and access

| Route | Verified access and evidence |
|---|---|
| `Henzinger Mazzocchi Saraç 2022 abstract monitors observational equivalence classes full text` | Springer metadata agrees with the ISTA record. The open ISTA copy is the published proceedings version. Read §1, §2.1–2.3, the finite-versus-limit distinctions in §3–4, and §5. [Publisher](https://link.springer.com/chapter/10.1007/978-3-031-17196-3_11) · [Published full text](https://research-explorer.ista.ac.at/download/11775/12317/2022_LNCS_RV_Henzinger.pdf) |
| `Jevitha Jayaraman Sethumadhavan 2024 runtime verification property-preserving abstractions execution state model full text` and `Jevitha 112138 property preserving abstract LTL` | Elsevier and University at Buffalo institutional records establish the peer-reviewed publication. Read the full author manuscript v1 on arXiv and checked its problem, approach and conclusions against the publisher preview. Exact-version publisher full text was not retrieved. Evidence locations below therefore use the public author manuscript. [Publisher](https://doi.org/10.1016/j.jss.2024.112138) · [Full author manuscript](https://arxiv.org/html/2406.12715v1) |
| `Smith 2009 On the Foundations of Quantitative Information Flow posterior vulnerability Bayes guessing` | Found the primary conference paper and checked §2.1 and §5 in the published full text. DBLP confirms the same DOI and pages. [Publisher](https://doi.org/10.1007/978-3-642-00596-1_21) · [Published full text](https://cs.au.dk/~askarov/lbs-course/2017/reading/fossacs09.pdf) |

## Henzinger, Mazzocchi and Saraç

**Source.** Thomas A. Henzinger, Nicolas Mazzocchi and N. Ege Saraç, *Abstract Monitors for Quantitative Specifications*. RV 2022, LNCS 13498, pp. 200–220, Springer, published 23 September 2022. Peer-reviewed conference paper. [DOI](https://doi.org/10.1007/978-3-031-17196-3_11)

**Question and formal task.** What precision can an abstract monitor achieve at a finite time or in the limit, and what resources does it require? Input traces are over a finite observation alphabet. The quantitative specification assigns real numbers to finite prefixes and uses a limit measure on infinite traces. An abstract monitor induces a right-monotonic equivalence relation and maps each class to a real-valued output. Prefix equivalence is preserved under a common continuation. The number of classes seen through a given length measures resource use. §2.1–2.3, printed pp. 204–206.

**Established evidence.** In Proposition 6, two prefixes in the same monitor class have a shared reported value. If the per-prefix error is bounded by \(\delta_{\mathrm{fin}}\), their prescribed values differ by at most \(2\delta_{\mathrm{fin}}\). Zero prompt error gives exact agreement within each class. The paper develops theoretical examples and results about when a resource-optimal limit monitor can save resources or when no such saving is possible. This is a theoretical analysis of monitor partitions and worst-case precision. It is distinct from a corpus-frequency estimate. §2.2, Proposition 6, printed p. 205, and §3–4.

**Authors' stated boundaries.** The abstract cost proxy counts equivalence classes even when concrete machine implementations for the same number of classes require different resources. Construction of concrete monitors, further error notions, and reclaiming resources through time are future directions. §5, printed pp. 215–216.

**Independent inference for C1/M5.** Paper 7 Proposition 1 applies the already-established indistinguishability principle to a fixed event-interface projection and a categorical decision sequence. It makes no contribution to general observational equivalence or abstract-monitor theory. Its input classes are fixed by the reviewed encoding, whereas Henzinger et al. compare right-monotonic monitor relations under error tolerance. The latter establish which numerical specification values a monitor can represent for a chosen resource budget. Paper 7 constructs two explicit event representations for its policy and exhibits a class that is homogeneous for the decision output and heterogeneous for the reason output. That is the concrete refinement supplied by Propositions 3 and 4.

## Jevitha, Jayaraman and Sethumadhavan

**Source.** K. P. Jevitha, Bharat Jayaraman and M. Sethumadhavan, *Runtime verification on abstract finite state models*. Peer-reviewed *Journal of Systems and Software*, vol. 216, article 112138, October 2024 issue. [DOI](https://doi.org/10.1016/j.jss.2024.112138)

**Question and formal task.** How can online checking of data-oriented and control-oriented properties be made efficient when execution-state models obtained from Java runs grow large? The user selects key attributes and abstractions tailored to a specified property. Data models use Boolean or multi-valued abstractions. Control models abstract structures or paths. The authors treat runtime verification over an observed execution, with state and path properties checked within finite traces. Author manuscript §§1 and 3–4.

**Established evidence.** For a state invariant \(G[p]\), the data-oriented checker builds an implication from the predicates describing an abstract state's concrete values to \(p\). Valid implications support a proof that the concrete states satisfy the requirement. Failure of the abstract check can reflect an overly coarse abstraction. The specified path abstraction uses edges representing concrete paths between selected abstract states. In Algorithm 6 it checks for a bypass of a required intermediate state. The study compares linear, distinct and abstract state models on state counts and construction and verification time. For example, the reported OAuth case has 29 distinct states and three abstract states for the selected path property. The authors note that total time depends on construction costs as well as checking costs. Author manuscript §§5.3 and 6.4, Algorithms 4–6 and Tables 2–3.

**Authors' stated boundaries.** Verification pertains to an observed finite run. The paper identifies trade-offs between under-abstraction and over-abstraction, possible re-traversal for an unsuitable abstraction, path properties whose evidence is unavailable until later events, and the need for a different event-generation mechanism to extend the implementation beyond Java. It characterizes its correctness explanation as informal. Author manuscript §§5.3 and 7.

**Independent inference for C1/M5.** The work is a close primary precedent for choosing an abstraction according to the verification objective. It reduces a graph of execution states for evaluation of selected Boolean properties. Paper 7's unit is an ordered input event and its output is an event-by-event tuple, optionally joined by a reason label. The contribution is a causal comparison encoding that preserves those outputs for a given lifecycle and a witness showing ambiguity when two fields are merged. State-model size and verification-time comparisons answer different measurable questions from exact decision/reason agreement under the same trace.

## Smith and the finite-corpus calculation

**Source and result.** Geoffrey Smith, *On the Foundations of Quantitative Information Flow*. FoSSaCS 2009, LNCS 5504, pp. 288–302. The primary paper defines conditional vulnerability as the probability of guessing a value correctly in one try after observing another value. Definition 3 and its calculation in §5, printed pp. 296–297, take the sum over observations of the maximum joint mass. §2.1 also describes the equivalence classes induced by a deterministic observation. [DOI](https://doi.org/10.1007/978-3-642-00596-1_21)

**Exact connection to Proposition 2.** On a uniform draw from corpus occurrences, let \(Y\) be the required complete output sequence and \(Z\) the projected complete trace. The empirical joint mass is \(n(z,y)/N\). Substitution into Smith's Definition 3 gives \(\sum_z\max_y n(z,y)/N\), exactly the normalized Paper 7 count. The maximizing choice is a most frequent required output sequence per complete projected trace. This recovers the bound as a known zero-one-loss rule and explains why a full-trace lookup attains it. A causal monitor sees prefixes as it emits output, so the same value is an upper bound for that stricter interface.

## Revised candidate register and manuscript placement

| Candidate | Result after closest-work challenge |
|---|---|
| Same visible history implies one deterministic monitor output | Established. Henzinger et al. formalize the analogue for quantitative monitors. Proposition 1 uses the principle to test a specified projection. |
| Finite benchmark optimum found by choosing the modal label per visible input | Established. Smith's Definition 3 gives the normalized calculation. Proposition 2 connects the known rule to the corpus and its trace-level decision endpoint. |
| Runtime abstraction can retain information needed by a chosen verification objective | Established. Jevitha et al. give property-tailored data and path abstractions with explicit verification and performance evidence. Leucker et al. supply a separate timed-stream precedent on soundness and precision under partial information. |
| Three joint event comparisons preserve decisions, and keeping context and policy separate also preserves reasons | The verified closest studies supply general principles but leave this event-interface comparison open. Propositions 3 and 4 instantiate the two representations for the specified lifecycle. Their difference is testable by an input collision whose reason labels differ while its decision tuples coincide. The frozen synthetic replays check both outputs separately. |
| Three comparisons are globally minimal or reduce the monitor's concrete memory | Outside the demonstrated result. The paper gives a sufficient encoding with retained non-version inputs and a reason counterexample for one particular coarsening. It does not compare all possible encodings or measure resource savings. |

Add the two primary comparison paragraphs and the output-specific synthesis in related work. Attribute the general reasoning behind Propositions 1 and 2 at their point of use. Present the advance through Propositions 3 and 4 and their evidence, with the named retained inputs and the specified lifecycle. The reviewed evidence supports this scoped advance as a concrete comparison of two output requirements. The theoretical frameworks and experimental objectives of the prior work remain distinct from the Paper 7 endpoints.


---

# Preserved journal-first assessment

# Paper 7 · Research-gap discovery

**Industrial risk-alarm extension of LEAP | Science of Computer Programming | 18 November 2026**

**Selected research question.** When a reviewer receives an alert after the evidence or review policy has changed, which relationships between versions must the monitor distinguish to reproduce the warning, and which must it distinguish to explain the warning? The answer changes the design of the interface between the producer of a finding and its consumer. An interface can preserve everything a reviewer sees about the warning while losing which revision justified it.

**Editorial decision: READY TO DRAFT WITH VERIFIED EVIDENCE**, for this specified software contract. The strongest formal precedent establishes how precise an abstraction can be for timed stream operators. The strongest application precedent binds findings to releases and policy digests. Neither supplies the output-specific answer for a review episode in which evidence and authorization to suppress it can expire independently. This report identifies the overlap explicitly, states what survived it, and supplies the resulting manuscript prose in F.

## A. Target-journal frontier and coverage

The search started with the actual LEAP output: five lexical tests issue source-review findings. The existing dispatcher requests review of an artifact. Qualification over time, persistence, clearing and deferral belong to the extension evaluated here. That distinction makes runtime specification and verification the first literature to examine. It also determines the comparator: a monitor receiving the same events and the same review policy.

The recorded journal search screened ten SCP records in issue years 2026, 2025 and 2024; four were selected as the direct topical comparators. Three complete SCP articles were also assessed for their technical exposition: Vamos, the driving-requirement study, and detectEr. These counts describe overlapping sets. Only Vamos belongs to both. Inspecting a different paper by the RTLola or CauMon authors does not make the exact 2026 article a full-text assessment. The chronological records below retain the search route, identity and depth of access.

The search started with 2026, then checked 2025 and 2024 issue years. Searches paired the journal title and publisher domain with `runtime verification`, `runtime monitoring`, `event streams`, `policy`, `provenance`, `software evolution`, `version`, `compliance`, `governance`, `alerts`, and competing vocabulary such as `partial monitoring`, `causation`, and `CI/CD reliability`. Publisher, DOI, DBLP, and author/institutional records verified publication identity. Method-name and author searches followed explanatory monitoring, stream timing, CauMon's 2024 artifact and 2023 antecedent, and monitor-state adaptation. Outside searches covered release/policy digests, AI governance, alert suppression, authorization decision replay and evidence completeness. This was targeted coverage, with ten target-journal records screened and four compared substantively. Records with no direct bearing on the research question remain listed to make selection visible.

| SCP issue year and published paper | Access and inspected evidence | Result and role in the comparison |
|---|---|---|
| 2026, Baumeister, Finkbeiner, Kohn and Scheerer, *Stream-based monitoring with RTLola* | Publisher preview on automatic monitor generation and trigger outputs plus authors' institutional abstract. [DOI](https://doi.org/10.1016/j.scico.2026.103495) · [Author record](https://rct.cit.tum.de/publications/2026-rtlola-tutorial-journal/) | A stream specification can be statically analyzed for resource requirements and turned into an executable monitor. Boolean triggers carry violations to operators. This supports expressibility and tool comparability, without a claim about a field projection for a particular review policy. |
| 2026, Zhang, An, Arcaini and Hasuo, *CauMon* | Publisher and institutional abstracts on robustness masking and causation. Companion artifact and foundational method located separately. [DOI](https://doi.org/10.1016/j.scico.2026.103499) · [Artifact](https://zenodo.org/records/12518433) · [2023 method](https://doi.org/10.1007/978-3-031-37706-8_4) | Causation semantics can reveal the relevance of newly arriving signal information to a verdict where a single robustness result masks that relevance. This addresses the informativeness of a verdict for a temporal signal property. |
| 2026, Rodríguez, Piña and Castañeda, *A reliable non-intrusive runtime verification framework for linearizability* | Publisher abstract and issue metadata. [DOI](https://doi.org/10.1016/j.scico.2026.103509) | Screened. The verification target is a concurrency correctness condition and the method addresses observation interference. |
| 2026, Waga, Matsuoka and Suwa, *ArithHomFA* | Publisher abstract and issue metadata. [DOI](https://doi.org/10.1016/j.scico.2026.103539) | Screened. Homomorphic encryption permits checking discrete-time signal requirements with confidential input. |
| 2026, Benjamin and Mathew, *Early detection of emerging CI/CD reliability degradation through multi-source triangulation and deep representation learning* | Publisher abstract, data/package description, and issue metadata. [DOI](https://doi.org/10.1016/j.scico.2026.103532) | Screened. Detects reliability degradation using development and workflow evidence. The monitored outcome differs from the ordered review decision contract. |
| 2025, Chalupa, Muehlboeck, Muroya Lei and Henzinger, *Vamos* | Publisher version of the full text via ISTA, especially Sections 3–5 and Figures 12–14. [DOI](https://doi.org/10.1016/j.scico.2024.103212) · [Full text](https://research-explorer.ista.ac.at/download/18169/18831/2024_ScienceCompProg_Chalupa.pdf) | Best-effort middleware marks dropped events while arbitrating heterogeneous sources. A race evaluation used 391 benchmarks, 118 with established ground truth. The Wayland case aligned hardware and client observations approximately because they lacked common identifiers. Hardware/event loss is a different condition from an intact but obsolete observation. |
| 2025, Ferrando and Cardoso, *Towards partial monitoring* | Publisher preview and institutional abstract, with an open-access full-text candidate. [DOI](https://doi.org/10.1016/j.scico.2024.103220) · [Institutional record](https://iris.unimore.it/handle/11380/1361526) | Two forms of partial monitoring address terminal inconclusiveness or irrelevant events. An implemented LTL construction was evaluated on a remote-inspection case and synthetic properties. An observation invalidated by revision exposes a different reason that it cannot support a current decision. |
| 2025, Stemmer et al., *Runtime monitoring of complex scenario-based requirements for autonomous driving functions* | Institutional abstract and opening page of the public publisher PDF. [DOI](https://doi.org/10.1016/j.scico.2025.103301) · [DLR record](https://elib.dlr.de/214014/) | Screened. Defines monitoring over finite, sampled driving observations using Traffic Sequence Charts. |
| 2025, Mahe, Bannour, Gaston and Le Gall, *Efficient interaction-based offline runtime verification of distributed systems with lifeline removal* | Publisher abstract and issue metadata. [DOI](https://doi.org/10.1016/j.scico.2024.103230) | Screened. Checks recorded distributed interactions against specifications offline. |
| 2024, Aceto et al., *A monitoring tool for linear-time μHML* | Publisher abstract and highlights. [DOI](https://doi.org/10.1016/j.scico.2023.103031) | Screened. Implements a runtime-monitorable linear-time μ-calculus fragment in an Erlang/OTP verification tool. |

## B. Research lineage and cross-journal challenge

**From a trigger to a versioned finding.** RTLola explains how to compute a trigger from input streams. Nweke and Yeng bind a runtime decision to its release, environment and policy digest. Li and colleagues attach the model version to individual threshold alerts. Together these results defeat a proposal whose contribution is simply a version-tagged governance alert.

**From a versioned finding to an action.** Alertmanager separates an active condition from permission to notify. Its versioned tests contain an active alert that can be muted by a matching silence. The remaining question is about a particular deferral that survives a revision: can the monitor preserve the active interval and still present the wrong action? Comparing both outputs on the same trace can detect the discrepancy.

**From an action to its explanation.** WhyMon supplies proof-tree explanations, and its checker certifies those explanations. Leucker, Sánchez, Scheffel, Schmitz and Thoma prove precision results for abstract timed-stream operators. Theorem 2 on p. 282 covers individual operators with the stated abstraction assumptions; §4 explains why operator-level precision does not automatically carry through composition. These sources defeat a general claim to invent either explanatory monitoring or reasoning about lost information. Paper 7 fixes a particular lifecycle and identifies an encoding that is exact for its action tuple yet ambiguous for its reason. [Timed-stream paper, pp. 282–285](https://software.imdea.org/~cesar/papers/leucker19runtime.pdf) · [Verified explanation checker](https://isa-afp.org/entries/MFOTL_Checker.html)

Peer-reviewed journal papers carry the evidential comparison. Conference papers establish complementary methods. Official documentation verifies operational capabilities. The preprints listed here serve as additional counterexamples to broad priority claims.

| Source and status | Access and evidence location | Verified result and relevance |
|---|---|---|
| Nweke and Yeng, *Compliance-as-Code for AI-Driven Identity Systems*, IEEE Access, 18 February 2026 | Publisher abstract/full search record and public copy of the version of record. Section III, goals G1–G5 and claims C1–C4. Section IV, evidence contracts. Section V-A, canonical binding. Section VIII, workloads and Table 2. [DOI](https://doi.org/10.1109/ACCESS.2026.3665991) · [Full text copy](https://www.researchgate.net/publication/400811779_Compliance-as-Code_for_AI-Driven_Identity_Systems_Clause-to-Control_Traceability_and_Machine-Readable_Evidence) | Runtime authorization events carry release, environment, control, timestamp, decision, and policy digest. Fixed-window evidence contracts and an evidence graph support missing/stale-evidence findings and release attribution. Two reproducible workloads spanning four releases exercise those properties. Evidence availability and release attribution are established antecedents to the Paper 7 question. |
| Li et al., *An ethics-informed computable audit framework for monitoring misdiagnosis risk in AI-assisted diagnosis*, Scientific Reports, 6 April 2026 | Publisher PDF and HTML excerpts on the sentinel, ledger, audit procedure, simulation and alert outcomes. [DOI](https://doi.org/10.1038/s41598-026-46652-1) · [Full text](https://www.nature.com/articles/s41598-026-46652-1.pdf) | Clinical threshold triggers are written with model version, timestamp, site or subgroup, window, metric, band, and mitigation. Simulation reports alert burden, timing, and persistence. This defeats priority for version-tagging individually emitted governance alerts. |
| Muhammad, Yow and Alsenan, *Audit-as-code*, Frontiers in Artificial Intelligence, 2026 | Publisher full text, Sections 3–4, including the policy file, evidence schema, deterministic gate, Table 6 and Table 13. [DOI](https://doi.org/10.3389/frai.2026.1759211) | A versioned policy governs pass/warn/block decisions from structured evidence. Tests use 1,000 synthetic scenarios and five model benchmarks. This supplies a release-assurance gate and evidence-ablation precedent. |
| Rațiu, Mayr-Dorn, Stock and Egyed, *Automated runtime temporal constraint checking for engineering process compliance*, Journal of Systems and Software, August 2026 issue | Publisher abstract, institutional record and author manuscript metadata. [DOI](https://doi.org/10.1016/j.jss.2026.112868) | Rechecks constraints expressed in OCL with LTL-style operators on changes to interrelated artifacts and incorporates relevant histories incrementally. In an industry-derived use case, the paper reports detected violations and approximately 0.3 ms mean evaluation time for a single constraint operator. That unit differs from alert time-to-action. |
| Barrientos, Winter and Rinderle-Ma, *Impact analysis of regulatory requirement changes on business process compliance*, Information and Software Technology, June 2026 issue | Publisher and institutional abstracts, Method and Results. [DOI](https://doi.org/10.1016/j.infsof.2026.108079) · [Author record](https://portal.fis.tum.de/en/publications/impact-analysis-of-regulatory-requirement-changes-on-business-pro/) | Models requirements in deontic logic, extracts change operations, and explains compliance effects on process models. Three datasets and comparisons with existing approaches support the results reported in the abstract. This defeats a broad gap in requirement-change impact analysis. |
| Calboreanu, *TRACE*, IEEE Access, 14 September 2026 | Publisher abstract for the evaluation and accessible full-text sections for launch admission and its signed manifest. [DOI](https://doi.org/10.1109/ACCESS.2026.3733578) | Binds the framework, authorized tools, and model identity to a signed policy/runtime manifest and uses telemetry and tripwires for agent oversight. Reports 200 deterministic evidence package reconstructions. This supplies an agent-specific precedent for binding and reconstructing actionable runtime evidence. |
| Carwehl, Vogel, Rodrigues and Grunske, SEAMS 2023 | Conference record and public author version, Sections III–IV. [DOI](https://doi.org/10.1109/SEAMS59076.2023.00024) · [Author text](https://arxiv.org/abs/2303.16530) | Property adaptation patterns migrate timed-automaton state during self-adaptation. Evaluates a body-sensor network and the Timescales benchmark. This establishes a monitor-state update option under changing requirements. |
| Hublet, Nevatia and Schneider, 2026 preprint | Author full text, Sections 1 and 3–5. [arXiv](https://arxiv.org/abs/2609.10114) | Formalizes when a monitor can change policy using only its stored state and still reproduce future verdicts under the incoming policy. This is a strong conceptual challenge to general novelty in monitor information sufficiency under policy change. Its target is monitor-state transformation. |
| Open Policy Agent, Logius, and Prometheus operational sources | OPA Decision Logs field table, Logius Authorization Decision Log 1.0.0, §§1.1 and 3.5.1, and Prometheus architecture and silences documentation. [OPA](https://www.openpolicyagent.org/docs/management-decision-logs) · [Logius](https://logius-standaarden.github.io/publicatie/ftv/adl/1.0.0/) · [Alertmanager](https://prometheus.io/docs/alerting/latest/alertmanager/) | OPA records the actual policy-bundle revision and decision ID. Logius describes recording reconstructable historical decision context. Alertmanager retains active alerts while temporarily muting notifications based on matchers. A version or suppression feature on its own is established practice. |
| TeSSLa, asynchronous streams, and proof-tree monitoring | Previously inspected source sections on delay semantics, system versus monitor time, and proof explanation/checking. [TeSSLa](https://doi.org/10.1007/978-3-030-03044-5_10) · [Asynchronous streams](https://doi.org/10.1007/s11219-019-09493-y) · [Proof-tree monitoring](https://doi.org/10.1007/978-3-031-57246-3_16) | Establishes methods for timed stream operators, non-synchronized arrival, and certified explanations. These supply relevant implementation or evaluation precedents. |
| Sampath, Sengupta, Lafortune, Sinnamohideen and Teneketzis, *Diagnosability of discrete-event systems*, IEEE Transactions on Automatic Control, September 1995 | Publisher abstract and bibliographic record. [DOI](https://doi.org/10.1109/9.412626) | Establishes necessary and sufficient conditions for failure diagnosis from online observations of discrete-event systems. It supplies historical context for deciding what observable distinctions are necessary. Paper 7 uses an elementary projection argument to characterize a particular review interface. |

The lineage runs from executable triggers and partial observation in SCP to release-attributed runtime findings in IEEE Access and version-tagged threshold triggers in Scientific Reports. Prometheus establishes a second distinction between alert activity and notification handling. The residual comparison examines the information needed to preserve *both* outcomes when the current, observed, or suppression-authorizing version can differ.

### Search routes and access

A publisher-index recheck recovered the exact 2026 articles using `site:sciencedirect.com/journal/science-of-computer-programming OR site:sciencedirect.com/science/article "Science of Computer Programming" "monitoring" "2026" RTLola CauMon runtime`. The query `site:sciencedirect.com "Science of Computer Programming" 2025 "monitoring" Vamos partial monitoring changes` returned the Vamos and Ferrando–Cardoso records. The original journal-first and citation-chain routes are documented in A and in the cards below. This focused follow-up tested the strongest methodological objection using the following literal queries on 18 November 2026:

- `runtime verification monitor verdict explanations proof trees metric first order temporal logic Lima explanation WhyMon same verdict` led to the institutional record for Lima et al. and the Archive of Formal Proofs checker. The latter's scope is verified proof checking; this study checks a policy reason code.
- `runtime verification minimal observation alphabet monitor output equivalence state outputs coarsening specification event distinguishability alert suppression reason` and `alarm shelving version specific suppression policy alert episode evidence provenance runtime verification historical decision reason labels` were also submitted. No distinct supporting record is attributed to these two queries.
- `runtime verification monitoring with partial observation indistinguishable traces observational determinacy monitors event abstraction knowledge Bauer Leucker` led to the Taleb–Hallé–Khoury survey, Bollig's lecture notes, and the primary Leucker et al. article. The primary full text, especially Theorem 2 and §4, supplied the comparison with compositional abstraction. The survey and lecture notes were discovery routes. [Survey](https://doi.org/10.1016/j.cosrev.2023.100594)

## C. Gap register and eight boundary tests

**Implicit gap.** Nweke and Yeng establish release-specific evidence attribution under versioned controls. Alertmanager establishes temporary notification suppression through label matching. Those findings leave open which version relationships an interface must convey if one reference checks a latent episode, a displayed action and a reason on every event. A paired deletion and output-preserving recoding directly test the question. This inference follows from comparing inputs and endpoints; it is not attributed to either source's authors.

**Residual gap.** Abstract-stream verification establishes principled treatment of partial inputs. Explanation-producing monitors establish that a verdict can carry separately checkable evidence. The surviving issue is the difference between *two output contracts on the same input histories*: preserving display/activity/severity versus preserving those components and their specified reason. The R3 counterexample and replay decide that distinction for the stated lifecycle.

| Boundary | Test applied | Consequence |
|---|---|---|
| Question | Compare generating a version-linked finding with preserving a decision across multiple revisions. | Select the complete ordered trace as the primary evaluation unit. |
| Assumption | Replace persistent version names with relations computed by a trusted producer; retain event time, value and expiry. | Raw IDs are unnecessary for the decision under this contract. |
| Evidence | Compare activity intervals with displayed decisions and reason labels on identical inputs. | A correct interval history can conceal a wrong display. |
| Comparison | Give an established engine the full policy and events. | Exact PyContract parity rules out an accuracy advantage from the choice of engine. |
| Mechanism | Keep timers fixed while removing observation binding, suppression binding or freshness separately. | Suppression-binding errors can affect display alone; observation-binding errors can affect activity. |
| Transfer | Check whether disjoint predicate families also constitute new industrial sites or new temporal templates. | They do not. The result supports conformance on constructed traces with shared templates. |
| Contradiction | Compare unchanged episode intervals with changed warnings. | Different endpoints explain both observations. No credible contradiction between published findings was identified. |
| Knowledge connection | Join release attribution, temporal monitoring, and notification suppression. | A version relation can be dispensable for one output and indispensable for its explanation. |

Author-stated limitations are recorded only when inspected. The candidate and verdict columns are this review's inferences from methods and outcomes.

| Candidate | Author-stated boundary where verified | Independent comparison and verdict |
|---|---|---|
| Timed alerts and actionable explanations | Vamos reports finite test substrates and case-specific limits. | RTLola, TeSSLa and proof-tree monitoring already develop these capabilities. **Already addressed.** |
| Version-bound runtime governance findings | Nweke and Yeng bound assurance to evaluated controls and discuss evidence tamper detection and deployment trust. | Their evidence graph and Li et al.'s ledger directly establish release and alert version association. **Already addressed.** |
| Active condition separate from suppressed display | No author limitation is needed for the documented Alertmanager behavior. | Matcher-based silences establish the operational distinction. **Already addressed** as a feature. |
| Monitor adaptation to changing policy | Hublet et al. identify complexity questions for more general monitors. | Adaptation and its state-information conditions are established research problems. **Already addressed** at that general level. |
| Preserve activity and display when one of six revision fields is deleted from the specified event interface | This question is inferred from the inspected specifications and endpoints. | Nweke and Yeng jointly record revisions and findings. Alertmanager separates activity and suppression. The combined prior evidence leaves the six specified single-field projections and their dual-endpoint consequences open within the verified search. **Confirmed within verified search scope.** |
| Require literal raw revision identifiers across all implementations | The present proofs constrain a projection of the stated interface. | An authoritative source could supply equivalent change and match information instead of exposing raw identifiers. **Not established by the field-deletion result.** |
| Correct attribution under concurrent releases or transport reordering | Paper 7 specifies one artifact/rule trace and increasing supplied event times. | Concurrent rollout and transport robustness would require a different benchmark and reference. **Not testable with the frozen evidence.** |

**Explicit gap adjudication.** No inspected author-stated future direction was adopted as the central gap. The formal paper's stated composition boundary is an explicit qualification to its theorem. It does not establish that a generic composition problem remains unsolved. The accepted question above is a residual, independently inferred question about a named policy and named outputs.

## D. Ranked contribution options

| Rank and verdict | Consequence | Closest prior boundary | Decisive test | Feasibility and journal relevance |
|---|---|---|---|---|
| 1. Output-specific version requirements — CONFIRMED WITHIN VERIFIED SEARCH SCOPE | Determines what an evidence producer may discard when decisions and their explanations have different consumers. | Abstract stream precision, versioned findings and suppression are established; the verified evidence supplies no equivalent answer for this contract. | Inductive sufficiency proof, ambiguity witness for reason, and matched replay with separate endpoints. | Specification, code and frozen reference available. Directly concerns monitor inputs and observable outputs. |
| 2. Suppression fault detection by endpoint — CONFIRMED WITHIN VERIFIED SEARCH SCOPE | An activity-only score can certify a monitor that hides current warnings. | Alertmanager already separates activity from display. The added evidence is the measured effect of deliberately ignoring revision-bound deferrals. | Remove only suppression binding. Compare trace and interval agreement on the same designs. | Completed on 987 held-out base designs. Supports rank 1 as a diagnostic result. |
| 3. Increased accuracy through a new execution engine — ALREADY ADDRESSED as a mechanism; no performance advantage established | Engine choice would matter if equally informed implementations disagreed. | PyContract and ordinary SQL can express the policy. | Match context, inputs and reference exactly. | Both reproduce the reference. Retain as controls, not the central claim. |
| 4. Operational benefit across sites or concurrent rollbacks — NOT TESTABLE WITH AVAILABLE EVIDENCE | Would concern deployment behavior and decision consequences. | Requires event histories and an approved policy for those sites or deployment modes. | Prespecify event ordering and compare independent reference actions across systems. | Neither a deployment population nor those histories were recovered. |

A new project name, industrial terminology, and reimplementation of the Paper 6 detector were rejected as **NOT SCIENTIFICALLY CONSEQUENTIAL** contributions. Paper 6 fixes source revisions to score definition–implementation pairs. Paper 7 varies revisions within traces and scores the resulting decisions.

## E. Decisive design and measured contribution

**Claim.** The study establishes that the information sufficient for a review decision can be insufficient for the reason accompanying it, by deriving and testing output-specific version comparisons, using paired counterexamples and 4,935 frozen simulated traces, beyond prior demonstrations of versioned findings, notification suppression and general stream abstraction.

The three joint comparisons are whether either current version changed, whether both versions of a supplied observation match, and whether both versions of a supplied deferral match. The other inputs, including timestamps, values, packet presence and expiration, remain available. Six component comparisons keep evidence-context and policy comparisons distinct. Sufficiency is proved under the specified transition order. The study does not establish the smallest possible encoding across all representations.

| Evidence | Measured outcome | Interpretation |
|---|---|---|
| 30 paired witnesses, five pairs per original field projection | Equal projected inputs require different decisions. Each projection has a 5/10 upper bound on its own balanced assay. | Once the distinguishing information has been deleted without replacement, no deterministic decoder can recover both outputs. |
| Independent reference and full incremental monitor | 987/987 held-out base traces agree; 2,961/2,961 including two deterministic variants each. | Conformance for the specified policy. Deterministic variants are reported separately from base designs. |
| Disabled suppression binding | 30/987 base traces have a wrong displayed decision; all 987 active interval sequences agree. | Tracking intervals alone misses every affected trace in this ablation. |
| Three joint comparisons versus reference | 26,430/26,430 decision tuples agree. This decoder changed 510 policy-mismatch and 75 policy-change labels. | The observed 585 differences describe this decoding. They are not a mathematical lower bound on reason errors for other decoders. The paired counterexample establishes general ambiguity for the reason code. |
| Full-policy PyContract and SQLite | Both match all 26,430 event decisions from 4,935 traces. | Independent implementations can execute the full contract. This is retrospective conformance on reused traces. |
| External suppression fixtures | 4/4 mapped expectations reproduced out of 8 upstream assertions. | An external software test anchors a subset of the semantics. The other four use features outside the mapped policy. |

The original benchmark and oracle were frozen before held-out scoring. The finite designed sample supports exact agreement counts. No population sampling model identifies an industrial error rate. Additional operational claims would require an independently approved review policy and observed revision histories scored against authorized reviewer actions.

## F. Manuscript-ready introduction and related work

# Introduction

A governance review alert asks a reviewer to examine evidence associated with a source artifact, such as a software component or a key performance indicator (KPI) calculation. When that artifact or its review policy changes, correct handling of the alert depends on whether the supporting observation and any temporary deferral still apply. Under the policy studied here, three comparisons suffice to preserve the displayed state, episode activity, and severity. Keeping evidence and policy comparisons separate also preserves the reason given for a decision. We establish these results through a formal analysis of version comparisons and a controlled study of event traces.

An alert episode is the interval during which a review condition remains active across observations. Temporary suppression can defer its displayed warning while the underlying episode continues. Consider a constructed example in which a reviewer defers a warning for one revision of a component. After the revised component qualifies for a new episode, it has the same positive finding, and the deferral still names the earlier revision. A monitor that checks the deferral’s applicability displays the current warning; a monitor that accepts the obsolete deferral suppresses it. Both monitors can agree that the episode remains active. Their agreement on activity therefore conceals a disagreement about the action presented to the reviewer. This example motivates tracking what the reviewer sees alongside whether the review episode is active. At each event we compare three decision components: displayed state, activity, and severity. We separately compare the reported reason, such as an observation that names an obsolete evidence revision.

Recent work in *Science of Computer Programming* provides several parts of the machinery needed for this problem. Baumeister et al. describe how RTLola constructs stream monitors from specifications and produces assessments of a system’s behavior (Baumeister et al. 2026). Chalupa et al. address monitoring heterogeneous event streams and missing events through Vamos (Chalupa et al. 2025). These contributions establish mechanisms for evaluating observations over time. Closely related work also makes the origin of decisions explicit: Nweke and Yeng associate runtime decisions and compliance findings with release-specific evidence and versioned policy/configuration information (Nweke and Yeng 2026). In deployed alerting infrastructure, Prometheus Alertmanager separates active alerts from temporary notification suppression (Prometheus Authors n.d.). Together, these capabilities provide a concrete basis for examining what an interface must preserve when it passes observations and deferrals into a revision-sensitive monitor.

Abstract stream semantics already establish how incomplete observations can be transformed soundly and how precision depends on their representation (Leucker et al. 2019). The question here is the output-specific applicability contract for a revision-sensitive review: which comparisons preserve displayed state, episode activity, and severity, and which also preserve the reason label? Recording a version establishes an identity; deciding whether an observation or deferral applies requires a relationship between that identity and the current evidence and policy. If an interface removes that relationship, two distinct histories can become identical to the monitor even though the policy requires different actions. We investigate this boundary by removing selected version fields without replacing them with equivalent match or change information. For each resulting interface, paired traces test whether the retained inputs distinguish the required outputs. The comparison isolates information loss before monitoring from the subsequent computation of temporal decisions.

The study develops this analysis from the review signals produced by LEAP, a system for reconstructing source-linked KPI knowledge from enterprise code. Mouawad’s architecture study describes the extraction and publication of that knowledge (Mouawad 2026a). Here, five recovered source-review predicates provide Boolean observations for a newly specified lifecycle. The lifecycle defines when a warning qualifies for activation, persists, clears, escalates, becomes temporarily suppressed, or remains unresolved. Each observation and suppression is associated with an evidence context and policy version, allowing the lifecycle to check whether it applies to the current review. The evaluation follows complete event traces through these decisions.

Three questions connect the information analysis to the experiment. Which current-context, policy, observation-binding, and suppression-binding distinctions must survive an interface for exact decision sequences? How do removing evidence binding, suppression binding, or freshness checks affect episode activity and displayed decisions under the same lifecycle policy? Do the decisions remain unchanged under irrelevant metadata edits and equivalent changes of time unit? An incremental monitor and an independently implemented retrospective reference answer these questions alongside controlled requirement ablations. The benchmark contains 987 held-out base designs and their two transformations, yielding 2,961 simulated traces.

The study makes three contributions:

- A set of paired histories and a counting bound identify which deletions can make an exact review decision impossible.

- Three comparisons that combine the evidence and policy versions preserve all three decision components. Six separate comparisons also preserve the reason label.

- A controlled evaluation distinguishes errors in episode activity from errors in the displayed warning. The suppression ablation changes 30 of 987 base decision sequences while preserving every active interval.

## Related work

#### Specifying and observing runtime behavior

A runtime monitor applies a specification to an execution as observations become available. The specification determines the question the monitor answers, and the event interface determines the information available to answer it. Recent work in *Science of Computer Programming* develops both sides of this distinction. Baumeister et al. describe RTLola, which converts a specification over streams into an executable monitor. Derived streams can summarize observations, and Boolean triggers notify operators when specified conditions hold. Static specification analyses address runtime errors and memory requirements, while a configurable interface connects the generated monitor to the observed system (Baumeister et al. 2026). This gives a way to express and run a review policy once its input streams and output conditions have been defined.

Zhang et al. examine what an online verdict conveys about an execution. Under standard robustness semantics for Signal Temporal Logic, a partial signal can hide the effect of later observations on satisfaction or violation. CauMon uses causation semantics to identify how observations contribute to the verdict as execution proceeds (Zhang et al. 2026). The corresponding question for a revision-sensitive review rule concerns the applicability of the observation itself. A positive observation can be recorded intact and still refer to a superseded evidence context. The monitor can distinguish that case from a valid positive only if the event interface retains their differing relationship to the current context.

Chalupa et al. make unavailable observations explicit in Vamos. The middleware preprocesses heterogeneous event streams and can replace events lost under load with summary events. The summaries can retain information such as a dropped-event count and the range of timestamps. In their Wayland experiment, the hardware and graphical server provide separate event streams, which the monitor matches approximately by timestamp. It treats gaps as interruptions in checking (Chalupa et al. 2025). Ferrando and Cardoso examine a complementary question about what the monitor needs to read. Their partial monitoring construction can stop when a conclusive verdict is unreachable, or skip events irrelevant to checking the property. They demonstrate a prototype through a remote-inspection example and tests with synthetic properties (Ferrando and Cardoso 2025). These studies show how a monitor can deal with observations that are unavailable or unnecessary. For the review contract examined here, the test is whether discarding a version relationship collapses two otherwise identical inputs that require different decisions, including decisions about whether a suppression applies to an active episode.

#### Partial information and output precision

Leucker et al. represent gaps and imprecise values by abstract timed streams whose concretization contains the possible complete streams (Leucker et al. 2019). Their Theorem 2 (p. 282) establishes that each abstract TeSSLa operator is a perfect abstraction: applying it retains the precision obtainable by applying the concrete operator to every represented stream and abstracting the outputs. For , the underlying data-function abstraction must itself be perfect. Section 4 examines why perfect operators need not yield perfect compositions. Its timestamp example loses useful temporal bounds through ordinary operator composition; a dedicated time-aware abstraction recovers them. This analysis makes the chosen representation and its treatment through composition central to the precision of monitored outputs.

The present contract fixes a different precision target: exact equality of a specified review-decision tuple after replacing version identities with comparisons. An omitted binding can place two complete histories in one interface class even though their required decisions differ. The paired witnesses expose those classes, and the sufficiency proofs identify representations on which the decision function is constant. Three joint comparisons preserve displayed state, activity, and severity; keeping evidence and policy comparisons separate also preserves the reason label. Thus the relation to abstract-stream monitoring is concrete: both examine what an input representation allows an output to determine. Here the output choice separates two sufficient applicability representations and supports an executable comparison of episode activity, displayed decisions, and reasons under one lifecycle contract.

#### Timing, policy changes, and verdict explanations

Convent et al. define delay-generated events in TeSSLa, a language for transforming timestamped streams. Leucker et al. distinguish system time from event-arrival time and study how to compute verdicts from asynchronously arriving streams (Convent et al. 2018; Leucker et al. 2020). The evaluation here specifies decisions at supplied event times and compares each observation’s recorded time with that of the current event. Carwehl et al. use timed-automata patterns to change requirements during verification of self-adaptive systems and preserve relevant monitor state (Carwehl et al. 2023). This demonstrates that monitor state can carry across requirement changes under a specified adaptation. In the review policy studied here, current evidence and policy revisions define the scope of an episode, and a change to either resets its temporal state.

Industrial anomaly detection also uses qualification and clearing delays. Zhou et al. analyze on/off-delay timers for stochastic anomaly detectors (Zhou, Shang, and Chen 2025). Their detector addresses variation in a measured process. In the LEAP evaluation an observation can be accurate for a previous revision yet inadmissible for the current one. This changes the reference decision even when the numerical timing parameters remain fixed.

Verdict explanations provide another way to inspect a monitor’s decisions. Lima et al. construct proof-tree explanations for metric first-order temporal logic and implement a verified checker for the proofs (Lima, Munive, and Traytel 2024). The review monitor in this study returns the contract condition that governed a decision, such as a mismatch between the observation’s policy version and the current version. A projection-based test then asks whether the outputs can still be reconstructed once the field that distinguishes the two conditions has been removed. Established languages, adaptation patterns, and proof systems supply ways to express, change, or explain temporal behavior. The projection instead tests which input distinctions the specified behavior requires.

#### Versioned findings and suppression

Cross-journal research already connects findings to policy and release versions. Muhammad et al. connect versioned policies and schema-checked evidence bundles to a deterministic gate that returns pass, warn, or block. They evaluate release and audit decisions on 1,000 synthetic scenarios and five benchmark model configurations (Muhammad, Yow, and Alsenan 2026). Nweke and Yeng carry version binding into runtime decision logs and findings in two identity workflows. Open Policy Agent, used in their implementation, records the policy bundle revision at evaluation time alongside a decision identifier (Open Policy Agent Project n.d.). Their evidence contracts bind control, release, environment, and timestamp, with policy and configuration digests where required. A release gate checks policy provenance, and window-level checks report missing or stale evidence. Across four releases, their evaluation exercises missing release provenance and evidence completeness and produces machine-readable findings with hash-linked evidence (Nweke and Yeng 2026). Li et al. likewise record the deployed model version together with each threshold trigger, its observation window, metric, and proposed mitigation in a clinical audit ledger. Their simulation measures alert burden and time to trigger under different shifts (Li et al. 2026). These results establish version binding for release decisions, runtime findings, and individual threshold alerts.

Two complementary systems clarify the remaining distinction. Raţiu et al. incrementally check temporal constraints whenever related engineering artifacts change, using Object Constraint Language extended with linear temporal operators. Their industry-derived case demonstrates feedback on process deviations as relevant artifact histories evolve (Raţiu et al. 2026). Prometheus Alertmanager stores active alerts and can mute notifications when alert labels match a temporary silence (Prometheus Authors n.d.). This operational separation shows why checking activation can miss a displayed-action error. If a suppression authorized under an earlier evidence or policy revision is applied to a current episode, its active flag can remain correct while the action shown to a reviewer is wrong.

#### Checks on source-linked KPI records

Mouawad and Jones compare rule-based checks of generated KPI documentation with reviewer judgments (Mouawad and Jones 2026). In a companion study, Mouawad compares documented KPI definitions with their executable implementations using 24 source-pinned pairs from two financial analytics projects (Mouawad 2026b). The source pins fix the inputs for each comparison. In the present study, successive revisions are inputs to an event trace and can change whether a finding or deferral applies.

#### Information required by the review interface

The reviewed studies establish ways to compute timed verdicts, attribute findings to versions, and hold back notifications from active alerts. The concrete question carried forward is which comparisons implement the applicability contract for each output: the displayed-state, activity, and severity tuple, or that tuple together with its reason label. Here the three bindings play different roles. The current context and policy delimit an episode, the observation’s context and policy determine whether its finding is admissible, and the suppression’s context and policy determine whether a display override applies. The study isolates each role with pairs of traces that become identical when one field is removed without providing equivalent change or match information. It then measures complete-sequence agreement and event-level errors under the same temporal policy. The sufficiency result below also permits an interface to send the outcomes of the version comparisons directly. This analysis tests what a monitor must know about the three bindings to implement the review contract, independently of the language used to implement it.

The comparison began with 2026, 2025, and 2024 publications in *Science of Computer Programming* and examined related publications and technical documentation through 18 November 2026. It draws on inspected full-text sections for Vamos, the versioned assurance and clinical audit papers, and the temporal and explanation foundations, including Theorem 2 and Section 4 of the full Leucker et al. partial-information paper. The 2026 RTLola and CauMon descriptions and the engineering-process evaluation are reported at the level supported by primary previews and abstracts.

Table <a href="#tab:related-matrix" data-reference-type="ref" data-reference="tab:related-matrix">1</a> compares the reviewed approaches by their input object and the decision they produce. Versioned assurance and notification suppression already provide essential mechanisms. The present analysis connects those mechanisms through an event-interface question: which applicability distinctions must remain available to preserve both displayed decisions and episode activity?

<div id="tab:related-matrix">

| Approach                                                                                 | Input and established operation                                                                                     | Decision or evidential object                                                                                                          |
|:-----------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------------------------------------------------------|
| RTLola; Vamos (Baumeister et al. 2026; Chalupa et al. 2025)                              | Stream specifications and observations; monitor construction or best-effort acquisition of heterogeneous events.    | Stream assessments and triggers; events and reported gaps for downstream monitoring.                                                   |
| Abstract TeSSLa (Leucker et al. 2019)                                                    | Timed streams with gaps or imprecise values; abstract operators and analysis of compositional precision.            | Sound abstract outputs; operator-level perfection and selected perfect compositions.                                                   |
| CauMon; WhyMon (Zhang et al. 2026; Lima, Munive, and Traytel 2024)                       | Temporal requirements and observed signals/events; causation-aware verdicts or checked proof-tree explanations.     | Contributions of observations to a temporal verdict, or explanations certifying satisfaction/violation.                                |
| Changing-requirement monitoring (Carwehl et al. 2023)                                    | Requirement changes in self-adaptive systems; adaptation through timed-automata patterns.                           | Updated verification behavior with transfer of relevant monitor state.                                                                 |
| Audit-as-Code; Compliance-as-Code (Muhammad, Yow, and Alsenan 2026; Nweke and Yeng 2026) | Versioned policy, release context and evidence; deterministic gates and checks of evidence completeness/provenance. | Pass/warn/block gates, runtime decisions and machine-readable evidence-linked findings.                                                |
| Temporal engineering compliance (Raţiu et al. 2026)                                      | Changes to related engineering artifacts; incremental checking of temporal constraints.                             | Feedback on process deviations as artifact histories evolve.                                                                           |
| Alertmanager (Prometheus Authors n.d.)                                                   | Active alerts, label matchers and temporary silences.                                                               | Notification suppression separated from stored active alerts.                                                                          |
| Present study                                                                            | Current, observation and suppression bindings; interface projections and a specified review lifecycle.              | Necessary applicability distinctions, sufficient comparison representations, complete decision sequences and active-episode intervals. |

Comparison by monitored object and decision semantics. Entries describe capabilities established in the cited sources; they do not imply that a general-purpose framework cannot express the study policy.

</div>

<div id="refs" class="references csl-bib-body hanging-indent" entry-spacing="0">

<div id="ref-baumeister2026rtlola" class="csl-entry">

Baumeister, Jan, Bernd Finkbeiner, Florian Kohn, and Frederik Scheerer. 2026. “Stream-Based Monitoring with RTLola.” *Science of Computer Programming* 253: 103495. <https://doi.org/10.1016/j.scico.2026.103495>.

</div>

<div id="ref-carwehl2023changing" class="csl-entry">

Carwehl, Marc, Thomas Vogel, Genaína Nunes Rodrigues, and Lars Grunske. 2023. “Runtime Verification of Self-Adaptive Systems with Changing Requirements.” In *2023 IEEE/ACM 18th Symposium on Software Engineering for Adaptive and Self-Managing Systems (SEAMS)*, 104–14. <https://doi.org/10.1109/SEAMS59076.2023.00024>.

</div>

<div id="ref-chalupa2025vamos" class="csl-entry">

Chalupa, Marek, Fabian Muehlboeck, Stefanie Muroya Lei, and Thomas A. Henzinger. 2025. “Vamos: Middleware for Best-Effort Third-Party Monitoring.” *Science of Computer Programming* 240: 103212. <https://doi.org/10.1016/j.scico.2024.103212>.

</div>

<div id="ref-convent2018tessla" class="csl-entry">

Convent, Lukas, Sebastian Hungerecker, Martin Leucker, Torben Scheffel, Malte Schmitz, and Daniel Thoma. 2018. “TeSSLa: Temporal Stream-Based Specification Language.” In *Formal Methods: Foundations and Applications (SBMF 2018)*, 11254:144–62. <https://doi.org/10.1007/978-3-030-03044-5_10>.

</div>

<div id="ref-ferrando2025partial" class="csl-entry">

Ferrando, Angelo, and Rafael C. Cardoso. 2025. “Towards Partial Monitoring: Never Too Early to Give In.” *Science of Computer Programming* 240: 103220. <https://doi.org/10.1016/j.scico.2024.103220>.

</div>

<div id="ref-leucker2020streams" class="csl-entry">

Leucker, Martin, César Sánchez, Torben Scheffel, Malte Schmitz, and Alexander Schramm. 2020. “Runtime Verification of Real-Time Event Streams Under Non-Synchronized Arrival.” *Software Quality Journal* 28: 745–87. <https://doi.org/10.1007/s11219-019-09493-y>.

</div>

<div id="ref-leucker2019partial" class="csl-entry">

Leucker, Martin, César Sánchez, Torben Scheffel, Malte Schmitz, and Daniel Thoma. 2019. “Runtime Verification for Timed Event Streams with Partial Information.” In *Runtime Verification*, edited by Bernd Finkbeiner and Leonardo Mariani, 11757:273–91. Lecture Notes in Computer Science. Springer. <https://doi.org/10.1007/978-3-030-32079-9_16>.

</div>

<div id="ref-li2026sentinel" class="csl-entry">

Li, Yue, MengYu Yuan, Yujing Yang, Jia Fu, Yi Xin, Chu Jie Duan, and Jun Wang. 2026. “An Ethics-Informed Computable Audit Framework for Monitoring Misdiagnosis Risk in AI-Assisted Diagnosis.” *Scientific Reports* 16: 16462. <https://doi.org/10.1038/s41598-026-46652-1>.

</div>

<div id="ref-lima2024explainable" class="csl-entry">

Lima, Leonardo, Jonathan Julián Huerta y Munive, and Dmitriy Traytel. 2024. “Explainable Online Monitoring of Metric First-Order Temporal Logic.” In *Tools and Algorithms for the Construction and Analysis of Systems (TACAS 2024)*, 14570:288–307. <https://doi.org/10.1007/978-3-031-57246-3_16>.

</div>

<div id="ref-mouawad2026architecture" class="csl-entry">

Mouawad, Meshaal Obaid. 2026a. “Reconstructing Source-Linked KPI Documentation: Architecture and Evaluation of LEAP.” Public author manuscript, revision P6R17. <https://github.com/Meshaal-Mouawad/LEAP-Paper1-Evidence/tree/a20b243683a262fd43987013117120c313ec8fa8/SCP_P6R17>.

</div>

<div id="ref-mouawad2026discrepancies" class="csl-entry">

———. 2026b. “KPI Definition–Implementation Discrepancies: A Source-Pinned Evaluation of LEAP Checks and Executable Contracts.”

</div>

<div id="ref-mouawadjones2026checks" class="csl-entry">

Mouawad, Meshaal Obaid, and Bryan A. Jones. 2026. “Evaluating Checks for Generated KPI Documentation: Rule Coverage and Reference Criteria.”

</div>

<div id="ref-muhammad2026audit" class="csl-entry">

Muhammad, Aoun E., Kin-Choong Yow, and Shrooq Alsenan. 2026. “Audit-as-Code: A Policy-as-Code Framework for Continuous AI Assurance.” *Frontiers in Artificial Intelligence* 9: 1759211. <https://doi.org/10.3389/frai.2026.1759211>.

</div>

<div id="ref-nwekeyeng2026compliance" class="csl-entry">

Nweke, Livinus Obiora, and Prosper Kandabongee Yeng. 2026. “Compliance-as-Code for AI-Driven Identity Systems: Clause-to-Control Traceability and Machine-Readable Evidence.” *IEEE Access* 14: 28258–81. <https://doi.org/10.1109/ACCESS.2026.3665991>.

</div>

<div id="ref-opa2026logs" class="csl-entry">

Open Policy Agent Project. n.d. “Decision Logs.” Open Policy Agent documentation. <https://www.openpolicyagent.org/docs/management-decision-logs>.

</div>

<div id="ref-prometheus2026alertmanager" class="csl-entry">

Prometheus Authors. n.d. “Alertmanager.” Prometheus documentation. <https://prometheus.io/docs/alerting/latest/alertmanager/>.

</div>

<div id="ref-ratiu2026runtime" class="csl-entry">

Raţiu, Cosmina Cristina, Christoph Mayr-Dorn, Sebastian Stock, and Alexander Egyed. 2026. “Automated Runtime Temporal Constraint Checking for Engineering Process Compliance.” *Journal of Systems and Software* 238: 112868. <https://doi.org/10.1016/j.jss.2026.112868>.

</div>

<div id="ref-zhang2026caumon" class="csl-entry">

Zhang, Zhenya, Jie An, Paolo Arcaini, and Ichiro Hasuo. 2026. “CauMon: A Tool for Online Monitoring Against Signal Temporal Logic.” *Science of Computer Programming* 253: 103499. <https://doi.org/10.1016/j.scico.2026.103499>.

</div>

<div id="ref-zhou2025delay" class="csl-entry">

Zhou, Jing, Jun Shang, and Tongwen Chen. 2025. “Performance Analysis for Stochastic Anomaly Detectors with on/Off-Delay Timers.” *Automatica* 173: 112073. <https://doi.org/10.1016/j.automatica.2024.112073>.

</div>

</div>


## G. Verification and editorial decision

| Gate | Assessment and evidence |
|---|---|
| J1 Current | **Pass within targeted coverage.** SCP issue-year screening from 2026 to 2024 and the most relevant papers are recorded under A. |
| J2 Cross-journal | **Pass.** IEEE Access, Scientific Reports, Frontiers, JSS, IST, conference and tool records challenge broad interpretations. |
| J3 Distinction | **Pass.** C separates stated boundaries from independently inferred gaps. |
| J4 Specific consequential gap | **Pass.** The displayed suppression outcome can change while activity remains correct. |
| J5 Closest predecessor | **PASS for the contract-specific claim.** Leucker et al. establish operator-level precision but identify a composition boundary. Paper 7 supplies a separate proof for its composed lifecycle and an explicit reason ambiguity. Nweke and Yeng establish binding and evidence findings. The verified comparison leaves projection-level preservation of the pair of outputs open. |
| J6 Test | **PASS.** Three joint comparisons and six separated comparisons are assessed against different outputs. Paired witnesses and complete implementations directly address distinguishability and mechanistic effects. |
| J7 Evidence | **PASS within the study scope.** The endpoint-specific replay yielded zero tuple disagreements and 585 reason-label disagreements; the counterexample proves ambiguity independently of the observed count. Counterexamples, finite benchmark bounds and agreement results support the claim. |
| J8 Reader | **Pass for drafted prose.** The section follows monitor inputs, outputs and consequence through the cited findings. |
| J9 Sources | **Pass at declared access levels.** The 2026 SCP tool papers were verified through primary abstracts/previews, so the manuscript uses positive descriptions of supported capabilities. Full-text sections were examined for the principal cross-journal challenges. |
| J10 Journal | **Pass for scientific relevance.** An executable review specification and an information-sufficiency assessment connect directly to SCP's monitoring and verification literature. |



**Verification date: 18 November 2026.** The manuscript source, bibliography and rendered pages are included as a separate paper. The exact 2026 RTLola and CauMon articles and the 2025 partial-monitoring article were assessed at preview or abstract depth; the report uses only positive, supported attributions from those records.

**Decision: READY TO DRAFT WITH VERIFIED EVIDENCE.** The selected result is a contract-specific separation of decision information and reason information. The reviewed literature precludes broad priority claims for versioned alerts, partial observation, notification suppression, or explanatory monitoring. The revised introduction and related work in F implement this decision. Journal submission readiness is a separate decision with outstanding personal declarations and current journal-guide verification.

## Appendix · Pivotal source extractions

# Paper 7 pivotal source cards

Verified on 18 November 2026 for a study of which version relationships an event interface must preserve to reproduce the displayed review decision and underlying episode activity. The study distinguishes the current evidence context and policy, the observation's context and policy, and the suppression's authorization context and policy. Each card separates the authors' reported evidence and stated limits from the independent comparison with this research question.

## Full-text scholarly sources

### Nweke and Yeng · Release-attributed compliance findings

- **Identity and access.** Livinus Obiora Nweke and Prosper Kandabongee Yeng, *Compliance-as-Code for AI-Driven Identity Systems: Clause-to-Control Traceability and Machine-Readable Evidence*. Peer-reviewed *IEEE Access*, 14, 28258–28281, published 18 February 2026. The publisher's record verifies publication and the full version-of-record copy supports methods and results. [Official DOI](https://doi.org/10.1109/ACCESS.2026.3665991) · [Version-of-record text](https://www.researchgate.net/publication/400811779_Compliance-as-Code_for_AI-Driven_Identity_Systems_Clause-to-Control_Traceability_and_Machine-Readable_Evidence)
- **Question and claims.** Can a compliance pipeline keep technical findings attributable as configurations and policies evolve, make missing monitoring evidence explicit, and export independently checkable artifacts? The authors specify C1, release attribution through required provenance, C2, decidable evidence completeness in fixed windows, C3, bounded tamper detection for exported resources, and C4, explicit staleness through privacy-minimized heartbeat summaries. §I-B and §III-D–E.
- **Inputs and conditions.** A bounded set of identity-workflow controls, a pinned policy-bundle digest for deployment, explicit evidence contracts with mandatory bindings, fixed windows, and a host substrate trusted enough to originate evidence. Workloads are MIDV-500 document onboarding and synthetic OpenID4VP/W3C VC DM 2.0 wallet-verification traces, with fixed-seed schedules and injected failures. §III–IV and §VIII-B–D.
- **Method.** CI configuration checks, a fail-closed promotion gate, Open Policy Agent external authorization, and an evidence graph. Canonical bindings include control, release, environment and time, with applicable policy and configuration digests. Fixed-window completeness produces machine-readable findings and remediation items. Evidence exports reference hashes through the Open Security Controls Assessment Language. §IV-F–G and §V-A–C.
- **Evidence and finding.** Four releases exercise release binding, missing artifacts, exports and runtime feasibility. The missing digest in r1 triggers a finding and r2–r4 pass that gate. Window-level staleness and evidence gaps become assessable findings. The paper reports release-level and window-level outcomes, hash-linked export properties and wallet-verification latency at 5,000 requests and concurrency 50. §VIII-C–F and Tables 2–5.
- **Authors' stated limits.** Their controls cover bounded obligations. The workloads represent two identity patterns. Hash recomputation detects modification relative to stored digests, with stronger assurance requiring anchoring. A fully compromised host can forge evidence at source. The evaluation measures authorization-boundary latency and evidence volume, with broader organizational costs outside those measures. §III-C and §IX-B.
- **Independent inference and relationship.** This is the strongest direct prior art against broad novelty for release/policy/evidence binding and findings about stale evidence. Its evidence checks concern provenance gates and completeness over windows. The remaining comparison concerns six field deletions at the event interface and whether a stale suppression changes the displayed action while activity is preserved. That inference follows from the measured outcomes and the evidence contract, separately from the authors' stated limits.

### Li et al. · Version-labeled clinical monitoring triggers

- **Identity and access.** Yue Li, MengYu Yuan, Yujing Yang, Jia Fu, Yi Xin, Chu Jie Duan and Jun Wang, *An ethics-informed computable audit framework for monitoring misdiagnosis risk in AI-assisted diagnosis*. Peer-reviewed *Scientific Reports*, 16, 16462, published 6 April 2026. Read the publisher PDF. [Official DOI](https://doi.org/10.1038/s41598-026-46652-1) · [Version of record](https://www.nature.com/articles/s41598-026-46652-1.pdf)
- **Question and expectation.** Can quantitative signals and threshold policies turn misdiagnosis risk into reviewable actions at deployment time? The stress test examines whether trigger behavior varies with shift type and severity and whether the system keeps auditable records of those triggers. The paper frames this as a controlled design evaluation. Abstract, Introduction and “Scenario-based simulation”.
- **Inputs and conditions.** A binary diagnostic-support model yielding a continuous score, deployment features, subgroup tags and clinician actions, with outcome labels available potentially after a delay. The experiment uses controlled synthetic streams with feature/device, mixture and prevalence-shift conditions, 20 rolling windows of 400 cases and a classification threshold fixed on development. “Failure modes and operational risk signals”, pp. 2–5, and “Scenario-based simulation”, pp. 7–8.
- **Method.** Combines four risk components in an index, evaluates label-free and label-dependent indicators as available, and applies thresholds, stop rules and a cooldown. For each threshold breach the ledger records timestamp, model/version, site or subgroup, window, metric and value, exceeded band, and proposed mitigation. “Incident response, audit trail, and ‘stop rules’”, printed p. 6.
- **Evidence and finding.** Compares stability, shift and severity conditions through predictive metrics, window alert rate, first-trigger time and persistence. The authors report low burden under stable simulated conditions and graded response to the specified shifts. In one shifted deployment stream, Table 5 reports 20 of 20 windows triggered, with empirical run-to-run percentiles reported for performance metrics. Evaluation protocol, Fig. 2, Table 5, Supplementary Tables S1–S2 and Algorithm S1.
- **Authors' stated limits.** Synthetic streams simplify case mix, clinical workflows and clinician adaptation. Delayed/incomplete outcome labels complicate detection of several shift types. False-alert burden depends on thresholds, window size, indicator dependence and response capacity. Prospective multisite evaluation is future work. “Future directions”, pp. 9–10.
- **Independent inference and relationship.** The paper demonstrates prior per-alert model-version association and time-dependent actions, including cooldown. Its documented comparison varies drift and reporting conditions. A case contrasting two suppression-authorization revisions with the same underlying activity remains a separate event-interface question.

### Chalupa et al. · Best-effort runtime monitoring under missing events

- **Identity and access.** Marek Chalupa, Fabian Muehlboeck, Stefanie Muroya Lei and Thomas A. Henzinger, *Vamos: Middleware for Best-Effort Third-Party Monitoring*. Peer-reviewed *Science of Computer Programming*, 240, 103212, February 2025 issue, online 23 September 2024. Read the version of record at ISTA. [Official DOI](https://doi.org/10.1016/j.scico.2024.103212) · [Version of record](https://research-explorer.ista.ac.at/download/18169/18831/2024_ScienceCompProg_Chalupa.pdf)
- **Question and claims.** The authors ask how efficient the framework is, whether it facilitates best-effort monitoring, and whether it applies in different practical settings. The design aims to combine limited access to third-party software with monitoring that can continue under events the monitor cannot keep up with. §§1 and 5, RQ1–RQ3.
- **Inputs and conditions.** Heterogeneous instrumented or externally observable streams, configurable buffers, and monitor-specific rules for remaining incomplete observations. Evaluation includes throughput/prime-event experiments, a simulated banking benchmark, race detection, and Wayland hardware and client events. The Wayland experiment assumes a bounded amount of clock skew and uses timestamp proximity for alignment. §§3–5.3.3.
- **Method.** Collects and preprocesses event sources, optionally drops events under load and reports a gap, and uses an arbiter to produce one stream for the verdict monitor. A gap event can carry aggregates such as a count and a timestamp range. The Wayland monitor stops checking a segment at a gap and can resume at the next segment. §§3.3–3.4 and 5.3.3, Fig. 13.
- **Evidence and finding.** Stress experiments vary buffering and input rates. The race comparison uses Helgrind and ThreadSanitizer across 391 benchmarks, of which 118 have established ground truth. In the replayed Wayland pointer evaluation, the reported integrity deviations were below 1% even for small tolerated positional error, with these reported deviations treated as presumed false positives. The authors conclude that useful best-effort detection is possible under the tested conditions. §§5.2–5.4, Figs. 8–14.
- **Authors' stated limits.** The study has no good ease-of-use metric. The authors identify architecture and CPU assumptions, limited evidence for large numbers of streams, benchmark selection and the use of one person's prerecorded pointer motions. §5.4 and §5.4.1.
- **Independent inference and relationship.** Vamos establishes what a monitor can do when an observation is dropped or timing alignment is imperfect. Paper 7 varies a different information boundary, where the event arrives with an intact value and its current-version relationship is absent or obsolete. The decision may still depend on that relationship even under a complete transport stream.

### Lima, Huerta y Munive and Traytel · WhyMon explanatory verdicts

- **Identity and access.** Leonardo Lima, Jonathan Julián Huerta y Munive and Dmitriy Traytel, *WhyMon: A Runtime Monitoring Tool with Explanations as Verdicts*. Peer-reviewed ATVA 2024 proceedings, LNCS 15055, pp. 76–90, published 2025. The publisher and Copenhagen record verify identity. The complete author-hosted tool paper was accessed in this pass. The separate TACAS 2024 research paper provides the formal proof/checking method. [Tool paper DOI](https://doi.org/10.1007/978-3-031-78750-8_4) · [Author PDF](https://www21.in.tum.de/~traytel/papers/atva24-whymon-tool/whymon-tool.pdf) · [TACAS DOI](https://doi.org/10.1007/978-3-031-57246-3_16)
- **Question and demonstration objective.** Can an online monitor explain why a given variable assignment satisfies or violates a specified temporal formula, and can users inspect and verify those explanations? The tool article demonstrates architecture and use in a risk-based authentication case. The TACAS article develops proof trees and a checker for the underlying formal method. Tool §§1–2 and 6. TACAS §§3–6.
- **Inputs and conditions.** A logical signature, a metric first-order temporal logic formula, and a prefix of timestamped predicate events carrying data. The demonstration selects 150 time-points from a synthetic risk-based authentication dataset, retains country and user attributes, and sets a 151,200-ms look-back. Proof-checking evaluates the supplied formula and observed execution. Tool §§2, 5 and 6.
- **Method.** An incremental monitor emits proof-based explanations for assignments to free variables. An Isabelle-verified checker certifies explanations in a CLI mode. A graphical interface lets users inspect subformulas, relevant time-points and witness assignments. Tool §§3–5 and Figs. 1–5.
- **Evidence and finding.** The risk-based authentication example explains a simulated takeover pattern and exposes a vacuous subformula that the authors then revise. It demonstrates the value of proof output for diagnosing which formula and observed events supported a verdict. Tool §6, especially Figs. 6–9 and “Reflection”.
- **Authors' stated limits.** The results apply to observed traces. The tool paper reports that its graphical interface struggles beyond 500 time-points for complex formulas and that a 51-minute trace prefix took 48 minutes in one CLI run on an Apple M1 with 16 GB RAM under the reported window. The authors could not evaluate larger window values in that case. Tool §1 and §6 “Reflection”.
- **Independent inference and relationship.** WhyMon closes broad novelty claims about explaining temporal verdicts from evidence. A proof checker can certify a verdict relative to the supplied formula and events. The comparison with Paper 7 concerns whether the supplied events still distinguish current evidence, obsolete evidence, and an obsolete suppression under two different histories.

### Leucker et al. · Timed event streams with partial information

- **Identity and access.** Martin Leucker, César Sánchez, Torben Scheffel, Malte Schmitz and Daniel Thoma, *Runtime Verification for Timed Event Streams with Partial Information*. Peer-reviewed RV 2019 proceedings, LNCS 11757, pp. 273–291, published 1 October 2019. Read the full version published to a coauthor's institutional page. This is a distinct paper from the 2020 journal article on non-synchronized arrival. [Official DOI](https://doi.org/10.1007/978-3-030-32079-9_16) · [Full publication text](https://software.imdea.org/~cesar/papers/leucker19runtime.pdf)
- **Question and formal claims.** Can a stream specification written for complete traces be translated to process timed observations with gaps and imprecise values soundly? Theorem 1 establishes operator soundness, Corollary 1 establishes soundness of the translated specification, and Theorem 2 establishes precision of individual abstract operators relative to the chosen abstraction, with its stated assumption for lifted functions. §§1–4.
- **Inputs and conditions.** Non-synchronized timed event streams, abstract intervals/points representing missing information, possibly imprecise values, and a TeSSLa specification interpreted over the set of concrete streams compatible with the abstract input. The macro implementation uses a smallest relative time step for its chosen encoding. §§2–3 and 6.
- **Method.** Replaces concrete TeSSLa operators with abstract versions that propagate the uncertainty of possible input completions. Gives a sliding-window/queue example, then implements the abstract operators as macros using the original runtime engine. §§3–6.
- **Evidence and finding.** Combines the transfer theorems with a TeSSLa implementation and empirical comparison against best possible outputs on constructed examples. It compares computation-graph depth for overhead and precision of the abstract outputs. Simple reset/count/filter examples are exact under the tested inputs. Burst and queue examples can lose accuracy, while a finite-size queue example is exact. §6, Fig. 3 and §7.
- **Authors' stated limits.** Perfect precision for individual operators does not ensure perfect precision for a composition. Some gap information remains unrecoverable in their examples. A simplifying implementation choice for the initial event-less phase of the abstract `last` operator retains soundness while losing perfect precision for that phase. §4 and §6, printed pp. 282 and 287–289.
- **Independent inference and relationship.** This is the key conceptual antecedent for reasoning about indistinguishable compatible completions with partial input. Its task returns a sound abstract verdict from streams with gaps. Paper 7 tests exact event-by-event reproduction of a particular lifecycle output pair after removing a defined version relationship. The elementary indistinguishability argument is established reasoning. The substantive contribution is the concrete binding contract and its output-specific witnesses.

## Full primary implementation source

### Prometheus Alertmanager · Notification silences

- **Identity and access.** Prometheus project, *Alertmanager* official documentation, accessed 18 November 2026, and repository source `silence/silence_test.go` at tag v0.28.1. Primary product documentation and test code. No publication DOI applies. Both the documentation and pinned source assertions were inspected. [Official documentation](https://prometheus.io/docs/alerting/latest/alertmanager/) · [Pinned upstream test](https://github.com/prometheus/alertmanager/blob/v0.28.1/silence/silence_test.go#L1372-L1443)
- **Question and design claim.** Under what conditions does a time-scoped silence mute notifications for a received alert? The documentation specifies stored alerts and subsequent notification routing and muting. The upstream assertions provide executable behavioral expectations. “Architecture” and “Silences”, and `TestSilencer`.
- **Inputs and conditions.** An incoming alert's labels, one or more active silences and their matchers, and time relative to the silence's interval. The check requires all matchers in a silence to match an alert. The source exercise includes matching and nonmatching exact labels, expiry, scheduled activation, overlaps and a regular-expression matcher. `TestSilencer`, lines 1372–1443 at v0.28.1.
- **Method.** Alertmanager stores active alerts. The silence layer checks active time windows and matching labels before routing notifications. The source fixture uses a controlled clock and changes the silence and target labels to assert a Boolean muting decision. “Architecture” and “Silences”, and `TestSilencer`.
- **Evidence and finding.** Documentation and the upstream test establish that active alert storage and notification muting are separate. The test specifies an unmuted alert with no silence or no matching silence, muting with a matching active silence, and a return to unmuted after expiry. Paper 7 separately translated the first four upstream assertions into its own traces and reproduced all four expected output values. That replay used the Paper 7 implementation. [Upstream test](https://github.com/prometheus/alertmanager/blob/v0.28.1/silence/silence_test.go#L1372-L1443)
- **Source-stated scope.** The documentation defines a notification routing component driven by incoming alerts and configured silences. It makes an operational specification rather than an empirical or scientific hypothesis. The upstream fixture tests configured muting behavior. Coverage of only four of its eight assertions is a limitation of the Paper 7 mapping.
- **Independent inference and relationship.** The operational distinction between active and muted is established. In a review policy, a mute can depend specifically on the evidence and policy that authorized it. The fixture agreement checks receipt, matching and expiry behavior. The revision-field projections address what a monitor can recover from a specified interface when the relation between the authorization and current evidence changes.

## Exact journal article at abstract or preview level

### Baumeister et al. · RTLola monitor construction

- **Identity and access.** Jan Baumeister, Bernd Finkbeiner, Florian Kohn and Frederik Scheerer, *Stream-based monitoring with RTLola*. Peer-reviewed *Science of Computer Programming* Original Software Publication, 253, 103495, August 2026 issue. Verified against the publisher preview and CISPA/TUM group records. Full exact journal text was unavailable through the checked routes. [Official DOI](https://doi.org/10.1016/j.scico.2026.103495) · [Publisher preview](https://www.sciencedirect.com/science/article/pii/S0167642326000614) · [CISPA author record](https://finkbeiner.groups.cispa.de/publications/2026-rtlola-tutorial-journal/)
- **Question and objective.** How can developers create executable, configurable stream monitors for embedded and safety-critical systems with analysis of correctness, runtime errors and memory use? The accessible material presents a framework overview and illustrative objective. A particular statistical hypothesis could not be verified. Abstract and “Motivation and significance” preview.
- **Inputs and conditions.** Declarative stream specifications and asynchronous dense-time inputs, typically sensor readings. The monitor produces processed stream values and Boolean triggers. The scope in the preview includes interpreted or compiled execution. Publisher introduction and overview snippets.
- **Method.** The RTLola framework analyzes stream specifications statically, supports configurable integration, and constructs executable monitors. Boolean trigger streams can notify operators. Abstract and publisher snippets on framework and stream processing.
- **Evidence and finding.** The preview describes the tool's implementation and illustrates applications in aerospace, including earlier DLR and Volocopter work. The 2025 same-author tutorial independently illustrates the language and an aerospace example. Specific experimental designs, measurements and numerical outcomes for the exact 2026 article could not be verified. [Separate 2025 tutorial](https://doi.org/10.1007/978-3-031-71177-0_33)
- **Authors' stated limits.** No formal limitations section or completeness claim was verified for the exact journal article. Safety-critical operation, bounded memory and integration are the stated requirements visible in the abstract.
- **Independent inference and relationship.** RTLola is a plausible platform for expressing a full review contract if the relevant event-stream relationships are present. Its reported construction capability does not resolve the specific question of how the output sequence changes when one such relationship is removed. This is an interpretation of available evidence, without inference about unseen content or encoding limits.

### Zhang et al. · Causation semantics for informative online verdicts

- **Identity and access.** Zhenya Zhang, Jie An, Paolo Arcaini and Ichiro Hasuo, *CauMon: A tool for online monitoring against signal temporal logic*. Peer-reviewed *Science of Computer Programming* Original Software Publication, 253, 103499, August 2026 issue. Publisher abstract and motivation preview, Kyushu record and Jie An's publication list verify the exact item. Full exact journal text was unavailable through the checked routes. [Official DOI](https://doi.org/10.1016/j.scico.2026.103499) · [Publisher preview](https://www.sciencedirect.com/science/article/pii/S0167642326000651) · [Kyushu record](https://kyushu-u.elsevierpure.com/en/publications/caumon-a-tool-for-online-monitoring-against-signal-temporal-logic/)
- **Question and objective.** Can online monitoring describe how successive observations affect temporal satisfaction and violation when conventional robustness semantics masks relevant developments? The journal abstract reports an online and scalable tool objective. A formal experimental hypothesis could not be verified. Abstract and “Motivation and significance” preview.
- **Inputs and conditions.** Runtime signal traces from a cyber-physical system and Signal Temporal Logic specifications interpreted over those traces. The journal preview does not expose the detailed tested traces, formula families or experimental configuration.
- **Method.** Apply causation semantics in online signal monitoring to characterize the relevance of incoming signal observations for satisfaction or violation. Separately, the same authors' 2023 full paper defines Boolean and quantitative causation monitors, and their 2024 artifact identifies speed and informativeness studies. [Separate 2023 method](https://doi.org/10.1007/978-3-031-37706-8_4) · [Separate 2024 artifact](https://zenodo.org/records/12518433)
- **Evidence and finding.** The exact journal abstract reports more faithful descriptions of system evolution than conventional robustness monitoring and sufficient efficiency for online use with longer executions and complex formulas. These are abstract-level author reports. Journal-specific measurements, comparisons and uncertainty were not verified.
- **Authors' stated limits.** The abstract and preview identify the problem of information masking in robustness semantics and the cyber-physical/STL scope. Any separate limitations or discussion specific to the exact journal article could not be verified.
- **Independent inference and relationship.** CauMon is prior art for richer, more informative online verdicts. Paper 7 seeks to distinguish whether the observed value or a suppression applies to the current evidence and policy. That distinction concerns the input contract before a monitor can calculate or explain its verdict. No inference is made about uninspected CauMon features.

## Combined comparison

Vamos and Leucker et al. establish ways to handle incomplete streams. RTLola supplies an executable stream framework, while CauMon and WhyMon establish stronger forms of verdict information or explanation. Nweke and Yeng and Li et al. establish version attribution for findings and alerts. Alertmanager establishes that an active alert and a muted notification can coexist. The remaining scoped question is whether each of the six specified version relationships can be dropped from the Paper 7 event interface without changing its two decision outputs. Paired histories and reference decisions answer that question directly for the stated contract.



## Appendix · Companion journal editorial assessment

# Paper 7 — Gold Niche companion editorial test

**Journal-fit decision: FIT for Science of Computer Programming's regular research track.** The supported contribution is an output-specific information requirement for one explicit review lifecycle: three joint version comparisons preserve decisions; six component comparisons also preserve the specified reason labels. The proofs, counterexample and trace replays support that claim. Retain this contribution and the completed study.

**Gold companion completion decision: COMPLETE WITH RECORDED VENUE/ADMIN CHECK. Journal submission status: NOT READY.** Current journal-specific instructions and personal declarations remain unverified. Gold §11 explicitly distinguishes these checks from an independently supported scientific argument. No repeated experiment or further scientific expansion is required by this companion review.

## Prompt and review identity

Applied the complete **GOLD_NICHE_JOURNAL_CHIEF_EDITOR_PROMPT_v1(5).md**, edition1.0, recovered from the supplied native file, version0, `libfile_fde3_f-30f800bd2ea48191a94e5e43176e4167_6246015f02148191b6fb1aaa7040b316`. All426 lines were retrieved. The local recovered text is `GOLD_NICHE_JOURNAL_CHIEF_EDITOR_PROMPT_v1_5.md`,39,536 bytes, SHA-256 `03abb8581e2cd12046d065144b7b9cd880d2f2a9c2c0a8f3c6440fc3d8f8e8b4`.

Scope is the **companion REVIEW/VERIFY test** invoked by the Mouawad gap-discovery protocol. The work reuses completed primary-source, computational, editorial and rendered-document checks. It does not restart research discovery or apply every possible draft/develop workflow to an already completed experiment. Reviewer: separate AI agent `/root/final_review`,18 November2026; this is an AI-agent editorial assessment, not human adjudication or a journal decision. The manuscript was not modified.

## Paper Identity and Evidence Brief — Gold §0

| Item | Recovered record |
|---|---|
| Exact article | *Version Comparisons Preserve Governance Alert Decisions Across Evidence and Policy Revisions*. Sole author: Meshaal Obaid Mouawad. |
| Genre and object | Software specification/verification study with elementary propositions and controlled computational conformance evidence. The object is an ordered governance-review trace, with current evidence/policy, observations and deferrals. |
| Authoritative edition | `gap_execution/Paper7.tex`, SHA-256 `f65ff8df9246305eb8f2432647d67997815c0aac855d23de180118c8a5277e94`; PDF SHA-256 `0a762c6f2acfc4608bc6cc45452d624f38e8563d4398efd04e6bf2083b273505`,19 pages. |
| Primary target and reader | Science of Computer Programming, regular research track; readers studying executable specifications, monitor inputs, abstraction and verification. Numbered citation style and elsarticle source are implemented. |
| Adjacent journal candidate | Journal of Systems and Software is a recorded topical alternative because Rațiu et al.'s2026 engineering-process temporal-compliance paper is a close application precedent. No switch is recommended or claimed verified against that journal's current author guide; SCP's monitoring conversation supplies the present fit evidence. |
| Status | Prepared research manuscript, not submitted. No acceptance, review invitation or industrial deployment is inferred. |
| Protected record | Original15-file freeze,4,935 traces,26,430 events, reference and raw outputs, proofs, categorical severities, witness construction, separate SQL/PyContract/fixture protocols, source snapshots and author metadata. |
| Closed findings | Missing-unit oracle correction preserved separately; all frozen outputs unchanged. R2/R3 endpoint wording, representation result placement, pipeline, source comparison, PyContract execution and reason-count interpretation corrected and checked. |
| Current evidence hierarchy | Frozen code/data/reference and actual executions govern numerical claims; current source governs the article; inspected primary papers govern prior-work claims; dated editorial decisions and publisher sources govern presentation at their verified access level. |
| Required outputs | This companion brief, contribution–evidence map, Gold gates, prioritized remaining actions and retained passages. Existing manuscript, source/PDF, figures, bibliography, supplement and change records remain the deliverables. |

### Plain-language argument map

**Problem:** an observation or permission to hide a warning can refer to an earlier revision, so activity alone does not determine what a reviewer should see. **Existing ability:** timed stream monitors evaluate temporal rules; assurance systems bind findings to releases; Alertmanager suppresses notification while activity continues; abstraction and explanatory monitoring already have formal foundations. **Question:** which version relationships suffice for the displayed decision, and which additional distinctions preserve its reason? **Response:** a fixed lifecycle, paired deletion witnesses, inductive comparison encodings, and identical-input replays. **Evidence:** proofs and counterexample;987 held-out base designs;3-versus6-comparison replay; established-engine parity; separate external suppression assertions. **Contribution:** the information preserved by an interface depends on whether the consumer requires the decision tuple or that tuple plus its specified reason.

## Niche-journal and closest-prior-work challenge — Gold §§1–3

The journal benchmark is `../r3/benchmark.md`: three full published SCP articles—Vamos, the scenario-based driving-requirement study and detectEr—are compared by problem introduction, mechanism, evaluation and closing interpretation. They establish an editorial model for an inspectable software operation with evidence appropriate to its claims. They do not establish an acceptance probability.

The decisive formal challenge is Leucker et al.'s *Runtime Verification for Timed Event Streams with Partial Information*. The recovered full text `leucker19runtime.txt` states Theorem2 on printed p.282: individual abstract operators preserve the precision available under their abstraction, with a specific assumption for lifted functions. The following paragraph distinguishes that result from general compositional perfection; §4 examines selected compositions. This is stronger prior art than a generic citation to “runtime monitoring.” Paper7's revision correctly retains the concrete composed lifecycle and its two output contracts as the question to answer. `literature_check.json` fixes the primary PDF, DOI, pages and revision scope.

Nweke and Yeng already provide release/policy/evidence binding and stale/missing-evidence findings. WhyMon already generates explanations whose proof objects can be checked. Alertmanager already separates activity and suppression. Their inspected source cards are in `Cards.md`; authors' findings and stated boundaries are separate from Paper7's inference. The proposed knowledge is therefore the specific relation between retained comparisons and the two outputs of the chosen lifecycle, rather than novelty for version tagging, explanations, silencing or abstraction in general.

### Contribution–evidence matrix

| Contribution claim | Closest prior capability | Present research operation | Direct evidence | Valid interpretation | Remaining boundary |
|---|---|---|---|---|---|
| Joint version relations preserve the decision tuple; component relations preserve its reason as well. | Abstract-stream precision and explanatory verdicts. | Inductive proofs for the stated transition order; compare encodings of the same histories. | Information-requirements propositions; `../r3/analysis/representation_results.json`:26,430 preserved tuples and585 reason changes under the explicit decoder. | Decision preservation and reason preservation are different contracts. | Sufficiency is proved; a globally minimal encoding is not established. |
| A reason cannot always be recovered from the three joint comparisons. | Checked explanations distinguish what supports a verdict. | Construct two first events with identical joint comparison and retained inputs, but context versus policy mismatch. | Proposition4's counterexample gives different required reason labels. | No deterministic decoder of those identical reduced inputs can return both required reasons. | The observed585 changes are this decoder's count, not a lower bound for every decoder. |
| Removing suppression binding can preserve every active interval and still alter displayed decisions. | Alertmanager already separates active alerts from silence handling. | Remove only suppression-version checks and score both endpoints on identical traces. |30/987 base traces differ;48 event tuples differ;987/987 active interval sequences agree. | An activity-only endpoint misses this class of discrepancy in the constructed test. | No industrial frequency or operational consequence is estimated. |
| The complete contract is executable in independent implementations. | Established runtime-monitoring engines and ordinary SQL. | Supply identical policy, events and severity to incremental/reference, SQLite and PyContract encodings. | SQL and PyContract each reproduce4,935 sequences/26,430 events; external fixture projection reproduces4/4 selected assertions from8. | Agreement checks implementation conformance and prevents attributing the result to a special execution engine. | Later replays reuse the corpus; fixture mapping covers specified suppression conditions only. |

## Question → method → finding → interpretation — Gold §6

| Question | Method | Finding | Interpretation |
|---|---|---|---|
| What can the interface discard for each output? | Single-field deletion witnesses and endpoint-specific sufficiency/ambiguity proofs. | Each balanced deletion assay has B=5/10; three comparisons preserve decisions; six preserve decisions and reasons. | Specify information requirements relative to the requested output. |
| How do missing bindings affect behavior? | Matched ablations with complete trace, active interval and event-attribute endpoints. | Stale suppression changes display without changing intervals; observation/freshness ablations also change activity. | Endpoint choice determines which contract error is visible. |
| Do irrelevant/equivalent changes preserve decisions? | Metadata and seconds-to-milliseconds variants. |3,290 comparisons per method preserve outputs, including reduced methods. | Invariance is a separate property from reference agreement. |

No new scoring was required for this editorial narrowing. In this companion pass, direct source comparison confirmed that the abstract and all content from Section3 to the end are byte-identical to the independently checked R3 source. The earlier numerical audits therefore still apply to these unchanged claims. Exact finite-set counts remain the appropriate analysis for the constructed dependent designs.

## Gold hard gates — §11

| Gate | Verdict | Evidence and exact interpretation |
|---|---|---|
| G1 Venue | PASS for scientific fit; current formatting rules NOT VERIFIED | SCP monitoring papers and the3-article benchmark support the genre. `../r3/audit/Publisher_Source_Check.md` identifies the current guide403; no current rule is invented. |
| G2 Contribution | PASS for the narrowed claim | Theorem-specific primary comparison, contribution matrix above, composed-policy proofs and separate reason counterexample support the output-specific result. No claim of general abstraction firstness or minimal code length is made. |
| G3 Reader | PASS | Introduction defines review alert, episode and deferral before comparison fields; the stale-deferral example motivates the endpoint distinction. The method pipeline and state/output explanation prepare the propositions. |
| G4 Continuity | PASS | Questions, two output contracts, proof, replay and conclusion use the same decision-versus-reason distinction. Matched engine parity is supporting conformance evidence. |
| G5 Sources | PASS at recorded access levels | `Cards.md`, `literature_check.json` and the gap report distinguish full-text formal/application sources from RTLola/CauMon exact-journal abstracts/previews. The full Leucker theorem paragraph was inspected in this pass. |
| G6 Methods | PASS for this genre | Explicit event fields, temporal boundaries, reset/validation precedence, trace unit, source/family split and matched comparators; independent oracle and later corrections recorded. |
| G7 Results | PASS | Prior independent raw-output audits remain applicable to unchanged Section3 onward. Three-comparison count is explicitly decoder-specific:510+75=585 reason differences and zero tuple differences. Null invariance and parity results remain visible. |
| G8 Figures | PASS | Three source-grounded visuals, captions/units/conditions and editable sources; current19-page inspection in `Final_Render.md` covers the changed pagination and comparison table. |
| G9 Preservation | PASS | Direct comparison in this pass confirms unchanged abstract and Section3 onward relative to R3. The original freeze and raw evidence were not modified. |
| G10 Production | PASS for current local artifact | Exact new PDF/source identities above; `Final_Render.md` records all19 pages; final logs have no relevant warnings. This pass reopened the8-entry flat source ZIP and independently verified CRC and flat paths. |
| G11 Authorial voice | PASS | Connected problem/operation/evidence prose; research-relevant AI reference provenance and required AI disclosure remain separate from editorial checklists. No Gold labels are inserted into the article. |
| G12 Closure | PASS | Scientific findings already resolved remain closed. The present report introduces only a companion editorial assessment and names the remaining venue/author gates. |

The current visual inspection was performed by the separate visual-review agent; this companion reviewer read that hash-specific report and checked build/package evidence, rather than claiming another19-page visual pass.

## Prioritized issue register and retained passages — Gold §§8–12

| Finding and location | Primary evidence | Severity | Required action | Access/confidence boundary |
|---|---|---|---|---|
| Current official title-specific guide is unavailable. | `Publisher_Source_Check.md`: ScienceDirect and official alternate guide URLs returned403. | Submission blocker, administrative | Verify the current guide before submission and reconcile its actual requirements with the prepared files. | Source access is the unresolved fact; it does not reverse the scientific fit decision. |
| Paper7 personal declarations are unconfirmed. | `../submission/Author_and_Declarations.md`; current factual AI-use statement. | Submission blocker, author-only | Obtain accurate interests, funding, responsibility, contributor roles and exclusivity declarations. | An agent cannot attest on the author's behalf. |
| Release scope must match the artifact actually distributed. | Offline supplement omits private source snapshots; separate provenance retains them. | Release-specific administrative check | Use the cleared offline supplement; verify rights before any separate publication of private recovered materials. | No public release or submission is authorized by this session. |
| Fixed source-policy and constructed traces determine the scientific claim. | Methods, preserved protocol and dedicated Limitations. | Defined scope, not a new correction | Retain the contract-specific conclusion. Expand only under a new authorized study with an external policy/history reference. | No requirement to invent industrial validation or restart the completed study. |

Retain the first two introduction paragraphs, the explicit comparison with abstract-stream precision, the distinction between deleting an identifier and retaining its relation, Proposition4's reason counterexample, the30-versus0 suppression endpoint result, and the sentence identifying585 as a count for the explicit decoding. These passages directly resolve the chief-editor tests for need, prior capability, mechanism, evidence and interpretation. No further manuscript edit is prescribed by this review.

## Applicability and final disposition

This is a computational/theoretical software paper. Gold's qualitative recruitment, systematic-review flow, double-anonymization and causal-treatment examples are conditional genre guidance, not missing experiments for Paper7. The paper is identified for the recorded single-anonymized preparation route; that title-specific rule remains tied to the dated guide until current official verification. Exact article APC coverage is relevant only if that publication route is chosen; unverified coverage is not asserted as an entitlement.

The companion test is complete for the present narrowed claim, with the named venue/author checks retained. The user-facing package status remains **NOT READY for journal submission**. Preserve this report with the exact manuscript/source identities and existing source/evidence records. Do not reopen closed scientific findings or introduce another cosmetic rewrite solely because this companion prompt was recovered later.
