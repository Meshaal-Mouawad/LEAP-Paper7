"""Construct simulated revision traces. No monitored industrial data used."""
import json,itertools,copy,hashlib,pathlib,importlib.util
ROOT=pathlib.Path(__file__).resolve().parents[1]
REC=ROOT/'recovery/github/AI-Powered_KPI_Extractor_Interactive_Bluebook_Generator'
spec=importlib.util.spec_from_file_location('recovered',REC/'governance_patch.py'); recovered=importlib.util.module_from_spec(spec);spec.loader.exec_module(recovered)
FAMILIES=[
 ('KSA-PDPL-REG-01','privacy','national_id = 1','masked = hash(national_id)','check_ksa_pdpl_reg_01','development'),
 ('KSA-NCA-ECC-SEC-04','execution','eval(value)','result = value','check_ksa_nca_ecc_sec_04','development'),
 ('KSA-NCA-ECC-AUD-02','audit','update(record)','update(record) # actor timestamp before after diff','check_ksa_nca_ecc_aud_02','heldout'),
 ('GDPR-DATA-PROC-01','transfer','export(personal_data)','export(personal_data) # consent','check_gdpr_data_proc_01','heldout'),
 ('SOC2-LINEAGE-AUDIT-01','lineage','trace = record','trace = record # signature','check_soc2_lineage_audit_01','heldout')]
POLICY={'D':2,'C':2,'E':4,'F':2}
def event(t,value,c='c1',p='p1'):
 e={'t':t,'unit':'s','c':c,'p':p}
 if value!='missing':e['o']={'value':value,'c':c,'p':p,'at':t}
 return e

def designs():
 # Exhaustive finite alphabet coverage; complete event sequences stay in family split.
 for values in itertools.product([False,True,None,'missing'],repeat=4):
  yield 'exhaustive',''.join({False:'0',True:'1',None:'x','missing':'m'}[v] for v in values),[event(i*2,v) for i,v in enumerate(values)]
 base=[event(i,v) for i,v in enumerate([False,True,True,True,True,True,True,True,False,False,False,False])]
 yield 'control','activate_clear',base
 yield 'control','all_clear',[event(i,False) for i in range(12)]
 yield 'control','all_alert',[event(i,True) for i in range(12)]
 # One intervention per trace plus explicit boundary sweeps. No random tuning.
 for j in (2,3,5,7,9):
  for typ in ('missing','conflict','stale','future','context_old_obs','policy_old_obs','context_fresh','policy_fresh','suppression_valid','suppression_old_context','suppression_old_policy'):
   a=copy.deepcopy(base)
   if typ=='missing':a[j].pop('o')
   elif typ=='conflict':a[j]['o']['value']=None
   elif typ=='stale':a[j]['o']['at']=j-3
   elif typ=='future':a[j]['o']['at']=j+1
   elif typ in ('context_old_obs','context_fresh'):
    for e in a[j:]:e['c']='c2';e['o']['c']='c1' if typ=='context_old_obs' else 'c2'
   elif typ in ('policy_old_obs','policy_fresh'):
    for e in a[j:]:e['p']='p2';e['o']['p']='p1' if typ=='policy_old_obs' else 'p2'
   else:
    for e in a[j:]:e['s']={'c':'c0' if typ=='suppression_old_context' else 'c1','p':'p0' if typ=='suppression_old_policy' else 'p1','until':j+2}
   yield typ,str(j),a
 for boundary in ('dwell','clear','escalate','freshness','suppression'):
  for delta in (-.5,0,.5):
   if boundary=='dwell':a=[event(0,True),event(2+delta,True)]
   elif boundary=='clear':a=[event(0,True),event(2,True),event(3,False),event(5+delta,False)]
   elif boundary=='escalate':a=[event(0,True),event(2,True),event(6+delta,True)]
   elif boundary=='freshness':a=[event(0,True),event(2+delta,True)];a[-1]['o']['at']=0
   else:
    a=[event(0,True),event(2,True),event(4+delta,True)]
    a[-1]['s']={'c':'c1','p':'p1','until':4}
   yield 'boundary_'+boundary,str(delta),a

def build():
 rows=[];sources=[];checks=[]
 kb=json.loads((REC/'iso_framework.json').read_text())
 for rule,family,pos,neg,fn,split in FAMILIES:
  severity=next(x['severity'] for x in kb['local_governance_rules'] if x['rule_id']==rule)
  checks.append({'rule':rule,'positive':bool(getattr(recovered,fn)(pos)),'negative':bool(getattr(recovered,fn)(neg))})
  assert checks[-1]['positive'] and not checks[-1]['negative']
  artifact='simulated_'+family+'_revision_source'
  sources.append(dict(rule=rule,family=family,source=artifact,split=split,positive=pos,negative=neg,adapter=fn,severity=severity,provenance='New controlled snippets, evaluated by recovered lexical predicates; not execution of these snippets'))
  for mechanism,key,trace in designs():
   for variant in ('base','metadata','milliseconds'):
    a=copy.deepcopy(trace)
    for e in a:
     if 'o' in e and type(e['o']['value']) is bool:
      code=pos if e['o']['value'] else neg
      e['o']['snapshot']=code;e['o']['snapshot_sha256']=hashlib.sha256(code.encode()).hexdigest()
      e['o']['value']=bool(getattr(recovered,fn)(code))
     if variant=='metadata':e['metadata']={'display_name':'irrelevant renamed title','note':'new annotation outside analyzed source'}
     if variant=='milliseconds':
      e['unit']='ms';e['t']*=1000
      if 'o' in e:e['o']['at']*=1000
      if 's' in e:e['s']['until']*=1000
    group=f'{family}/{mechanism}/{key}'
    rows.append(dict(id=group+'/'+variant,group=group,rule=rule,family=family,source=artifact,split=split,mechanism=mechanism,variant=variant,severity=severity,trace=a))
 (ROOT/'benchmark/traces.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in rows))
 (ROOT/'benchmark/sources.json').write_text(json.dumps(sources,indent=2))
 (ROOT/'benchmark/policy.json').write_text(json.dumps(POLICY,indent=2))
 (ROOT/'benchmark/adapter_checks.json').write_text(json.dumps(checks,indent=2))
 print(json.dumps({'traces':len(rows),'groups':len(rows)//3,'events':sum(len(x['trace']) for x in rows),'development':sum(x['split']=='development' for x in rows),'heldout':sum(x['split']=='heldout' for x in rows)},indent=2))
if __name__=='__main__':build()
