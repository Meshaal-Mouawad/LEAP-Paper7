"""One-time prospective freeze; refuses to overwrite an existing freeze."""
import pathlib,json,hashlib,datetime
from oracle import oracle
ROOT=pathlib.Path(__file__).resolve().parents[1]
assert not (ROOT/'protocol/FREEZE.json').exists(),'Already frozen'
p=json.loads((ROOT/'benchmark/policy.json').read_text())
with (ROOT/'benchmark/reference.jsonl').open('w') as out:
 for x in map(json.loads,(ROOT/'benchmark/traces.jsonl').open()):out.write(json.dumps({'id':x['id'],'outputs':oracle(x['trace'],p,x['severity'])})+'\n')
w=json.loads((ROOT/'benchmark/necessity_witnesses.json').read_text())
for x in w:
 x['left_reference']=oracle(x['left'],p);x['right_reference']=oracle(x['right'],p)
(ROOT/'benchmark/witness_references.json').write_text(json.dumps(w,indent=2))
files=[]
for folder in ['protocol','benchmark','implementation']:
 files.extend(q for q in (ROOT/folder).rglob('*') if q.is_file() and '__pycache__' not in str(q))
record={'study':'LEAP Paper 7','version':1,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':'after development comparisons; before heldout monitor evaluation','sha256':{str(q.relative_to(ROOT)):hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted(files)}}
(ROOT/'protocol/FREEZE.json').write_text(json.dumps(record,indent=2));print('Frozen',len(files),'files at',record['utc'])
