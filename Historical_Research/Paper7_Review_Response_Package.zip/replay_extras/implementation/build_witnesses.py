import json,copy,pathlib
from build_benchmark import event,FAMILIES
ROOT=pathlib.Path(__file__).resolve().parents[1]
rows=[]
for rule,family,pos,neg,fn,split in FAMILIES:
 for field in ['event.c','event.p','o.c','o.p','s.c','s.p']:
  a=[event(t,True) for t in (0,2,3,5)]
  if field.startswith('s.'):
   for e in a:e['s']={'c':'c1','p':'p1','until':10}
  b=copy.deepcopy(a)
  for e in b[1:]:
   outer,inner=field.split('.')
   if outer=='event':e[inner]+='_other'
   else:e[outer][inner]+='_other'
  rows.append({'id':family+'/'+field,'family':family,'rule':rule,'projection_drop':field,'left':a,'right':b})
(ROOT/'benchmark/necessity_witnesses.json').write_text(json.dumps(rows,indent=2))
print('Witness pairs',len(rows))
