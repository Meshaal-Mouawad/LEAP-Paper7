# M4 reproducibility closure — Paper 7

**M4 result: PASS for the complete temporal study.** An independent AI-agent replay extracted the latest standalone supplement, verified its 58 input checksums, executed its documented command, retained a separate fresh run, and recomputed the raw endpoint counts without importing the original evaluator, monitor or reference-oracle helpers. All nine retained subprocess commands exited successfully. All 270 original primary metric rows matched the independent rescore.

The deliverable is `LEAP_Paper7_Research_Reproduction.zip`, 846,551 bytes, 174 files. SHA-256: `c121f98da3a2379c56655f5511673f1018de121dcb71ad684018046a35b1c94c`. It contains pristine executable study inputs, a fresh full run with raw predictions and logs, editable design and mechanism tables, independent audit scripts, pinned public upstream source and licenses, a full file manifest, and four explicit reproduction commands. It requires Python 3.11+ with SQLite and pandas; the observed environment is recorded. It performs no network retrieval or package installation.

| Check | Independently observed result |
|---|---|
| Complete benchmark | 4,935 traces; 26,430 events; 1,645 intact transformation groups |
| Held-out base denominator | 987 traces; 5,286 events; 1,293 active; 3,993 inactive; 1,803 UNKNOWN reference events |
| Held-out transformed denominator | 2,961 traces; 15,858 events |
| Input partition check | Source and family labels disjoint across partitions; all three related variants together |
| Primary raw output digest | `18d4c6db9f58c9844e465e6447229cb49b242cc299e557bde2b62fcc6704c14a` |
| SQLite raw output digest | `bcd6f2cf4d125efb2a19f7cdec719b0fcbcc53378a953acaebb92ee6f7e64909` |
| PyContract raw output digest | `05e417a248e8557f7a4635c33b485a9eeeee34b7b91e319e573f640dfe877810` |
| SQLite and PyContract references | All four output fields equal on every trace; no execution errors |
| Metamorphic outputs | All six methods equal on 3,290/3,290 metadata/time-unit pairs each |
| Reference regression | 29/29 intended valid cases |
| Upstream suppression projection | 4/4 mapped expectations |
| Equality encoding | Zero sequence mismatches |
| Reduced representation | Zero decision mismatches; 585 reason differences (510 + 75) |

`PACKAGE_VERIFICATION.json` records ZIP CRC, manifest, path and privacy-projection checks. `FINAL_EXTRACTED_PACKAGE_EXECUTION.json` and its three stdout/stderr pairs record execution from the exact final ZIP after fresh extraction. `SOURCE_ARCHIVE.json` identifies the source offline supplement by SHA-256. `DOCUMENTED_COMMAND.json` records the first untouched documented execution; `fresh_run/fresh_execution/` preserves the separate retained replay. `independent_analysis_final/` and the ZIP's `analysis/` contain the recalculated tables.

The new `base_mechanism_metrics.csv` separates family, intervention mechanism and method for base designs; it avoids treating transformations as independent samples. `design_inventory.csv` maps each trace to its group, source/family, policy rule, mechanism, partition, variant and reference denominators. `DESIGN_AND_MECHANISMS.md` explains the 329-design construction per family and links each mechanism to its executable records. The unchanged original runner verifies the paired-witness and representation outputs; the independent scorer specifically verifies raw primary/baseline outputs, denominators, episode spans and partition integrity.

## Scope and remaining gates

This closure covers offline reproduction from the temporal observation interface. The derivative benchmark excludes 18,600 illustrative snapshot strings and associated digests that no evaluated temporal method consumes, and reproduces the historical output digests exactly. The package excludes private LEAP source snapshots, private lexical adapter generation and the eleven-case source-recovery replay. The preserved design inventory supplies the temporal design data. The package contains constructed traces and an explicit experimental policy. It supplies no deployment observations or human adjudication. Submission readiness, current official venue requirements, author attestations and authorization for public distribution remain separate decisions for the lead review.
