#!/bin/sh
set -eu
pdflatex -interaction=nonstopmode -halt-on-error Paper7.tex
if command -v bibtex8 >/dev/null 2>&1; then
  bibtex8 Paper7
elif command -v bibtex >/dev/null 2>&1; then
  bibtex Paper7
elif command -v bibtex.original >/dev/null 2>&1; then
  bibtex.original Paper7
else
  echo 'BibTeX is required: citation numbering cannot be checked with a stale .bbl file.' >&2
  exit 1
fi
pdflatex -interaction=nonstopmode -halt-on-error Paper7.tex
pdflatex -interaction=nonstopmode -halt-on-error Paper7.tex
