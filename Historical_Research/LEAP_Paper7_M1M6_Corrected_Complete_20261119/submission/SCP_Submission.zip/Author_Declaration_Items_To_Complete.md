# Author-only declarations — factual completion required in submission system

These are the remaining questions for the author and journal; no factual attestations have been fabricated.

- Funding source and sponsor role, if any.
- Financial and nonfinancial competing interests.
- Whether another journal is considering this manuscript and original-work exclusivity confirmation.
- Required CRediT roles, if the journal requests them.
- Current SCP file-category, highlight-limit, generative-AI disclosure and competing-interest form instructions; apply the live official guide at submission.

The manuscript already includes the approved AI-preparation responsibility statement. This list is not part of the scientific manuscript.
