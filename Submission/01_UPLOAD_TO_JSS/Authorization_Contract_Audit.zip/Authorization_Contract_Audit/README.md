# Paper 7: approval-applicability contract and monitor-consequence audit

**Identity:** Supplementary, independently specified implementation-conformance audit for *Tracing KPI Source Revisions into Version-Sensitive Governance Alert Decisions* (Mouawad, 2026).

## Scientific design

Archived governing documents (`source_snapshot/.ai/BUSINESS_RULES.md`, `source_snapshot/.ai/GOVERNANCE_SPEC.md`) establish file-signature lineage, approval status, and review override applicability based on KPI identity and code-context hash. The reference is a declared **conjunction** of those written requirements; its experimental implementation is in `verify_authorization_contract.py`. This is an explicit controlled reference rule, not a claim of operational approval records.

**Native algorithm:** The script selects and executes the original AST function bodies `_definition_override_candidates` and `_apply_definition_override` from the original archived `source_snapshot/main.py`. It does not patch their logic. The source `main.py` also computes the 10-character MD5 code-context hash, whereas the documented ledger stores a 64-character SHA-256 signature of the full file. `source_file_signature` is a field read but not assigned in the inspected native module; the tests therefore inject this field to assess the specified interface. The test ledgers are constructed, not recovered authorizations.

**Cases:** 16 controlled approval conditions, including approved/pending/rejected/missing status, changed/renewed source signatures, changed/renewed code hashes, inconsistent identifier/name, and missing records. The native function agrees with the conjunctive reference in 7/16 cases and differs in 9/16 (8 applications without a qualifying record, 1 missed qualified record). Exact rows: `test_results.csv`; derived counts: `result_summary.json`. Source files and their archived hashes are included.

**Key information counterexample:** T01 and T04 have identical source bytes, code-context digest, and stable KPI identifier but different ledger authorization states. Their reference applicability decisions differ. T11 shows a changed file with a correctly renewed approval. Source equality alone therefore cannot decide approval validity.

**Downstream demonstration:** `propagate_authorization_to_monitor.py` invokes the frozen monitor on **one** archived constructed warning/deferral witness trace with each test's expected and native applicability value. Nine of 16 controlled mappings change a single displayed event and zero active episodes. These are replays of one witness, not independently observed alerts. Detailed records: `downstream_consequence.csv`; summary: `downstream_summary.json`.

## Reproduce

Requires Python 3.11+ (standard library only).

```bash
python -B verify_authorization_contract.py
python -B propagate_authorization_to_monitor.py
```

From this directory, the first command recreates the structured rows and direct evidence checksum record; the second command recreates the downstream event comparison. Both scripts use only included files. The originals were copied without changes to underlying code or governance documents, and original temporal/source experiments remain in their own unchanged archives.

## Interpretation boundary

The combined written requirement is a transparent test contract, not a reconstructed deployed authorization database. These 16 controlled records do not establish the effectiveness of a live organizational approval workflow. The separate nine historical Git source-revision pairs and 252 constructed monitoring streams are preserved in the two original reproduction archives accompanying the manuscript.

DOI assigned to the existing Harvard Dataverse draft: `10.7910/DVN/3A5J9E`; add **this archive as one supplemental file to that existing dataset**, not as a new dataset.
