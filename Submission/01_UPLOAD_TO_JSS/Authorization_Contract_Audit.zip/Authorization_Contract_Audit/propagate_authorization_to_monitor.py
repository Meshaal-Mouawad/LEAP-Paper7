#!/usr/bin/env python3
"""Deterministic policy consequence of controlled authorization mismatch.
This reuses one archived constructed trace for every controlled approval test.
No deployed alerts or independent observation samples are claimed.
"""
from pathlib import Path
import csv,json,copy,importlib.util,hashlib
P=Path(__file__).resolve().parent
source=P/'frozen_monitor/monitor.py'
spec=importlib.util.spec_from_file_location('paper7_contract_monitor',source)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
events=json.loads((P/'frozen_monitor/witness.json').read_text())['events']
policy=json.loads((P/'frozen_monitor/policy.json').read_text())
assert isinstance(policy,dict)
if all(k in policy for k in ('D','C','E','F')): policy={k:policy[k] for k in ('D','C','E','F')}
else:policy={'D':2,'C':2,'E':4,'F':2}
def monitor(eligible):
 ev=copy.deepcopy(events)
 for e in ev:
  if 's' in e: e['s']['c']='c1' if eligible else 'c0'
 return m.monitor(ev,policy,base_severity='COMPLIANCE_AUDIT_GAP',mode='bound')
rows=[]
for r in csv.DictReader((P/'test_results.csv').open()):
 expected=monitor(r['reference_eligible']=='1')
 native=monitor(r['native_override_applied']=='1')
 diff=[i for i,(a,b) in enumerate(zip(expected,native)) if a!=b]
 # These tests are a deliberately reused trace, not independent alert histories.
 rows.append(dict(case_id=r['case_id'],reference_approved=r['reference_eligible'],native_applied=r['native_override_applied'],different_output_tuples=len(diff),event_indices=','.join(map(str,diff)),episode_activity_differences=sum(a['active']!=b['active'] for a,b in zip(expected,native)),reference_at_3s=json.dumps(expected[3],sort_keys=True),actual_at_3s=json.dumps(native[3],sort_keys=True)))
assert len(rows)==16
assert sum(bool(int(x['different_output_tuples'])) for x in rows)==9
assert all(x['episode_activity_differences']==0 for x in rows)
assert all(x['different_output_tuples']==1 for x in rows if x['reference_approved']!=x['native_applied'])
with (P/'downstream_consequence.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,rows[0].keys());w.writeheader();w.writerows(rows)
summary={'controlled_cases':16,'reference_vs_native_decision_disagreements':9,'different_event_tuples':9,'active_episode_differences':0,'frozen_monitor_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'frozen_trace_id':'audit/suppression_old_context/2/base','interpretation':'16 counterfactual applications of one frozen monitor trace, not 16 measured operational monitoring histories'}
(P/'downstream_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
