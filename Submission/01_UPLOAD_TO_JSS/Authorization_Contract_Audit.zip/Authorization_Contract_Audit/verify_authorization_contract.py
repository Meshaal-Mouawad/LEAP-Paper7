#!/usr/bin/env python3
"""Controlled LEAP override applicability test against an independent written contract.

Inputs: exact archived LEAP source snapshots, governance documents, controlled
approval records. The hypothetical test records are not operational approvals.
No archived empirical study output is overwritten by this script.
"""
from __future__ import annotations
import ast,csv,hashlib,json
from pathlib import Path
BASE=Path(__file__).resolve().parent
SOURCE=BASE/'source_snapshot'
CODE=(SOURCE/'main.py').read_text()
BUSINESS=(SOURCE/'.ai/BUSINESS_RULES.md').read_text()
GOV=(SOURCE/'.ai/GOVERNANCE_SPEC.md').read_text()
assert 'If KPI id and code hash match:' in GOV
assert 'SHA256 file signatures for verification' in BUSINESS
assert 'Overrides marked with status "APPROVED_BY_BUSINESS"' in BUSINESS
assert 'code_hash' in CODE and 'source_file_signature' in CODE
sha=lambda b:hashlib.sha256(b).hexdigest()
md5=lambda b:hashlib.md5(b).hexdigest()[:10]
raw=(SOURCE/'python_kpi.py').read_bytes()
old_file=sha(raw)
new_file=sha(raw + b'\n# Controlled audit-only trailing documentation line\n')
# A deterministic literal local code_context slice is supplied as the extractor's
# controlled input; no assertion is made that it is a full real-workspace extraction.
context=b'def audit_kpi(a, b):\n    return a / b\n'
old_code=md5(context)
new_code=md5(context.replace(b'a / b',b'a / (b + 1)'))
node_tree=ast.parse(CODE)
fnames={'_definition_override_candidates','_apply_definition_override'}
fn=[n for n in node_tree.body if isinstance(n,ast.FunctionDef) and n.name in fnames]
assert len(fn)==2
config=next(n for n in node_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='DEFINITION_OVERRIDE_FIELDS' for t in n.targets))
fields=ast.literal_eval(config.value)
ns={'Path':Path,'DEFINITION_OVERRIDE_FIELDS':fields}
compiled=ast.Module(body=fn,type_ignores=[]);ast.fix_missing_locations(compiled)
exec(compile(compiled,'<archived original LEAP function nodes>','exec'),ns)
apply=ns['_apply_definition_override']
# C1's implementation diagnostic. Confirm no declaration writes source_file_signature
# to a KPI in the included source, and loader only carries file_signature.
occ=[(x.lineno,ast.get_source_segment(CODE,x)) for x in ast.walk(node_tree) if isinstance(x,ast.Constant) and x.value=='source_file_signature']
assert len(occ)==1,occ
native_loader=next(n for n in node_tree.body if isinstance(n,ast.FunctionDef) and n.name=='_load_definition_overrides')
loader_text=ast.get_source_segment(CODE,native_loader)
assert '"file_signature": block.get("file_signature")' in loader_text
assert '"code_hash": block.get("code_hash")' not in loader_text
# Conjunctive audit policy from two distinct explicit written requirements.
# This tests a well-defined written contract, not claimed deployed approvals.
def reference(kpi,block):
 if not block:return False
 return all([
   block.get('status')=='APPROVED_BY_BUSINESS',
   bool(block.get('kpi_id')),block.get('kpi_id')==kpi.get('id'),
   bool(block.get('code_hash')),bool(kpi.get('code_hash')),
   block.get('code_hash')==kpi.get('code_hash'),
   bool(block.get('file_signature')),bool(kpi.get('source_file_signature')),
   block.get('file_signature')==kpi.get('source_file_signature')])
base_kpi={'id':'KPI-001','name':'Audit KPI','file_path':'sample_project/python_kpi.py','source_file_signature':old_file,'code_hash':old_code}
base_ledger={'kpi_id':'KPI-001','status':'APPROVED_BY_BUSINESS','file_signature':old_file,'code_hash':old_code,'fields':{'objective':'controlled approval value'}}
# Each case uses original source bytes, specified transformations, and controlled ledgers.
# The tests isolate independent changes to authorized identity, ledger status and evidence.
cases=[
 ('T01','all binding fields match',{},{}),
 ('T02','changed source file with old signed ledger',{'source_file_signature':new_file},{}),
 ('T03','stale code-context digest with identical source version',{}, {'code_hash':new_code}),
 ('T04','pending status with identical source version',{}, {'status':'PENDING'}),
 ('T05','rejected status with identical source version',{}, {'status':'REJECTED'}),
 ('T06','missing ledger file signature',{}, {'file_signature':''}),
 ('T07','missing ledger code hash',{}, {'code_hash':''}),
 ('T08','missing current file signature',{'source_file_signature':''}, {}),
 ('T09','missing current code hash',{'code_hash':''}, {}),
 ('T10','wrong ledger KPI id while display name matches',{}, {'kpi_id':'KPI-002'}),
 ('T11','changed source and freshly authorized ledger',{'source_file_signature':new_file}, {'file_signature':new_file}),
 ('T12','changed code context with stale ledger',{'code_hash':new_code,'source_file_signature':new_file},{}),
 ('T13','changed code context and freshly authorized ledger',{'code_hash':new_code,'source_file_signature':new_file}, {'code_hash':new_code,'file_signature':new_file}),
 ('T14','missing approval status',{}, {'status':''}),
 ('T15','different KPI name without matching ledger key',{'name':'Other KPI'},{}),
 ('T16','no approval record',{},None),
]
rows=[]
for sid,descr,kdelta,ldelta in cases:
 k={**base_kpi,**kdelta}
 ledger=None if ldelta is None else {**base_ledger,**ldelta}
 supplied={base_kpi['name']:ledger} if ledger is not None else {}
 initial={'objective':'unapproved text'}
 actual=apply(k,initial,supplied)
 observed=actual.get('objective')=='controlled approval value'
 expected=reference(k,ledger)
 rows.append(dict(case_id=sid,controlled_condition=descr,reference_eligible=int(expected),native_override_applied=int(observed),conforms=int(expected==observed),source_changed=int(k.get('source_file_signature')!=old_file),code_hash_changed=int(k.get('code_hash')!=old_code),kpi_id_changed=int(k.get('id')!=base_kpi['id']),ledger_status=(ledger or {}).get('status','NONE')))
# Decisive counterexample: same source identity under A and D but changed ledger
# status/code hash, so no source-only version identity can decide applicability.
assert rows[0]['reference_eligible']==1 and rows[3]['reference_eligible']==0
assert rows[0]['source_changed']==rows[3]['source_changed']==0
assert rows[0]['code_hash_changed']==rows[3]['code_hash_changed']==0
assert rows[10]['reference_eligible']==1 and rows[10]['source_changed']==1
assert rows[0]['native_override_applied']==1
summary={'case_count':len(rows),'conforming':sum(r['conforms'] for r in rows),'nonconforming':sum(1-r['conforms'] for r in rows),'unsupported_cases':[r['case_id'] for r in rows if not r['conforms']],'original_main_sha256':sha(CODE.encode()),'original_business_rules_sha256':sha(BUSINESS.encode()),'original_governance_spec_sha256':sha(GOV.encode()),'original_sample_sha256':sha(raw),'native_source_file_signature_reference_count':len(occ),'source_file_signature_assigned_by_inspected_main':False,'override_loader_retains_ledger_code_hash':False,'reference_basis':'Conjunctive interpretation of the archived written approval requirements, exercised only on controlled test ledgers; no operational authorizations are inferred.'}
with (BASE/'test_results.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
(BASE/'result_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(BASE/'selected_native_functions.py').write_text('\n\n'.join(ast.get_source_segment(CODE,n) for n in fn)+'\n')
print(json.dumps(summary,indent=2))
for r in rows: print(r['case_id'],r['reference_eligible'],r['native_override_applied'],r['conforms'])
